/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { HeroSection } from './components/home/HeroSection';
import { TrustCertificatesBanner } from './components/home/TrustCertificatesBanner';
import { FeaturedPackages } from './components/home/FeaturedPackages';
import { UmrahCalculator } from './components/home/UmrahCalculator';
import { HotelExplorer } from './components/home/HotelExplorer';
import { FleetShowcase } from './components/home/FleetShowcase';
import { VisaSection } from './components/home/VisaSection';
import { DestinationsSection } from './components/home/DestinationsSection';
import { ImportExportSection } from './components/home/ImportExportSection';
import { QuickWhatsAppBar } from './components/home/QuickWhatsAppBar';
import { CertificateModal } from './components/common/CertificateModal';
import { InquiryModal } from './components/common/InquiryModal';
import { AdminLayout } from './components/admin/AdminLayout';

function MainContent() {
  const { activeTab, toasts } = useApp();

  if (activeTab === 'admin') {
    return (
      <>
        <AdminLayout />
        <CertificateModal />
        {/* Toast notifications */}
        <div className="fixed top-4 right-4 z-50 space-y-2 pointer-events-none">
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`p-3 rounded-xl text-xs font-semibold shadow-xl border pointer-events-auto transition-all animate-bounce-short ${
                toast.type === 'error'
                  ? 'bg-rose-950 border-rose-500 text-rose-200'
                  : toast.type === 'info'
                  ? 'bg-slate-900 border-sky-500 text-sky-200'
                  : 'bg-slate-900 border-emerald-500 text-emerald-200'
              }`}
            >
              {toast.message}
            </div>
          ))}
        </div>
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans pb-16 sm:pb-0">
      <Navbar />

      <main className="flex-1">
        {activeTab === 'home' && (
          <>
            <HeroSection />
            <TrustCertificatesBanner />
            <FeaturedPackages />
            <UmrahCalculator />
            <HotelExplorer />
            <FleetShowcase />
            <VisaSection />
            <DestinationsSection />
            <ImportExportSection />
          </>
        )}

        {activeTab === 'packages' && (
          <div className="py-8">
            <FeaturedPackages />
          </div>
        )}

        {activeTab === 'hotels' && (
          <div className="py-8">
            <HotelExplorer />
          </div>
        )}

        {activeTab === 'transport' && (
          <div className="py-8">
            <FleetShowcase />
          </div>
        )}

        {activeTab === 'visa' && (
          <div className="py-8">
            <VisaSection />
          </div>
        )}

        {activeTab === 'calculator' && (
          <div className="py-8">
            <UmrahCalculator />
          </div>
        )}

        {activeTab === 'certificates' && (
          <div className="py-8">
            <TrustCertificatesBanner />
          </div>
        )}

        {activeTab === 'import-export' && (
          <div className="py-8">
            <ImportExportSection />
          </div>
        )}
      </main>

      <Footer />

      {/* Global Modals & Sticky Mobile Bar */}
      <CertificateModal />
      <InquiryModal />
      <QuickWhatsAppBar />

      {/* Toast notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2 pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`p-3 rounded-xl text-xs font-semibold shadow-xl border pointer-events-auto transition-all ${
              toast.type === 'error'
                ? 'bg-rose-950 border-rose-500 text-rose-200'
                : toast.type === 'info'
                ? 'bg-slate-900 border-sky-500 text-sky-200'
                : 'bg-slate-900 border-emerald-500 text-emerald-200'
            }`}
          >
            {toast.message}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
