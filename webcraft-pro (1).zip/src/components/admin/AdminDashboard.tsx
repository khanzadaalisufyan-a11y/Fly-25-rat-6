import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Package,
  Building2,
  Car,
  FileText,
  Users,
  ShieldCheck,
  TrendingUp,
  MessageCircle,
  Plus,
  Download,
  CheckCircle,
  Clock,
  Database
} from 'lucide-react';

interface AdminDashboardProps {
  onSelectTab: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onSelectTab }) => {
  const { packages, hotels, vehicles, visaServices, inquiries, certificates, language } = useApp();

  const newInquiriesCount = inquiries.filter((i) => i.status === 'New').length;

  return (
    <div className="space-y-8 animate-fade-in text-xs sm:text-sm">
      {/* Welcome Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-500/15 via-slate-900 to-slate-900 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs text-amber-400 font-bold uppercase tracking-wider block mb-1">
            {language === 'ur' ? 'ایڈمن کنٹرول سینٹر' : 'Master Admin Dashboard'}
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-white font-serif">
            FLY WITH HAMZA TRAVAL AND TOURS
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            {language === 'ur'
              ? 'مکہ مکرمہ آپریشنز، عمرہ و حج بکنگ، فائیو اسٹار ہوٹلز اور ٹرانسپورٹ بیڑہ مکمل کنٹرول میں ہے۔'
              : 'Enterprise portal controlling pilgrimage operations, luxury fleet, hotels, and leads.'}
          </p>
        </div>

        <div className="flex gap-2 shrink-0">
          <button
            onClick={() => onSelectTab('supabase')}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-700/20 transition flex items-center gap-2 cursor-pointer"
          >
            <Database className="w-4 h-4" />
            <span>{language === 'ur' ? 'سپابیس اسکیما (SQL)' : 'Supabase SQL'}</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div
          onClick={() => onSelectTab('inquiries')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 cursor-pointer transition"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs">Leads</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">{inquiries.length}</div>
          <span className="text-[10px] text-rose-400 font-medium">{newInquiriesCount} New Leads</span>
        </div>

        <div
          onClick={() => onSelectTab('packages')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 cursor-pointer transition"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs">Packages</span>
            <Package className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">{packages.length}</div>
          <span className="text-[10px] text-emerald-400 font-medium">Umrah & Hajj</span>
        </div>

        <div
          onClick={() => onSelectTab('hotels')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 cursor-pointer transition"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs">Hotels</span>
            <Building2 className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">{hotels.length}</div>
          <span className="text-[10px] text-slate-400">Makkah/Madinah</span>
        </div>

        <div
          onClick={() => onSelectTab('vehicles')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 cursor-pointer transition"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs">Fleet</span>
            <Car className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">{vehicles.length}</div>
          <span className="text-[10px] text-slate-400">GMC & Vans</span>
        </div>

        <div
          onClick={() => onSelectTab('certificates')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 cursor-pointer transition"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs">Licenses</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono">{certificates.length}</div>
          <span className="text-[10px] text-emerald-400">Saudi CR & Tax</span>
        </div>

        <div
          onClick={() => onSelectTab('company')}
          className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 cursor-pointer transition"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs">Status</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-base font-bold text-emerald-400 font-mono mt-1">Operational</div>
          <span className="text-[10px] text-slate-400">24/7 Live</span>
        </div>
      </div>

      {/* Recent Inquiries List */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-white text-sm">
              {language === 'ur' ? 'حالیہ کسٹمر انکوائریز و بکنگ درخواستیں' : 'Recent Customer Leads & Booking Inquiries'}
            </h3>
          </div>

          <button
            onClick={() => onSelectTab('inquiries')}
            className="text-xs text-amber-400 hover:underline"
          >
            View All ({inquiries.length})
          </button>
        </div>

        <div className="space-y-2">
          {inquiries.slice(0, 4).map((inq) => (
            <div
              key={inq.id}
              className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">{inq.customerName}</span>
                  <span className="text-[10px] px-2 py-0.2 rounded bg-amber-500/20 text-amber-300 font-semibold">
                    {inq.serviceType}
                  </span>
                  <span className="text-[10px] text-slate-400">({inq.country})</span>
                </div>
                <p className="text-slate-300 text-[11px] mt-0.5 line-clamp-1">
                  {inq.targetItemTitle || inq.message}
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="text-slate-400 text-[10px] font-mono">{inq.customerWhatsapp}</span>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    inq.status === 'New' ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-400'
                  }`}
                >
                  {inq.status}
                </span>
                <button
                  onClick={() => onSelectTab('inquiries')}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-200 text-[11px] hover:bg-slate-700"
                >
                  Manage
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
