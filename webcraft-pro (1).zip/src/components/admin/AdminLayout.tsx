import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdminDashboard } from './AdminDashboard';
import { CompanySettingsTab } from './tabs/CompanySettingsTab';
import { PackagesTab } from './tabs/PackagesTab';
import { HotelsTab } from './tabs/HotelsTab';
import { VehiclesTab } from './tabs/VehiclesTab';
import { CertificatesTab } from './tabs/CertificatesTab';
import { InquiriesTab } from './tabs/InquiriesTab';
import { SupabaseTab } from './tabs/SupabaseTab';
import {
  LayoutDashboard,
  Building2,
  Package,
  Car,
  ShieldCheck,
  Users,
  Database,
  ArrowLeft,
  RotateCcw,
  Globe,
  Lock
} from 'lucide-react';

export const AdminLayout: React.FC = () => {
  const { setActiveTab, resetAllData, inquiries, language, companySettings } = useApp();
  const [currentAdminTab, setCurrentAdminTab] = useState<string>('dashboard');

  const newInquiries = inquiries.filter((i) => i.status === 'New').length;

  const tabs = [
    { id: 'dashboard', labelEn: 'Dashboard', labelUr: 'ڈیش بورڈ', labelAr: 'لوحة التحكم', icon: LayoutDashboard },
    { id: 'company', labelEn: 'Company Settings', labelUr: 'کمپنی سیٹنگز', labelAr: 'إعدادات المنشأة', icon: Building2 },
    { id: 'packages', labelEn: 'Packages', labelUr: 'عمرہ و حج پیکجز', labelAr: 'الباقات', icon: Package },
    { id: 'hotels', labelEn: 'Hotels', labelUr: 'فنادق و ہوٹلز', labelAr: 'الفنادق', icon: Building2 },
    { id: 'vehicles', labelEn: 'Fleet Transport', labelUr: 'ٹرانسپورٹ بیڑہ', labelAr: 'أسطول السيارات', icon: Car },
    { id: 'certificates', labelEn: 'Saudi Licenses', labelUr: 'حکومتی لائسنس و اسناد', labelAr: 'التراخيص والشهادات', icon: ShieldCheck },
    { id: 'inquiries', labelEn: 'Inquiries & Leads', labelUr: 'کسٹمر بکنگ لیڈز', labelAr: 'طلبات الحجز', icon: Users, badge: newInquiries },
    { id: 'supabase', labelEn: 'Supabase / Cloud DB', labelUr: 'سپابیس ڈیٹا بیس (SQL)', labelAr: 'قاعدة بيانات سوبابيس', icon: Database }
  ];

  const getLabel = (tab: (typeof tabs)[0]) => {
    if (language === 'ur') return tab.labelUr;
    if (language === 'ar') return tab.labelAr;
    return tab.labelEn;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Admin Top Bar */}
      <header className="sticky top-0 z-30 bg-slate-900 border-b border-amber-500/20 px-4 sm:px-6 py-3 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setActiveTab('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{language === 'ur' ? 'ویب سائٹ پر واپس جائیں' : 'Back to Website'}</span>
          </button>

          <div className="hidden sm:flex items-center gap-2 border-l border-slate-700 pl-3">
            <div className="w-7 h-7 rounded-lg overflow-hidden border border-amber-500/40 p-0.5 bg-slate-950">
              <img src={companySettings.logo} alt="" className="w-full h-full object-cover rounded" />
            </div>
            <span className="text-xs font-bold text-white uppercase font-serif">
              {companySettings.companyName}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <button
            onClick={() => {
              if (confirm('Are you sure you want to reset all records to the verified defaults?')) {
                resetAllData();
              }
            }}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/60 hover:text-rose-400 text-slate-400 border border-slate-700 transition"
            title="Reset to factory verified company records"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs">
            <Lock className="w-3.5 h-3.5" />
            <span>Super Admin</span>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Sidebar */}
        <aside className="w-full md:w-64 bg-slate-900/90 border-b md:border-b-0 md:border-r border-slate-800 p-4 space-y-1 shrink-0 overflow-x-auto md:overflow-visible flex md:flex-col gap-1 md:gap-0">
          <span className="hidden md:block text-[11px] font-bold text-slate-400 uppercase tracking-wider px-3 pb-2 pt-1">
            Navigation Menu
          </span>

          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentAdminTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setCurrentAdminTab(tab.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition cursor-pointer shrink-0 md:shrink ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{getLabel(tab)}</span>
                </div>
                {tab.badge && tab.badge > 0 ? (
                  <span
                    className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-slate-950 text-amber-400' : 'bg-rose-600 text-white'
                    }`}
                  >
                    {tab.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </aside>

        {/* Content Area */}
        <main className="flex-1 p-4 sm:p-8 max-w-7xl mx-auto w-full">
          {currentAdminTab === 'dashboard' && <AdminDashboard onSelectTab={setCurrentAdminTab} />}
          {currentAdminTab === 'company' && <CompanySettingsTab />}
          {currentAdminTab === 'packages' && <PackagesTab />}
          {currentAdminTab === 'hotels' && <HotelsTab />}
          {currentAdminTab === 'vehicles' && <VehiclesTab />}
          {currentAdminTab === 'certificates' && <CertificatesTab />}
          {currentAdminTab === 'inquiries' && <InquiriesTab />}
          {currentAdminTab === 'supabase' && <SupabaseTab />}
        </main>
      </div>
    </div>
  );
};
