import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { CertificateItem } from '../../../types';
import { ShieldCheck, Edit, ExternalLink, Plus, Eye, EyeOff, X } from 'lucide-react';

export const CertificatesTab: React.FC = () => {
  const { certificates, updateCertificate, addCertificate, setSelectedCertificate, t, language } = useApp();
  const [editingCert, setEditingCert] = useState<CertificateItem | null>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCert) return;
    updateCertificate(editingCert);
    setEditingCert(null);
  };

  return (
    <div className="space-y-6 animate-fade-in text-xs sm:text-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-serif">
            {language === 'ur' ? 'سعودی قانونی اسناد و رجسٹریشن مینجمنٹ' : 'Official Saudi Certificates & Licenses'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ur'
              ? 'یہاں حقیقی اور باضابطہ جاری کردہ وزارت تجارت، زکوٰۃ و ٹیکس اتھارٹی اور ٹرانسپورٹ لائسنس کا انتظام ہے۔'
              : 'Manage authentic Saudi CR, VAT, National Address Proof, and Transport Authority licenses.'}
          </p>
        </div>
      </div>

      {/* Grid of Certificates */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {certificates.map((cert) => (
          <div
            key={cert.id}
            className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition space-y-4 shadow-xl"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] text-amber-400 font-semibold">{t(cert.authority)}</span>
                  <h3 className="font-bold text-white text-sm line-clamp-1">{t(cert.title)}</h3>
                </div>
              </div>
              <button
                onClick={() => setEditingCert(cert)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                title="Edit Certificate Details"
              >
                <Edit className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
              <div className="sm:col-span-5 h-32 rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                <img
                  src={cert.documentImage}
                  alt=""
                  className="w-full h-full object-cover object-top cursor-pointer hover:scale-105 transition"
                  onClick={() => setSelectedCertificate(cert)}
                />
              </div>

              <div className="sm:col-span-7 space-y-2 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">Certificate / CR Number:</span>
                  <span className="font-mono font-bold text-slate-200">{cert.certificateNumber}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Issue / Validity:</span>
                  <span className="text-emerald-400 font-medium">{cert.issueDate} ({cert.expiryDate})</span>
                </div>
                <div className="pt-1 flex gap-2">
                  <button
                    onClick={() => setSelectedCertificate(cert)}
                    className="text-xs text-amber-400 hover:underline flex items-center gap-1"
                  >
                    <Eye className="w-3 h-3" />
                    <span>Preview Document</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Modal */}
      {editingCert && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-slate-900 border border-amber-500/40 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Edit Certificate Info</h3>
              <button onClick={() => setEditingCert(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Certificate Title</label>
                <input
                  type="text"
                  required
                  value={editingCert.title.en}
                  onChange={(e) =>
                    setEditingCert({
                      ...editingCert,
                      title: { ...editingCert.title, en: e.target.value, ur: e.target.value }
                    })
                  }
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Certificate / Registry Number</label>
                <input
                  type="text"
                  required
                  value={editingCert.certificateNumber}
                  onChange={(e) => setEditingCert({ ...editingCert, certificateNumber: e.target.value })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-amber-300 font-mono outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Image URL or Workspace Asset Path</label>
                <input
                  type="text"
                  required
                  value={editingCert.documentImage}
                  onChange={(e) => setEditingCert({ ...editingCert, documentImage: e.target.value })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Official Verification URL</label>
                <input
                  type="text"
                  value={editingCert.verificationUrl || ''}
                  onChange={(e) => setEditingCert({ ...editingCert, verificationUrl: e.target.value })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingCert(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
