import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { CompanySettings } from '../../../types';
import { Save, Building2, Phone, Mail, MapPin, ShieldCheck, Globe, Clock, Check } from 'lucide-react';

export const CompanySettingsTab: React.FC = () => {
  const { companySettings, updateCompanySettings, language } = useApp();
  const [formData, setFormData] = useState<CompanySettings>(companySettings);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompanySettings(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in text-xs sm:text-sm">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-serif">
            {language === 'ur' ? 'کمپنی و کاروباری پروفائل سیٹنگز' : language === 'ar' ? 'إعدادات المنشأة والملف التعريفي' : 'Company & Corporate Settings'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ur'
              ? 'یہاں کی گئی تمام تبدیلیاں پوری ویب سائٹ اور واٹس ایپ بٹنز پر خود بخود لاگو ہو جائیں گی۔'
              : 'Updates made here immediately propagate across the website and direct WhatsApp routes.'}
          </p>
        </div>

        <button
          type="submit"
          className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-2 cursor-pointer self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>{language === 'ur' ? 'سیٹنگز محفوظ کریں' : language === 'ar' ? 'حفظ الإعدادات' : 'Save Changes'}</span>
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Core Identity */}
        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-amber-400 font-semibold text-xs">
            <Building2 className="w-4 h-4" />
            <span>{language === 'ur' ? 'کمپنی کا باضابطہ نام و برانڈنگ' : 'Official Name & Taglines'}</span>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">
              Company Name (Official) *
            </label>
            <input
              type="text"
              required
              value={formData.companyName}
              onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:border-amber-400 outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Logo Image URL</label>
            <input
              type="text"
              value={formData.logo}
              onChange={(e) => setFormData({ ...formData, logo: e.target.value })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:border-amber-400 outline-none text-xs font-mono"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Tagline (Urdu)</label>
            <input
              type="text"
              value={formData.tagline.ur}
              onChange={(e) => setFormData({ ...formData, tagline: { ...formData.tagline, ur: e.target.value } })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:border-amber-400 outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Tagline (English)</label>
            <input
              type="text"
              value={formData.tagline.en}
              onChange={(e) => setFormData({ ...formData, tagline: { ...formData.tagline, en: e.target.value } })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:border-amber-400 outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Tagline (Arabic)</label>
            <input
              type="text"
              value={formData.tagline.ar}
              onChange={(e) => setFormData({ ...formData, tagline: { ...formData.tagline, ar: e.target.value } })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:border-amber-400 outline-none"
            />
          </div>
        </div>

        {/* Contact Numbers & Channels */}
        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-emerald-400 font-semibold text-xs">
            <Phone className="w-4 h-4" />
            <span>{language === 'ur' ? 'رابطہ نمبرز اور واٹس ایپ' : 'Contact Numbers & WhatsApp'}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-medium mb-1">WhatsApp Number *</label>
              <input
                type="text"
                required
                value={formData.whatsapp}
                onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-emerald-300 font-mono focus:border-amber-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Official Phone *</label>
              <input
                type="text"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:border-amber-400 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Official Email *</label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:border-amber-400 outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Emergency 24/7 Number</label>
            <input
              type="text"
              value={formData.emergencyContact}
              onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:border-amber-400 outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Google Maps URL</label>
            <input
              type="text"
              value={formData.googleMapsUrl}
              onChange={(e) => setFormData({ ...formData, googleMapsUrl: e.target.value })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs font-mono focus:border-amber-400 outline-none"
            />
          </div>
        </div>

        {/* Saudi Official Registrations */}
        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-amber-400 font-semibold text-xs">
            <ShieldCheck className="w-4 h-4" />
            <span>{language === 'ur' ? 'سعودی قانونی رجسٹریشن نمبرز' : 'Official Saudi Registry Numbers'}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-medium mb-1">Commercial Registration (CR)</label>
              <input
                type="text"
                value={formData.crNumber}
                onChange={(e) => setFormData({ ...formData, crNumber: e.target.value })}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-amber-300 font-mono focus:border-amber-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">VAT Tax Registration</label>
              <input
                type="text"
                value={formData.vatNumber}
                onChange={(e) => setFormData({ ...formData, vatNumber: e.target.value })}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-emerald-300 font-mono focus:border-amber-400 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-medium mb-1">National Address Short Code</label>
              <input
                type="text"
                value={formData.nationalAddressShort}
                onChange={(e) => setFormData({ ...formData, nationalAddressShort: e.target.value })}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:border-amber-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Transport License (TGA)</label>
              <input
                type="text"
                value={formData.transportLicenseNumber}
                onChange={(e) => setFormData({ ...formData, transportLicenseNumber: e.target.value })}
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:border-amber-400 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Physical Address in Makkah */}
        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-sky-400 font-semibold text-xs">
            <MapPin className="w-4 h-4" />
            <span>{language === 'ur' ? 'ہیڈ آفس مکہ مکرمہ کا پتہ' : 'Headquarters Address'}</span>
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Address (Urdu)</label>
            <input
              type="text"
              value={formData.officeAddress.ur}
              onChange={(e) => setFormData({ ...formData, officeAddress: { ...formData.officeAddress, ur: e.target.value } })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:border-amber-400 outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Address (English)</label>
            <input
              type="text"
              value={formData.officeAddress.en}
              onChange={(e) => setFormData({ ...formData, officeAddress: { ...formData.officeAddress, en: e.target.value } })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:border-amber-400 outline-none"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-medium mb-1">Address (Arabic)</label>
            <input
              type="text"
              value={formData.officeAddress.ar}
              onChange={(e) => setFormData({ ...formData, officeAddress: { ...formData.officeAddress, ar: e.target.value } })}
              className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:border-amber-400 outline-none"
            />
          </div>
        </div>
      </div>
    </form>
  );
};
