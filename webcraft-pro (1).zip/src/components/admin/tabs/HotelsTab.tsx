import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { HotelItem } from '../../../types';
import { Plus, Edit, Trash2, Eye, EyeOff, Star, X, Building2 } from 'lucide-react';

export const HotelsTab: React.FC = () => {
  const { hotels, addHotel, updateHotel, deleteHotel, formatPrice, t, language } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingHotel, setEditingHotel] = useState<HotelItem | null>(null);

  const initialForm: HotelItem = {
    id: '',
    name: { en: '', ur: '', ar: '' },
    city: 'Makkah',
    area: { en: 'Central Area', ur: 'مرکزی علاقہ', ar: 'المنطقة المركزية' },
    stars: 5,
    distanceFromHaramMeters: 50,
    distanceText: { en: '50m from Haram Courtyard', ur: 'حرم کے صحن سے 50 میٹر', ar: '50 م من ساحة الحرم' },
    pricePerNightSar: 800,
    mainImage: 'https://images.unsplash.com/photo-1565552684305-7e77a28e9324?auto=format&fit=crop&w=1000&q=80',
    gallery: [],
    amenities: ['Buffet Breakfast', 'Free High Speed WiFi', 'Direct Haram Audio'],
    description: { en: '5-Star luxury hotel in front of the Holy Mosque.', ur: 'حرم شریف کے سامنے فائیو اسٹار ہوٹل۔', ar: 'فندق 5 نجوم راقي أمام الحرم مباشرة.' },
    featured: true,
    active: true
  };

  const [formData, setFormData] = useState<HotelItem>(initialForm);

  const handleOpenAdd = () => {
    setEditingHotel(null);
    setFormData({ ...initialForm, id: `hotel-${Date.now().toString(36)}` });
    setModalOpen(true);
  };

  const handleOpenEdit = (hotel: HotelItem) => {
    setEditingHotel(hotel);
    setFormData(hotel);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingHotel) {
      updateHotel(formData);
    } else {
      addHotel(formData);
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-6 animate-fade-in text-xs sm:text-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-serif">
            {language === 'ur' ? 'ہوٹلز مینجمنٹ سسٹم' : 'Hotels & Accommodations Manager'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ur' ? 'مکہ و مدینہ کے ہوٹلز، کعبہ ویو کمرے اور قیمتیں کنٹرول کریں۔' : 'Manage hotel listings, proximity from Haram, and pricing.'}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'ur' ? 'نیا ہوٹل شامل کریں' : 'Add New Hotel'}</span>
        </button>
      </div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Hotel</th>
                <th className="py-3 px-4">City</th>
                <th className="py-3 px-4">Rating</th>
                <th className="py-3 px-4">Distance from Haram</th>
                <th className="py-3 px-4">Price / Night</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-slate-300">
              {hotels.map((hotel) => (
                <tr key={hotel.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={hotel.mainImage}
                        alt=""
                        className="w-10 h-10 rounded-lg object-cover bg-slate-950 shrink-0"
                      />
                      <span className="font-semibold text-white block line-clamp-1">{t(hotel.name)}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-medium">{hotel.city}</td>
                  <td className="py-3 px-4 font-mono font-semibold text-amber-400 flex items-center gap-1">
                    <Star className="w-3 h-3 fill-amber-400" />
                    <span>{hotel.stars}★</span>
                  </td>
                  <td className="py-3 px-4 text-slate-300">{t(hotel.distanceText)}</td>
                  <td className="py-3 px-4 font-mono font-bold text-amber-400">
                    {formatPrice(hotel.pricePerNightSar)}
                  </td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => updateHotel({ ...hotel, active: !hotel.active })}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 ${
                        hotel.active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                      }`}
                    >
                      {hotel.active ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      <span>{hotel.active ? 'Active' : 'Hidden'}</span>
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(hotel)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                        title="Edit"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deleteHotel(hotel.id)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {editingHotel ? 'Edit Hotel' : 'Add New Hotel'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Hotel Name (English) *</label>
                <input
                  type="text"
                  required
                  value={formData.name.en}
                  onChange={(e) => setFormData({ ...formData, name: { ...formData.name, en: e.target.value, ur: e.target.value } })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Hotel Name (Urdu)</label>
                <input
                  type="text"
                  value={formData.name.ur}
                  onChange={(e) => setFormData({ ...formData, name: { ...formData.name, ur: e.target.value } })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">City</label>
                  <select
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value as any })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                  >
                    <option value="Makkah">Makkah</option>
                    <option value="Madinah">Madinah</option>
                    <option value="Jeddah">Jeddah</option>
                    <option value="Riyadh">Riyadh</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Stars</label>
                  <select
                    value={formData.stars}
                    onChange={(e) => setFormData({ ...formData, stars: Number(e.target.value) })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                  >
                    <option value={5}>5 Stars</option>
                    <option value={4}>4 Stars</option>
                    <option value={3}>3 Stars</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Price/Night (SAR)</label>
                  <input
                    type="number"
                    required
                    value={formData.pricePerNightSar}
                    onChange={(e) => setFormData({ ...formData, pricePerNightSar: Number(e.target.value) })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Distance Text (e.g. 50m from Haram)</label>
                <input
                  type="text"
                  value={formData.distanceText.en}
                  onChange={(e) => setFormData({ ...formData, distanceText: { ...formData.distanceText, en: e.target.value, ur: e.target.value } })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Image URL</label>
                <input
                  type="text"
                  value={formData.mainImage}
                  onChange={(e) => setFormData({ ...formData, mainImage: e.target.value })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold"
                >
                  Save Hotel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
