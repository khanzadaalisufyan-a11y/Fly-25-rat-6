import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { InquiryItem } from '../../../types';
import { MessageCircle, Mail, Phone, Calendar, Users, Trash2, Edit3, CheckCircle2, Clock } from 'lucide-react';

export const InquiriesTab: React.FC = () => {
  const { inquiries, updateInquiryStatus, deleteInquiry, language } = useApp();
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [selectedInquiry, setSelectedInquiry] = useState<InquiryItem | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [newStatus, setNewStatus] = useState<InquiryItem['status']>('New');

  const filtered = inquiries.filter((inq) => {
    if (filterStatus === 'All') return true;
    return inq.status === filterStatus;
  });

  const openStatusEditor = (inq: InquiryItem) => {
    setSelectedInquiry(inq);
    setAdminNote(inq.privateAdminNotes || '');
    setNewStatus(inq.status);
  };

  const saveStatusChanges = () => {
    if (!selectedInquiry) return;
    updateInquiryStatus(selectedInquiry.id, newStatus, adminNote);
    setSelectedInquiry(null);
  };

  const getWhatsAppCustomerLink = (inq: InquiryItem) => {
    const cleanNumber = inq.customerWhatsapp.replace(/[^0-9]/g, '');
    const msg = `Salam ${inq.customerName}, This is FLY WITH HAMZA TRAVAL AND TOURS regarding your inquiry for ${inq.targetItemTitle || inq.serviceType}.`;
    return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(msg)}`;
  };

  return (
    <div className="space-y-6 animate-fade-in text-xs sm:text-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-serif">
            {language === 'ur' ? 'کسٹمر بکنگ درخواستیں و لیڈز مینجمنٹ' : 'Inquiries & CRM Customer Leads'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ur'
              ? 'ویب سائٹ سے آنے والی تمام کسٹمر درخواستیں یہاں موجود ہیں؛ واٹس ایپ پر 1-کلک رابطہ کریں۔'
              : 'Review leads from online booking forms and calculators with direct WhatsApp follow-up.'}
          </p>
        </div>

        {/* Status Filters */}
        <div className="flex flex-wrap items-center gap-1.5">
          {['All', 'New', 'Contacted', 'Quoted', 'Confirmed', 'Cancelled'].map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                filterStatus === status
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {/* Leads Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Service / Package</th>
                <th className="py-3 px-4">Details</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-slate-300">
              {filtered.map((inq) => (
                <tr key={inq.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-3 px-4">
                    <span className="font-semibold text-white block">{inq.customerName}</span>
                    <span className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                      <Phone className="w-3 h-3 text-emerald-400" />
                      {inq.customerWhatsapp}
                    </span>
                    <span className="text-[10px] text-slate-500">{inq.country}</span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/15 text-amber-300 inline-block mb-1">
                      {inq.serviceType}
                    </span>
                    <div className="font-medium text-slate-200 line-clamp-1 max-w-[200px]">
                      {inq.targetItemTitle}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-[11px]">
                    <div className="flex items-center gap-2 text-slate-300">
                      <span>{inq.personsCount} Pax</span>
                      {inq.travelDate && <span>• {inq.travelDate}</span>}
                    </div>
                    {inq.message && (
                      <div className="text-slate-400 line-clamp-1 max-w-[220px] text-[10px] mt-0.5">
                        "{inq.message}"
                      </div>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        inq.status === 'New'
                          ? 'bg-rose-500/20 text-rose-400'
                          : inq.status === 'Contacted'
                          ? 'bg-sky-500/20 text-sky-400'
                          : inq.status === 'Quoted'
                          ? 'bg-amber-500/20 text-amber-300'
                          : inq.status === 'Confirmed'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {inq.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-[11px] text-slate-500">
                    {new Date(inq.createdAt).toLocaleDateString()}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <a
                        href={getWhatsAppCustomerLink(inq)}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 rounded-lg bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600 hover:text-white transition"
                        title="Chat on WhatsApp"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                      </a>
                      <button
                        onClick={() => openStatusEditor(inq)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                        title="Update Status / Notes"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deleteInquiry(inq.id)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center py-8 text-slate-500 text-xs">
                    No inquiries found for this status filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Status & Notes Modal */}
      {selectedInquiry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white">
              Manage Inquiry #{selectedInquiry.id}
            </h3>

            <div>
              <label className="block text-slate-400 text-xs mb-1">Status</label>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value as any)}
                className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none text-xs"
              >
                <option value="New">New</option>
                <option value="Pending">Pending</option>
                <option value="Contacted">Contacted</option>
                <option value="Quoted">Quoted</option>
                <option value="Confirmed">Confirmed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 text-xs mb-1">Private Internal Notes</label>
              <textarea
                rows={3}
                value={adminNote}
                onChange={(e) => setAdminNote(e.target.value)}
                placeholder="Add notes about quotation sent, preferences discussed..."
                className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none text-xs"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedInquiry(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={saveStatusChanges}
                className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
