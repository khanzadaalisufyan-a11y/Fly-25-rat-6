import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { PackageItem } from '../../../types';
import { Plus, Edit, Trash2, Eye, EyeOff, Check, X, Building2, Car } from 'lucide-react';

export const PackagesTab: React.FC = () => {
  const { packages, addPackage, updatePackage, deletePackage, formatPrice, t, language } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingPkg, setEditingPkg] = useState<PackageItem | null>(null);

  const initialForm: PackageItem = {
    id: '',
    title: { en: '', ur: '', ar: '' },
    category: 'umrah',
    badge: 'Popular',
    durationDays: 10,
    durationNights: 9,
    priceSar: 3500,
    discountPercent: 0,
    destination: { en: 'Makkah & Madinah', ur: 'مکہ و مدینہ', ar: 'مكة والمدينة' },
    makkahHotel: { en: 'Swissotel Makkah', ur: 'سوئس ہوٹل مکہ', ar: 'سويس أوتيل مكة' },
    makkahHotelDistance: '100 Meters',
    madinahHotel: { en: 'Anwar Al Madinah', ur: 'انوار المدینہ', ar: 'أنوار المدينة' },
    madinahHotelDistance: '150 Meters',
    transportType: { en: 'GMC Yukon / Coaster', ur: 'جی ایم سی / کوسٹر', ar: 'جي إم سي / كوستر' },
    featured: true,
    active: true,
    mainImage: 'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=1000&q=80',
    gallery: [],
    included: [
      { en: 'Hotel Stay with Breakfast', ur: 'ہوٹل قیام مع ناشتہ', ar: 'إقامة مع الإفطار' },
      { en: 'Airport Transfers', ur: 'ایئرپورٹ ٹرانسفر', ar: 'التوصيل من المطار' }
    ],
    excluded: [
      { en: 'Flight Tickets', ur: 'فلائٹ ٹکٹ', ar: 'تذاكر الطيران' }
    ],
    itinerary: [],
    departureDates: ['Weekly Departures']
  };

  const [formData, setFormData] = useState<PackageItem>(initialForm);

  const handleOpenAdd = () => {
    setEditingPkg(null);
    setFormData({
      ...initialForm,
      id: `pkg-${Date.now().toString(36)}`
    });
    setModalOpen(true);
  };

  const handleOpenEdit = (pkg: PackageItem) => {
    setEditingPkg(pkg);
    setFormData(pkg);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingPkg) {
      updatePackage(formData);
    } else {
      addPackage(formData);
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-6 animate-fade-in text-xs sm:text-sm">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-serif">
            {language === 'ur' ? 'عمرہ و حج پیکیجز مینجمنٹ' : language === 'ar' ? 'إدارة باقات العمرة والحج' : 'Pilgrimage Packages Manager'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ur' ? 'یہاں سے آپ نئے پیکیجز شامل، تبدیل یا حذف کر سکتے ہیں۔' : 'Add, edit, feature, and price pilgrimage packages.'}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'ur' ? 'نیا پیکیج شامل کریں' : 'Add New Package'}</span>
        </button>
      </div>

      {/* Table */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Package</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Duration</th>
                <th className="py-3 px-4">Price (SAR)</th>
                <th className="py-3 px-4">Hotels</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-slate-300">
              {packages.map((pkg) => (
                <tr key={pkg.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={pkg.mainImage}
                        alt=""
                        className="w-10 h-10 rounded-lg object-cover bg-slate-950 shrink-0"
                      />
                      <div>
                        <span className="font-semibold text-white block line-clamp-1">{t(pkg.title)}</span>
                        <span className="text-[10px] text-amber-400">{pkg.badge}</span>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4 capitalize font-medium">{pkg.category}</td>
                  <td className="py-3 px-4 font-mono">{pkg.durationDays}D / {pkg.durationNights}N</td>
                  <td className="py-3 px-4 font-mono font-bold text-amber-400">
                    {formatPrice(pkg.priceSar)}
                  </td>
                  <td className="py-3 px-4 text-[11px]">
                    <div className="truncate max-w-[150px]">{t(pkg.makkahHotel)}</div>
                    <div className="truncate max-w-[150px] text-slate-500">{t(pkg.madinahHotel)}</div>
                  </td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => updatePackage({ ...pkg, active: !pkg.active })}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 ${
                        pkg.active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                      }`}
                    >
                      {pkg.active ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      <span>{pkg.active ? 'Active' : 'Hidden'}</span>
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(pkg)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                        title="Edit"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deletePackage(pkg.id)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add / Edit */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-amber-500/40 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {editingPkg ? 'Edit Package' : 'Create New Package'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Title (Urdu) *</label>
                <input
                  type="text"
                  required
                  value={formData.title.ur}
                  onChange={(e) => setFormData({ ...formData, title: { ...formData.title, ur: e.target.value } })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Title (English) *</label>
                <input
                  type="text"
                  required
                  value={formData.title.en}
                  onChange={(e) => setFormData({ ...formData, title: { ...formData.title, en: e.target.value } })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Title (Arabic)</label>
                <input
                  type="text"
                  value={formData.title.ar}
                  onChange={(e) => setFormData({ ...formData, title: { ...formData.title, ar: e.target.value } })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                  >
                    <option value="umrah">Umrah</option>
                    <option value="hajj">Hajj</option>
                    <option value="family">Family</option>
                    <option value="ziyarat">Ziyarat</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Badge</label>
                  <select
                    value={formData.badge}
                    onChange={(e) => setFormData({ ...formData, badge: e.target.value as any })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                  >
                    <option value="VIP">VIP</option>
                    <option value="Popular">Popular</option>
                    <option value="Family">Family</option>
                    <option value="Economy">Economy</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Price (SAR) *</label>
                  <input
                    type="number"
                    required
                    value={formData.priceSar}
                    onChange={(e) => setFormData({ ...formData, priceSar: Number(e.target.value) })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Days / Nights</label>
                  <div className="flex gap-1">
                    <input
                      type="number"
                      placeholder="D"
                      value={formData.durationDays}
                      onChange={(e) => setFormData({ ...formData, durationDays: Number(e.target.value) })}
                      className="w-1/2 p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none font-mono"
                    />
                    <input
                      type="number"
                      placeholder="N"
                      value={formData.durationNights}
                      onChange={(e) => setFormData({ ...formData, durationNights: Number(e.target.value) })}
                      className="w-1/2 p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none font-mono"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Image URL</label>
                <input
                  type="text"
                  value={formData.mainImage}
                  onChange={(e) => setFormData({ ...formData, mainImage: e.target.value })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none text-xs font-mono"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Makkah Hotel</label>
                  <input
                    type="text"
                    value={formData.makkahHotel.en}
                    onChange={(e) => setFormData({ ...formData, makkahHotel: { ...formData.makkahHotel, en: e.target.value, ur: e.target.value } })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Madinah Hotel</label>
                  <input
                    type="text"
                    value={formData.madinahHotel.en}
                    onChange={(e) => setFormData({ ...formData, madinahHotel: { ...formData.madinahHotel, en: e.target.value, ur: e.target.value } })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  Save Package
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
