import React, { useState } from 'react';
import { useApp } from '../../../context/AppContext';
import { VehicleItem } from '../../../types';
import { Plus, Edit, Trash2, Eye, EyeOff, Car, Users, Luggage, X } from 'lucide-react';

export const VehiclesTab: React.FC = () => {
  const { vehicles, addVehicle, updateVehicle, deleteVehicle, formatPrice, t, language } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingVeh, setEditingVeh] = useState<VehicleItem | null>(null);

  const initialForm: VehicleItem = {
    id: '',
    name: { en: '', ur: '', ar: '' },
    category: 'SUV',
    modelYear: '2025/2026',
    passengerCapacity: 7,
    luggageCapacity: 6,
    features: [
      { en: 'Luxury leather seats', ur: 'لگژری چمڑے کی سیٹیں', ar: 'مقاعد جلدية فاخرة' },
      { en: 'High power AC', ur: 'مضبوط ایئر کنڈیشننگ', ar: 'تكييف قوي' }
    ],
    ratePerRouteSar: {
      makkahToMadinah: 900,
      jeddahAirportToMakkah: 400,
      madinahAirportToMadinah: 250,
      ziyaratMakkah: 350,
      ziyaratMadinah: 300
    },
    mainImage: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1000&q=80',
    featured: true,
    active: true
  };

  const [formData, setFormData] = useState<VehicleItem>(initialForm);

  const handleOpenAdd = () => {
    setEditingVeh(null);
    setFormData({ ...initialForm, id: `veh-${Date.now().toString(36)}` });
    setModalOpen(true);
  };

  const handleOpenEdit = (veh: VehicleItem) => {
    setEditingVeh(veh);
    setFormData(veh);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingVeh) {
      updateVehicle(formData);
    } else {
      addVehicle(formData);
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-6 animate-fade-in text-xs sm:text-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
        <div>
          <h2 className="text-xl font-bold text-white font-serif">
            {language === 'ur' ? 'گاڑیاں و ٹرانسپورٹ بیڑہ مینجمنٹ' : 'Vehicles & Chauffeur Fleet Manager'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ur' ? 'گاڑیاں، گنجائش اور روٹ کے نرخ تبدیل کریں۔' : 'Manage vehicles, passenger capacities, and transfer route rates.'}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>{language === 'ur' ? 'نئی گاڑی شامل کریں' : 'Add New Vehicle'}</span>
        </button>
      </div>

      <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Vehicle</th>
                <th className="py-3 px-4">Category / Model</th>
                <th className="py-3 px-4">Capacity</th>
                <th className="py-3 px-4">Jeddah Airport &rarr; Makkah</th>
                <th className="py-3 px-4">Makkah &rarr; Madinah</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-slate-300">
              {vehicles.map((veh) => (
                <tr key={veh.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={veh.mainImage}
                        alt=""
                        className="w-10 h-10 rounded-lg object-cover bg-slate-950 shrink-0"
                      />
                      <span className="font-semibold text-white block line-clamp-1">{t(veh.name)}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-medium text-slate-200">{veh.category}</span>
                    <span className="text-[10px] text-slate-500 block">Yr: {veh.modelYear}</span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2 text-slate-300">
                      <span>{veh.passengerCapacity} Seats</span>
                      <span>• {veh.luggageCapacity} Bags</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-amber-400">
                    {formatPrice(veh.ratePerRouteSar.jeddahAirportToMakkah)}
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-emerald-400">
                    {formatPrice(veh.ratePerRouteSar.makkahToMadinah)}
                  </td>
                  <td className="py-3 px-4">
                    <button
                      onClick={() => updateVehicle({ ...veh, active: !veh.active })}
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 ${
                        veh.active ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                      }`}
                    >
                      {veh.active ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      <span>{veh.active ? 'Active' : 'Hidden'}</span>
                    </button>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(veh)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                        title="Edit"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => deleteVehicle(veh.id)}
                        className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">
                {editingVeh ? 'Edit Vehicle' : 'Add New Vehicle'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">Vehicle Name (English) *</label>
                <input
                  type="text"
                  required
                  value={formData.name.en}
                  onChange={(e) => setFormData({ ...formData, name: { ...formData.name, en: e.target.value, ur: e.target.value } })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none"
                  >
                    <option value="SUV">SUV (e.g. Yukon)</option>
                    <option value="Van">Van (e.g. HiAce)</option>
                    <option value="Sedan">Sedan (e.g. Camry)</option>
                    <option value="Bus">Luxury Bus</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Passengers (Seats)</label>
                  <input
                    type="number"
                    value={formData.passengerCapacity}
                    onChange={(e) => setFormData({ ...formData, passengerCapacity: Number(e.target.value) })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Luggage Capacity</label>
                  <input
                    type="number"
                    value={formData.luggageCapacity}
                    onChange={(e) => setFormData({ ...formData, luggageCapacity: Number(e.target.value) })}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Jeddah Airport to Makkah (SAR)</label>
                  <input
                    type="number"
                    value={formData.ratePerRouteSar.jeddahAirportToMakkah}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        ratePerRouteSar: { ...formData.ratePerRouteSar, jeddahAirportToMakkah: Number(e.target.value) }
                      })
                    }
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Makkah to Madinah (SAR)</label>
                  <input
                    type="number"
                    value={formData.ratePerRouteSar.makkahToMadinah}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        ratePerRouteSar: { ...formData.ratePerRouteSar, makkahToMadinah: Number(e.target.value) }
                      })
                    }
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Vehicle Image URL</label>
                <input
                  type="text"
                  value={formData.mainImage}
                  onChange={(e) => setFormData({ ...formData, mainImage: e.target.value })}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono text-xs outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold"
                >
                  Save Vehicle
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
