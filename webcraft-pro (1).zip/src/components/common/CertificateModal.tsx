import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, ExternalLink, ShieldCheck, Download, Award } from 'lucide-react';

export const CertificateModal: React.FC = () => {
  const { selectedCertificate, setSelectedCertificate, t, language } = useApp();

  if (!selectedCertificate) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl shadow-amber-500/10 flex flex-col">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between p-4 bg-slate-900/95 backdrop-blur border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-medium">
                  {language === 'ur' ? 'حکومتی تصدیق شدہ' : language === 'ar' ? 'معتمد رسمياً' : 'Official Verified'}
                </span>
                <span className="text-xs text-slate-400"># {selectedCertificate.certificateNumber}</span>
              </div>
              <h3 className="text-lg font-bold text-white leading-tight">
                {t(selectedCertificate.title)}
              </h3>
            </div>
          </div>
          <button
            onClick={() => setSelectedCertificate(null)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Document Preview */}
          <div className="lg:col-span-7 bg-slate-950 p-2 rounded-xl border border-slate-800 flex flex-col items-center justify-center">
            <div className="relative w-full rounded-lg overflow-hidden group">
              <img
                src={selectedCertificate.documentImage}
                alt={t(selectedCertificate.title)}
                className="w-full h-auto object-contain max-h-[60vh] rounded shadow-lg transition-transform duration-300 group-hover:scale-[1.02]"
              />
            </div>
            <div className="mt-3 w-full flex items-center justify-between text-xs text-slate-400 px-2">
              <span>{language === 'ur' ? 'اصل دستاویز کی تصدیق شدہ نقل' : language === 'ar' ? 'صورة معتمدة من الوثيقة الأصلية' : 'Verified Original Document Copy'}</span>
              <a
                href={selectedCertificate.documentImage}
                target="_blank"
                rel="noreferrer"
                download
                className="flex items-center gap-1 text-amber-400 hover:underline"
              >
                <Download className="w-3.5 h-3.5" />
                {language === 'ur' ? 'ڈاؤن لوڈ' : language === 'ar' ? 'تحميل' : 'Download'}
              </a>
            </div>
          </div>

          {/* Details & Verification Data */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-3 text-sm">
              <div>
                <span className="text-xs text-slate-400 block">
                  {language === 'ur' ? 'جاری کنندہ ادارہ' : language === 'ar' ? 'الجهة المصدرة' : 'Issuing Authority'}
                </span>
                <span className="font-semibold text-amber-300 flex items-center gap-1.5 mt-0.5">
                  <Award className="w-4 h-4 text-amber-400 shrink-0" />
                  {t(selectedCertificate.authority)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700/50">
                <div>
                  <span className="text-xs text-slate-400 block">
                    {language === 'ur' ? 'تاریخِ اجراء' : language === 'ar' ? 'تاريخ الإصدار' : 'Issue Date'}
                  </span>
                  <span className="font-medium text-slate-200">{selectedCertificate.issueDate}</span>
                </div>
                <div>
                  <span className="text-xs text-slate-400 block">
                    {language === 'ur' ? 'حیثیت / میعاد' : language === 'ar' ? 'الحالة / الصلاحية' : 'Status / Expiry'}
                  </span>
                  <span className="font-medium text-emerald-400">{selectedCertificate.expiryDate}</span>
                </div>
              </div>

              {selectedCertificate.qrValue && (
                <div className="pt-2 border-t border-slate-700/50">
                  <span className="text-xs text-slate-400 block">
                    {language === 'ur' ? 'قومی شناختی / تصدیقی کوڈ' : language === 'ar' ? 'رمز التحقق الرقمي' : 'Verification Registry Code'}
                  </span>
                  <code className="mt-1 block font-mono text-xs bg-slate-950 px-2 py-1 rounded text-amber-300 border border-slate-800">
                    {selectedCertificate.qrValue}
                  </code>
                </div>
              )}
            </div>

            <div className="text-xs text-slate-300 leading-relaxed bg-slate-800/30 p-3.5 rounded-xl border border-slate-700/40">
              <p>{t(selectedCertificate.description)}</p>
            </div>

            {selectedCertificate.verificationUrl && (
              <a
                href={selectedCertificate.verificationUrl}
                target="_blank"
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-medium text-sm transition shadow-lg shadow-emerald-900/30"
              >
                <span>
                  {language === 'ur' ? 'سرکاری پورٹل پر تصدیق دیکھیں' : language === 'ar' ? 'التحقق عبر المنصة الحكومية الرسمية' : 'Verify on Saudi Official Portal'}
                </span>
                <ExternalLink className="w-4 h-4" />
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
