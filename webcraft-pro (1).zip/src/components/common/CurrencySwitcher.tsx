import React from 'react';
import { useApp } from '../../context/AppContext';
import { Currency } from '../../types';
import { Coins } from 'lucide-react';

export const CurrencySwitcher: React.FC = () => {
  const { currency, setCurrency } = useApp();

  const currencies: { code: Currency; label: string }[] = [
    { code: 'SAR', label: 'SAR (ريال)' },
    { code: 'PKR', label: 'PKR (روپے)' },
    { code: 'USD', label: 'USD ($)' },
    { code: 'AED', label: 'AED (درهم)' }
  ];

  return (
    <div className="flex items-center gap-1 bg-slate-900/90 border border-slate-700/60 rounded-full p-1 text-xs">
      <div className="px-2 text-emerald-400">
        <Coins className="w-3.5 h-3.5" />
      </div>
      <select
        value={currency}
        onChange={(e) => setCurrency(e.target.value as Currency)}
        className="bg-transparent text-slate-200 font-medium py-0.5 px-2 outline-none cursor-pointer text-xs"
      >
        {currencies.map((c) => (
          <option key={c.code} value={c.code} className="bg-slate-900 text-slate-100">
            {c.label}
          </option>
        ))}
      </select>
    </div>
  );
};
