import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Send, MessageCircle, Calendar, Users, Phone, Mail, User, MapPin } from 'lucide-react';
import confetti from 'canvas-confetti';

export const InquiryModal: React.FC = () => {
  const { inquiryModalItem, closeInquiryModal, addInquiry, getWhatsAppLink, language } = useApp();

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [country, setCountry] = useState(language === 'ur' ? 'پاکستان' : language === 'ar' ? 'المملكة العربية السعودية' : 'Saudi Arabia');
  const [persons, setPersons] = useState(2);
  const [travelDate, setTravelDate] = useState('');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  if (!inquiryModalItem) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !whatsapp) return;

    addInquiry({
      customerName: fullName,
      customerEmail: email || 'inquiry@flywithhamzatravel.com',
      customerPhone: phone || whatsapp,
      customerWhatsapp: whatsapp,
      serviceType: inquiryModalItem.service,
      targetItemTitle: inquiryModalItem.title,
      country,
      personsCount: Number(persons) || 1,
      travelDate,
      message: notes || `Interested in ${inquiryModalItem.title || inquiryModalItem.service}`,
      status: 'New'
    });

    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.6 }
    });

    setSubmitted(true);
  };

  const handleWhatsAppDirect = () => {
    const msg = language === 'ur'
      ? `السلام علیکم! میرا نام ${fullName || 'گاہک'} ہے۔ میں FLY WITH HAMZA TRAVAL AND TOURS کے ${inquiryModalItem.title || inquiryModalItem.service} کے بارے میں بکنگ کی تفصیلات چاہتا ہوں۔ افراد: ${persons}، تاریخ: ${travelDate || 'جلد'}`
      : language === 'ar'
      ? `السلام عليكم، أنا ${fullName || 'العميل'}. أود الاستفسار والحجز لـ ${inquiryModalItem.title || inquiryModalItem.service}. عدد الأشخاص: ${persons}. التاريخ: ${travelDate || 'قريباً'}`
      : `Hello FLY WITH HAMZA TRAVAL AND TOURS, My name is ${fullName || 'Customer'}. I would like to inquire/book: ${inquiryModalItem.title || inquiryModalItem.service}. Persons: ${persons}, Travel Date: ${travelDate || 'Upcoming'}.`;

    window.open(getWhatsAppLink(msg), '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl p-6 overflow-hidden">
        {/* Background glow */}
        <div className="absolute -top-20 -right-20 w-44 h-44 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <span className="text-xs text-amber-400 font-semibold uppercase tracking-wider">
              {inquiryModalItem.service}
            </span>
            <h3 className="text-lg font-bold text-white">
              {inquiryModalItem.title || (language === 'ur' ? 'آن لائن بکنگ و معلومات' : language === 'ar' ? 'طلب حجز واستفسار' : 'Book / Request Quote')}
            </h3>
          </div>
          <button
            onClick={closeInquiryModal}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40">
              <Send className="w-8 h-8" />
            </div>
            <h4 className="text-xl font-bold text-white">
              {language === 'ur' ? 'درخواست کامیابی سے موصول ہو گئی!' : language === 'ar' ? 'تم استلام طلبكم بنجاح!' : 'Inquiry Submitted Successfully!'}
            </h4>
            <p className="text-sm text-slate-300 max-w-sm mx-auto">
              {language === 'ur'
                ? 'ہمارے سعودی کنسلٹنٹ آپ سے جلد از جلد رابطہ کریں گے۔ تیز ترین جواب کے لیے براہ راست واٹس ایپ پر بات کریں۔'
                : language === 'ar'
                ? 'سيتواصل معكم أحد مستشارينا في أقرب وقت. للتواصل الفوري يمكنكم المتابعة عبر الواتساب.'
                : 'Our travel consultant will review your request and get back shortly. You can also chat with us directly on WhatsApp.'}
            </p>
            <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={handleWhatsAppDirect}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center justify-center gap-2 transition"
              >
                <MessageCircle className="w-5 h-5" />
                <span>{language === 'ur' ? 'واٹس ایپ پر رابطہ کریں' : language === 'ar' ? 'متابعة عبر الواتساب' : 'Chat on WhatsApp'}</span>
              </button>
              <button
                onClick={closeInquiryModal}
                className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium transition"
              >
                {language === 'ur' ? 'بند کریں' : language === 'ar' ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-sm">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {language === 'ur' ? 'مکمل نام *' : language === 'ar' ? 'الاسم الكامل *' : 'Full Name *'}
              </label>
              <div className="relative">
                <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder={language === 'ur' ? 'اپنا نام درج کریں' : language === 'ar' ? 'أدخل اسمك الكريم' : 'Enter your name'}
                  className="w-full pl-9 pr-3 py-2 bg-slate-950/70 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {language === 'ur' ? 'واٹس ایپ نمبر *' : language === 'ar' ? 'رقم الواتساب *' : 'WhatsApp Number *'}
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-2.5 w-4 h-4 text-emerald-400" />
                  <input
                    type="tel"
                    required
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    placeholder="+966 5x xxx xxxx"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950/70 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {language === 'ur' ? 'ای میل ایڈریس' : language === 'ar' ? 'البريد الإلكتروني' : 'Email Address'}
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full pl-9 pr-3 py-2 bg-slate-950/70 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {language === 'ur' ? 'ملک' : language === 'ar' ? 'الدولة' : 'Country'}
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-950/70 border border-slate-700 rounded-xl text-white focus:border-amber-400 focus:outline-none text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {language === 'ur' ? 'افراد کی تعداد' : language === 'ar' ? 'عدد الأشخاص' : 'Persons'}
                </label>
                <div className="relative">
                  <Users className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={persons}
                    onChange={(e) => setPersons(Number(e.target.value))}
                    className="w-full pl-9 pr-3 py-2 bg-slate-950/70 border border-slate-700 rounded-xl text-white focus:border-amber-400 focus:outline-none text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {language === 'ur' ? 'تاریخِ سفر' : language === 'ar' ? 'تاريخ السفر' : 'Travel Date'}
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input
                    type="date"
                    value={travelDate}
                    onChange={(e) => setTravelDate(e.target.value)}
                    className="w-full pl-9 pr-2 py-2 bg-slate-950/70 border border-slate-700 rounded-xl text-white focus:border-amber-400 focus:outline-none text-xs"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {language === 'ur' ? 'اضافی ضروریات یا سوال' : language === 'ar' ? 'ملاحظات أو متطلبات خاصة' : 'Additional Notes / Preferences'}
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={language === 'ur' ? 'مثلاً: ہوٹل کعبہ ویو چاہیے، گاڑی جی ایم سی ہو وغیرہ' : language === 'ar' ? 'مثال: فندق بإطلالة على الكعبة، سيارة يوكون، إلخ' : 'e.g. Kaaba view hotel room, Yukon SUV request...'}
                className="w-full p-2.5 bg-slate-950/70 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:border-amber-400 focus:outline-none text-xs"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="submit"
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>{language === 'ur' ? 'درخواست جمع کروائیں' : language === 'ar' ? 'إرسال الطلب' : 'Submit Booking Inquiry'}</span>
              </button>

              <button
                type="button"
                onClick={handleWhatsAppDirect}
                className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition flex items-center justify-center gap-1.5 shadow-md shadow-emerald-700/30"
                title="Direct WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
                <span className="hidden sm:inline">WhatsApp</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
