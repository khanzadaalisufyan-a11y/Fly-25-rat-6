import React from 'react';
import { useApp } from '../../context/AppContext';
import { Language } from '../../types';
import { Globe } from 'lucide-react';

export const LanguageSwitcher: React.FC = () => {
  const { language, setLanguage } = useApp();

  const languages: { code: Language; label: string; nativeName: string }[] = [
    { code: 'ur', label: 'اردو', nativeName: 'Urdu' },
    { code: 'en', label: 'English', nativeName: 'English' },
    { code: 'ar', label: 'العربية', nativeName: 'Arabic' }
  ];

  return (
    <div className="flex items-center gap-1 bg-slate-900/90 border border-amber-500/30 rounded-full p-1 shadow-inner">
      <div className="px-2 text-amber-400">
        <Globe className="w-3.5 h-3.5" />
      </div>
      {languages.map((item) => {
        const isActive = language === item.code;
        return (
          <button
            key={item.code}
            onClick={() => setLanguage(item.code)}
            className={`px-3 py-1 rounded-full text-xs font-semibold transition-all duration-200 cursor-pointer ${
              isActive
                ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
            title={item.nativeName}
          >
            {item.label}
          </button>
        );
      })}
    </div>
  );
};
