import React from 'react';
import { useApp } from '../../context/AppContext';
import { Compass, MapPin, Clock, ArrowRight } from 'lucide-react';

export const DestinationsSection: React.FC = () => {
  const { destinations, t, language, openInquiryModal } = useApp();

  return (
    <section className="py-16 bg-slate-900/60 border-t border-slate-800 relative" id="destinations-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
            <Compass className="w-3.5 h-3.5" />
            <span>
              {language === 'ur' ? 'سعودی عرب کے روحانی و تاریخی مقامات' : language === 'ar' ? 'وجهات سياحية وتاريخية أصيلة' : 'Spiritual & Heritage Destinations'}
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight font-serif">
            {language === 'ur'
              ? 'مکہ مکرمہ، مدینہ منورہ اور پرفضا طائف کے روح پرور دورے'
              : language === 'ar'
              ? 'رحلات تاريخية ومعالم مباركة في رحاب مكة والمدينة والطائف'
              : 'Sacred Sanctity & Majestic Landscapes'}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {destinations.map((dest) => (
            <div
              key={dest.id}
              className="group relative rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 hover:border-amber-500/40 shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div className="relative h-64 w-full overflow-hidden">
                <img
                  src={dest.mainImage}
                  alt={t(dest.name)}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-slate-950/80 backdrop-blur border border-amber-500/30 text-amber-300 text-xs font-semibold flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-amber-400" />
                  <span>{dest.city}</span>
                </div>
              </div>

              <div className="p-6 -mt-8 relative z-10 space-y-3 bg-slate-950/95 rounded-t-2xl border-t border-slate-800">
                <h3 className="text-xl font-bold text-white group-hover:text-amber-400 transition-colors">
                  {t(dest.name)}
                </h3>
                <p className="text-xs text-amber-300/90 font-medium">
                  {t(dest.tagline)}
                </p>
                <p className="text-xs text-slate-300 line-clamp-3 leading-relaxed">
                  {t(dest.description)}
                </p>

                <div className="pt-2 flex items-center justify-between text-xs border-t border-slate-800/80">
                  <span className="text-slate-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    {t(dest.recommendedDuration)}
                  </span>

                  <button
                    onClick={() => openInquiryModal('Destination Tour', t(dest.name))}
                    className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 transition"
                  >
                    <span>{language === 'ur' ? 'ٹور بک کریں' : language === 'ar' ? 'حجز جولة' : 'Book Tour'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
