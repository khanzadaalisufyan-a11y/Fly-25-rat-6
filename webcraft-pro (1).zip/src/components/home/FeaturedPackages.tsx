import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PackageItem } from '../../types';
import {
  Calendar,
  Building2,
  Car,
  Check,
  MessageCircle,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Percent
} from 'lucide-react';

export const FeaturedPackages: React.FC = () => {
  const { packages, t, formatPrice, language, openInquiryModal, getWhatsAppLink } = useApp();
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [selectedPackageDetails, setSelectedPackageDetails] = useState<PackageItem | null>(null);

  const categories = [
    { id: 'all', labelEn: 'All Packages', labelUr: 'تمام پیکیجز', labelAr: 'جميع الباقات' },
    { id: 'umrah', labelEn: 'Umrah Packages', labelUr: 'عمرہ پیکیجز', labelAr: 'باقات العمرة' },
    { id: 'hajj', labelEn: 'Hajj Packages', labelUr: 'حج پیکیجز', labelAr: 'باقات الحج' },
    { id: 'family', labelEn: 'Family Specials', labelUr: 'فیملی پیکجز', labelAr: 'باقات العائلات' }
  ];

  const filtered = packages.filter((pkg) => {
    if (!pkg.active) return false;
    if (filterCategory === 'all') return true;
    return pkg.category === filterCategory;
  });

  const handleWhatsAppPackage = (pkg: PackageItem) => {
    const msg = language === 'ur'
      ? `السلام علیکم! میں FLY WITH HAMZA TRAVAL AND TOURS کے اس پیکیج "${t(pkg.title)}" کے بارے میں معلومات اور بکنگ چاہتا ہوں۔ قیمت: ${formatPrice(pkg.priceSar)}`
      : language === 'ar'
      ? `السلام عليكم، أود الاستفسار وحجز باقة "${t(pkg.title)}" بسعر ${formatPrice(pkg.priceSar)} من FLY WITH HAMZA TRAVAL AND TOURS.`
      : `Hello FLY WITH HAMZA TRAVAL AND TOURS, I am interested in booking: "${t(pkg.title)}" starting at ${formatPrice(pkg.priceSar)}. Please share full details.`;
    window.open(getWhatsAppLink(msg), '_blank');
  };

  return (
    <section className="py-16 bg-slate-950 relative" id="packages-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>
              {language === 'ur' ? 'منتخب و مقبول ترین پیکیجز' : language === 'ar' ? 'باقات العمرة والحج المميزة' : 'Curated Pilgrimage Packages'}
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight font-serif">
            {language === 'ur'
              ? 'مقدس سفر کے لیے رائل و اکانومی پیکیجز'
              : language === 'ar'
              ? 'باقات متكاملة لضيوف الرحمن بأعلى مستويات الراحة'
              : 'Handcrafted Umrah & Hajj Pilgrimage Experiences'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            {language === 'ur'
              ? 'حرم مکی اور مسجد نبوی کے سامنے فائیو اسٹار ہوٹلز، جدید گاڑیاں اور مکمل زمینی ویزا معاونت۔'
              : language === 'ar'
              ? 'فنادق راقية مطلة على الحرمين الشريفين، تنقلات فاخرة، وخدمة عملاء على مدار الساعة.'
              : 'Direct Haram-view luxury towers, private GMC Yukon / luxury coaches, and dedicated scholars.'}
          </p>

          {/* Category Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-4">
            {categories.map((cat) => {
              const isSelected = filterCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setFilterCategory(cat.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                      : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                  }`}
                >
                  {language === 'ur' ? cat.labelUr : language === 'ar' ? cat.labelAr : cat.labelEn}
                </button>
              );
            })}
          </div>
        </div>

        {/* Packages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((pkg) => (
            <div
              key={pkg.id}
              className="group bg-slate-900/90 rounded-2xl border border-slate-800 hover:border-amber-500/40 overflow-hidden shadow-xl hover:shadow-2xl hover:shadow-amber-500/10 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Image & Badges */}
                <div className="relative h-56 w-full overflow-hidden bg-slate-950">
                  <img
                    src={pkg.mainImage}
                    alt={t(pkg.title)}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-80" />

                  {/* Badge */}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5">
                    <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500 text-slate-950 shadow-md">
                      {pkg.badge}
                    </span>
                    {pkg.discountPercent && pkg.discountPercent > 0 && (
                      <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-rose-600 text-white flex items-center gap-0.5 shadow-md">
                        <Percent className="w-3 h-3" />
                        {pkg.discountPercent}% OFF
                      </span>
                    )}
                  </div>

                  {/* Duration */}
                  <div className="absolute bottom-3 right-3 px-3 py-1 rounded-lg bg-slate-950/80 backdrop-blur border border-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    <span>
                      {pkg.durationDays} {language === 'ur' ? 'دن' : language === 'ar' ? 'أيام' : 'Days'} / {pkg.durationNights} {language === 'ur' ? 'راتیں' : language === 'ar' ? 'ليال' : 'Nights'}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-4">
                  <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-2 leading-snug">
                    {t(pkg.title)}
                  </h3>

                  {/* Hotels & Transport Meta */}
                  <div className="space-y-2 text-xs text-slate-300 border-y border-slate-800/80 py-3">
                    <div className="flex items-start gap-2">
                      <Building2 className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-slate-200">{t(pkg.makkahHotel)}</span>
                        <span className="text-[11px] text-amber-400 block">{pkg.makkahHotelDistance}</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <Building2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold text-slate-200">{t(pkg.madinahHotel)}</span>
                        <span className="text-[11px] text-emerald-400 block">{pkg.madinahHotelDistance}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Car className="w-4 h-4 text-amber-400 shrink-0" />
                      <span className="text-slate-300">{t(pkg.transportType)}</span>
                    </div>
                  </div>

                  {/* Highlights */}
                  <div className="space-y-1.5 text-xs text-slate-400">
                    {pkg.included.slice(0, 3).map((item, idx) => (
                      <div key={idx} className="flex items-start gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span className="text-slate-300 line-clamp-1">{t(item)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Price & Action Footer */}
              <div className="p-5 pt-0 border-t border-slate-800/60 mt-2">
                <div className="flex items-baseline justify-between mb-3 pt-3">
                  <span className="text-xs text-slate-400">
                    {language === 'ur' ? 'ابتدائی قیمت فی شخص' : language === 'ar' ? 'السعر يبدأ من' : 'Starting From'}
                  </span>
                  <div className="text-right">
                    <span className="text-xl font-bold text-amber-400 font-mono">
                      {formatPrice(pkg.priceSar)}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setSelectedPackageDetails(pkg)}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition cursor-pointer flex items-center justify-center gap-1 border border-slate-700"
                  >
                    <span>{language === 'ur' ? 'تفصیلات دیکھیں' : language === 'ar' ? 'التفاصيل' : 'View Details'}</span>
                  </button>

                  <button
                    onClick={() => handleWhatsAppPackage(pkg)}
                    className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-emerald-700/20"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Package Detail Modal */}
      {selectedPackageDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-amber-500/30 rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 font-semibold">
                  {selectedPackageDetails.badge}
                </span>
                <h3 className="text-xl font-bold text-white mt-1">
                  {t(selectedPackageDetails.title)}
                </h3>
              </div>
              <button
                onClick={() => setSelectedPackageDetails(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs text-slate-300">
              <div className="grid grid-cols-2 gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
                <div>
                  <span className="text-slate-400 block">{language === 'ur' ? 'مکہ ہوٹل' : language === 'ar' ? 'فندق مكة' : 'Makkah Hotel'}</span>
                  <span className="font-semibold text-white">{t(selectedPackageDetails.makkahHotel)}</span>
                  <span className="text-amber-400 block">{selectedPackageDetails.makkahHotelDistance}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">{language === 'ur' ? 'مدینہ ہوٹل' : language === 'ar' ? 'فندق المدينة' : 'Madinah Hotel'}</span>
                  <span className="font-semibold text-white">{t(selectedPackageDetails.madinahHotel)}</span>
                  <span className="text-emerald-400 block">{selectedPackageDetails.madinahHotelDistance}</span>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-white mb-2 text-sm">{language === 'ur' ? 'پیکیج میں شامل سہولیات' : language === 'ar' ? 'الخدمات المشمولة' : 'Included Services'}</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedPackageDetails.included.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 p-2 rounded-lg bg-slate-800/40">
                      <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{t(item)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-800">
                <div>
                  <span className="text-slate-400 block">{language === 'ur' ? 'کل قیمت فی کس' : language === 'ar' ? 'السعر للشخص' : 'Total Per Person'}</span>
                  <span className="text-2xl font-bold text-amber-400 font-mono">
                    {formatPrice(selectedPackageDetails.priceSar)}
                  </span>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const pkg = selectedPackageDetails;
                      setSelectedPackageDetails(null);
                      openInquiryModal('Umrah Package', t(pkg.title));
                    }}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition"
                  >
                    {language === 'ur' ? 'ابھی بک کریں' : language === 'ar' ? 'حجز الباقة' : 'Book Package'}
                  </button>

                  <button
                    onClick={() => handleWhatsAppPackage(selectedPackageDetails)}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>WhatsApp</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
