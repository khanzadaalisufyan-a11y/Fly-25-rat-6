import React from 'react';
import { useApp } from '../../context/AppContext';
import { Car, Users, Luggage, ShieldCheck, MessageCircle, ArrowRight } from 'lucide-react';

export const FleetShowcase: React.FC = () => {
  const { vehicles, t, formatPrice, language, openInquiryModal, getWhatsAppLink, companySettings } = useApp();

  const handleWhatsAppVehicle = (vehName: string) => {
    const msg = language === 'ur'
      ? `السلام علیکم! میں FLY WITH HAMZA سے ٹرانسپورٹ گاڑی "${vehName}" کی بکنگ اور روٹ ریٹس معلوم کرنا چاہتا ہوں۔`
      : language === 'ar'
      ? `السلام عليكم، أود الاستفسار وحجز سيارة "${vehName}" من أسطول FLY WITH HAMZA.`
      : `Hello FLY WITH HAMZA, I would like to book the transport vehicle: "${vehName}". Please share driver and route details.`;
    window.open(getWhatsAppLink(msg), '_blank');
  };

  return (
    <section className="py-16 bg-slate-900/60 border-t border-slate-800 relative" id="transport-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-2">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>
                {language === 'ur'
                  ? `ٹرانسپورٹ اتھارٹی لائسنس یافتہ بیڑہ (TGA: ${companySettings.transportLicenseNumber})`
                  : language === 'ar'
                  ? `مرخصة رسمياً من الهيئة العامة للنقل (ترخيص: ${companySettings.transportLicenseNumber})`
                  : `TGA Licensed Chauffeur Fleet (Permit: ${companySettings.transportLicenseNumber})`}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight font-serif">
              {language === 'ur'
                ? 'جدید و پروقار ٹرانسپورٹ اور پرائیویٹ لیموزین بیڑہ'
                : language === 'ar'
                ? 'أسطول سيارات النقل الفاخر والتنقل بين المدن والمطارات'
                : 'Executive Chauffeur Fleet & Intercity Transfers'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              {language === 'ur'
                ? 'جدہ ایئرپورٹ تا مکہ، مکہ تا مدینہ اور متبرک زیارات کے لیے نئی ماڈل گاڑیاں بمع تربیت یافتہ ڈرائیور۔'
                : language === 'ar'
                ? 'خدمات التوصيل من مطار جدة والمدينة المنورة إلى الفنادق، ورحلات بين المدن والمزارات بسيارات حديثة وسائقين أكفاء.'
                : 'From private VIP GMC Yukons to spacious family HiAce vans and Mercedes 49-seater luxury coaches.'}
            </p>
          </div>
        </div>

        {/* Vehicles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {vehicles.filter((v) => v.active).map((veh) => (
            <div
              key={veh.id}
              className="group bg-slate-950 rounded-2xl border border-slate-800 hover:border-amber-500/40 overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-amber-500/10 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Vehicle Image */}
                <div className="relative h-44 w-full overflow-hidden bg-slate-900">
                  <img
                    src={veh.mainImage}
                    alt={t(veh.name)}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded-full bg-slate-900/90 border border-slate-700 text-xs text-amber-300 font-medium">
                    {veh.category}
                  </div>
                  <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-slate-950/80 text-[10px] text-slate-300">
                    Model: {veh.modelYear}
                  </div>
                </div>

                {/* Specs */}
                <div className="p-4 space-y-3">
                  <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                    {t(veh.name)}
                  </h3>

                  {/* Capacities */}
                  <div className="flex items-center gap-4 text-xs text-slate-300 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                    <div className="flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-amber-400" />
                      <span>{veh.passengerCapacity} {language === 'ur' ? 'مسافر' : language === 'ar' ? 'ركاب' : 'Seats'}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Luggage className="w-4 h-4 text-emerald-400" />
                      <span>{veh.luggageCapacity} {language === 'ur' ? 'بیگز' : language === 'ar' ? 'حقائب' : 'Bags'}</span>
                    </div>
                  </div>

                  {/* Sample Route Rates */}
                  <div className="space-y-1.5 text-xs text-slate-400 pt-1">
                    <div className="flex justify-between border-b border-slate-900 pb-1">
                      <span>{language === 'ur' ? 'جدہ ایئرپورٹ تا مکہ' : language === 'ar' ? 'مطار جدة إلى مكة' : 'Jeddah to Makkah'}:</span>
                      <span className="font-mono text-amber-400 font-semibold">{formatPrice(veh.ratePerRouteSar.jeddahAirportToMakkah)}</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-900 pb-1">
                      <span>{language === 'ur' ? 'مکہ تا مدینہ منورہ' : language === 'ar' ? 'مكة إلى المدينة' : 'Makkah to Madinah'}:</span>
                      <span className="font-mono text-emerald-400 font-semibold">{formatPrice(veh.ratePerRouteSar.makkahToMadinah)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="p-4 pt-0 border-t border-slate-800/80 mt-2">
                <div className="grid grid-cols-2 gap-2 pt-3">
                  <button
                    onClick={() => openInquiryModal('Transport Booking', t(veh.name))}
                    className="py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
                  >
                    {language === 'ur' ? 'گاڑی بک کریں' : language === 'ar' ? 'طلب السيارة' : 'Book Vehicle'}
                  </button>

                  <button
                    onClick={() => handleWhatsAppVehicle(t(veh.name))}
                    className="py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
