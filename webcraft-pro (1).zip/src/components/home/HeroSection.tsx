import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  Search,
  Calendar,
  Users,
  Compass,
  Building2,
  Car,
  FileText,
  Sparkles,
  PhoneCall,
  MessageCircle
} from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { companySettings, t, language, setActiveTab, openInquiryModal, getWhatsAppLink } = useApp();
  const [searchTab, setSearchTab] = useState<'packages' | 'hotels' | 'transport' | 'visa'>('packages');
  const [selectedDestination, setSelectedDestination] = useState('Makkah');
  const [guests, setGuests] = useState('2');
  const [travelMonth, setTravelMonth] = useState('Next Month');

  const handleQuickSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTab === 'packages') {
      setActiveTab('packages');
    } else if (searchTab === 'hotels') {
      setActiveTab('hotels');
    } else if (searchTab === 'transport') {
      setActiveTab('transport');
    } else {
      setActiveTab('visa');
    }
    openInquiryModal(
      `Quick Search: ${searchTab.toUpperCase()}`,
      `${selectedDestination} - ${guests} Guests (${travelMonth})`
    );
  };

  return (
    <section className="relative min-h-[90vh] flex flex-col justify-center overflow-hidden bg-slate-950 pt-8 pb-16">
      {/* Background with luxury gradient overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=2000&q=85"
          alt="Makkah & Madinah Luxury Pilgrimage"
          className="w-full h-full object-cover object-center opacity-25 filter brightness-75 scale-105 animate-pulse duration-[10000ms]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-slate-950/60" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500/15 via-transparent to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 w-full my-auto">
        {/* Top Official Badge */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-amber-500/40 text-amber-300 text-xs font-semibold shadow-lg shadow-amber-500/10">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>
              {language === 'ur'
                ? `سعودی وزارتِ تجارت کا باضابطہ لائسنس یافتہ ادارہ (CR: ${companySettings.crNumber})`
                : language === 'ar'
                ? `مرخصة رسمياً من وزارة التجارة برقم (${companySettings.crNumber})`
                : `Official Saudi Registered Corporate Agency (CR: ${companySettings.crNumber})`}
            </span>
            <span className="hidden sm:inline w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span className="hidden sm:inline text-slate-300">
              {language === 'ur' ? 'ہیڈ آفس مکہ مکرمہ' : language === 'ar' ? 'مقرنا مكة المكرمة' : 'Makkah Al-Mukarramah HQ'}
            </span>
          </div>
        </div>

        {/* Hero Title & Branding */}
        <div className="text-center max-w-4xl mx-auto space-y-4">
          <h1 className="text-3xl sm:text-5xl md:text-6xl font-black text-white tracking-tight uppercase font-serif drop-shadow-md">
            <span className="block text-slate-100">{companySettings.companyName}</span>
            <span className="gold-gradient-text text-2xl sm:text-4xl md:text-5xl block mt-2 font-sans font-bold">
              {t(companySettings.tagline)}
            </span>
          </h1>

          <p className="text-sm sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            {t(companySettings.description)}
          </p>

          {/* Quick Action CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => {
                setActiveTab('packages');
                window.scrollTo({ top: 700, behavior: 'smooth' });
              }}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/25 transition transform hover:-translate-y-0.5 cursor-pointer flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>{language === 'ur' ? 'عمرہ و حج پیکیجز دیکھیں' : language === 'ar' ? 'استعراض باقات العمرة' : 'Explore Umrah Packages'}</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('calculator');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-6 py-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-amber-300 font-semibold text-sm border border-amber-500/40 shadow-lg transition cursor-pointer flex items-center gap-2"
            >
              <Compass className="w-4 h-4 text-amber-400" />
              <span>{language === 'ur' ? 'اپنی مرضی کا عمرہ ٹرپ بنائیں' : language === 'ar' ? 'صمم باقة عمرتك المخصصة' : 'Customize Trip Calculator'}</span>
            </button>

            <a
              href={getWhatsAppLink()}
              target="_blank"
              rel="noreferrer"
              className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-lg shadow-emerald-700/30 transition flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp</span>
            </a>
          </div>
        </div>

        {/* Interactive Quick Booking Search Box */}
        <div className="mt-10 max-w-4xl mx-auto bg-slate-900/90 backdrop-blur-xl border border-amber-500/30 rounded-2xl p-4 sm:p-6 shadow-2xl shadow-slate-950/80">
          {/* Tabs */}
          <div className="flex border-b border-slate-800 pb-3 gap-2 overflow-x-auto">
            {[
              { id: 'packages', labelEn: 'Packages', labelUr: 'پیکجز تلاش کریں', labelAr: 'الباقات', icon: Compass },
              { id: 'hotels', labelEn: 'Hotels', labelUr: 'فنادق و ہوٹلز', labelAr: 'الفنادق', icon: Building2 },
              { id: 'transport', labelEn: 'VIP Transport', labelUr: 'ٹرانسپورٹ و ٹیکسی', labelAr: 'النقل والليموزين', icon: Car },
              { id: 'visa', labelEn: 'Visa', labelUr: 'ویزا پروسیسنگ', labelAr: 'التأشيرات', icon: FileText }
            ].map((tab) => {
              const Icon = tab.icon;
              const isSelected = searchTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSearchTab(tab.id as any)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer shrink-0 ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{language === 'ur' ? tab.labelUr : language === 'ar' ? tab.labelAr : tab.labelEn}</span>
                </button>
              );
            })}
          </div>

          {/* Form */}
          <form onSubmit={handleQuickSearch} className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1 font-medium">
                {language === 'ur' ? 'منزل / شہر' : language === 'ar' ? 'الوجهة / المدينة' : 'Destination'}
              </label>
              <select
                value={selectedDestination}
                onChange={(e) => setSelectedDestination(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:border-amber-400 outline-none cursor-pointer"
              >
                <option value="Makkah">Makkah Al-Mukarramah (مكة المكرمة)</option>
                <option value="Madinah">Madinah Al-Munawwarah (المدينة المنورة)</option>
                <option value="Both">Makkah & Madinah (مكة والمدينة)</option>
                <option value="Taif">Taif Mountains (الطائف)</option>
                <option value="Jeddah">Jeddah Airport (مطار جدة)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">
                {language === 'ur' ? 'سفر کا مہینہ' : language === 'ar' ? 'شهر السفر' : 'Month of Travel'}
              </label>
              <select
                value={travelMonth}
                onChange={(e) => setTravelMonth(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:border-amber-400 outline-none cursor-pointer"
              >
                <option value="Immediate / This Week">Immediate / This Week</option>
                <option value="November 2026">November 2026</option>
                <option value="December 2026">December 2026 (Winter Umrah)</option>
                <option value="Ramadan 2027">Ramadan Special (رمضان المبارك)</option>
                <option value="Hajj Season 2027">Hajj Season (موسم الحج)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-medium">
                {language === 'ur' ? 'افراد کی تعداد' : language === 'ar' ? 'عدد المسافرين' : 'Pilgrims / Guests'}
              </label>
              <select
                value={guests}
                onChange={(e) => setGuests(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:border-amber-400 outline-none cursor-pointer"
              >
                <option value="1">1 Person (Solo Traveler)</option>
                <option value="2">2 Persons (Couple)</option>
                <option value="4">4 Persons (Family Small)</option>
                <option value="8">8-14 Persons (Group Van)</option>
                <option value="30+">30+ Persons (VIP Bus Delegation)</option>
              </select>
            </div>

            <div className="flex items-end">
              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Search className="w-4 h-4" />
                <span>{language === 'ur' ? 'دستیابی چیک کریں' : language === 'ar' ? 'تحقق من التوفر' : 'Check Availability'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Key Operational Highlights */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-center">
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-xl sm:text-2xl font-bold text-amber-400 font-mono">100%</span>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'ur' ? 'سعودی لائسنس یافتہ' : language === 'ar' ? 'ترخيص رسمي معتمد' : 'Verified Saudi CR'}
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-xl sm:text-2xl font-bold text-emerald-400 font-mono">0 Meters</span>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'ur' ? 'حرم کے سامنے ہوٹلز' : language === 'ar' ? 'فنادق ساحات الحرم' : 'Front Haram Hotels'}
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-xl sm:text-2xl font-bold text-amber-400 font-mono">24 / 7</span>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'ur' ? 'مکہ و مدینہ گراؤنڈ سپورٹ' : language === 'ar' ? 'خدمة ميدانية متواصلة' : 'Makkah Support'}
            </p>
          </div>
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-xl sm:text-2xl font-bold text-emerald-400 font-mono">VIP Fleet</span>
            <p className="text-xs text-slate-300 mt-0.5">
              {language === 'ur' ? 'جدید پرائیویٹ گاڑیاں' : language === 'ar' ? 'أسطول سيارات فاخر' : 'Private Yukon & Vans'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
