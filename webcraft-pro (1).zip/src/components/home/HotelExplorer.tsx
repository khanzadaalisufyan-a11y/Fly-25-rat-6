import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Building2, Star, MapPin, Check, MessageCircle, ExternalLink } from 'lucide-react';

export const HotelExplorer: React.FC = () => {
  const { hotels, t, formatPrice, language, openInquiryModal, getWhatsAppLink } = useApp();
  const [cityFilter, setCityFilter] = useState<'All' | 'Makkah' | 'Madinah'>('All');

  const filtered = hotels.filter((h) => {
    if (!h.active) return false;
    if (cityFilter === 'All') return true;
    return h.city === cityFilter;
  });

  const handleWhatsAppHotel = (hotelName: string, price: number) => {
    const msg = language === 'ur'
      ? `السلام علیکم! میں FLY WITH HAMZA سے ہوٹل "${hotelName}" (قیمت تقریباً ${formatPrice(price)} فی رات) کی بکنگ کروانا چاہتا ہوں۔`
      : language === 'ar'
      ? `السلام عليكم، أود حجز فندق "${hotelName}" بسعر ${formatPrice(price)} لليلة من شركة FLY WITH HAMZA.`
      : `Hello FLY WITH HAMZA, I am interested in booking room nights at "${hotelName}" (~${formatPrice(price)}/night).`;
    window.open(getWhatsAppLink(msg), '_blank');
  };

  return (
    <section className="py-16 bg-slate-950 relative" id="hotels-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-semibold mb-2">
              <Building2 className="w-3.5 h-3.5" />
              <span>{language === 'ur' ? 'حرم مکی اور مسجد نبوی کے فائیو اسٹار ہوٹلز' : language === 'ar' ? 'فنادق الحرمين الشريفين' : 'Luxury Holy Haramain Hotels'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight font-serif">
              {language === 'ur'
                ? 'کعبہ ویو اور روضۂ رسول ﷺ کے سامنے پُرسکون قیام'
                : language === 'ar'
                ? 'إقامة روحانية فاخرة بإطلالات مباشرة على الكعبة المشرفة والمسجد النبوي'
                : 'Direct Haram Access & Kaaba View Luxury Suites'}
            </h2>
          </div>

          {/* City Filter Pills */}
          <div className="flex items-center gap-2">
            {(['All', 'Makkah', 'Madinah'] as const).map((city) => (
              <button
                key={city}
                onClick={() => setCityFilter(city)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                  cityFilter === city
                    ? 'bg-amber-500 text-slate-950'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {city === 'All'
                  ? (language === 'ur' ? 'سب ہوٹلز' : language === 'ar' ? 'الكل' : 'All')
                  : city === 'Makkah'
                  ? (language === 'ur' ? 'مکہ مکرمہ' : language === 'ar' ? 'مكة المكرمة' : 'Makkah')
                  : (language === 'ur' ? 'مدینہ منورہ' : language === 'ar' ? 'المدينة المنورة' : 'Madinah')}
              </button>
            ))}
          </div>
        </div>

        {/* Hotels Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filtered.map((hotel) => (
            <div
              key={hotel.id}
              className="group bg-slate-900 rounded-2xl border border-slate-800 hover:border-amber-500/40 overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-amber-500/10 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Image */}
                <div className="relative h-48 w-full overflow-hidden bg-slate-950">
                  <img
                    src={hotel.mainImage}
                    alt={t(hotel.name)}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2.5 right-2.5 px-2.5 py-1 rounded-full bg-slate-950/80 backdrop-blur border border-amber-500/30 text-amber-400 text-xs flex items-center gap-1 font-bold">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span>{hotel.stars} Star</span>
                  </div>

                  <div className="absolute bottom-2.5 left-2.5 px-2.5 py-0.5 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-[11px] text-emerald-300 font-medium">
                    {hotel.city}
                  </div>
                </div>

                {/* Info */}
                <div className="p-4 space-y-3">
                  <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                    {t(hotel.name)}
                  </h3>

                  <div className="flex items-center gap-1.5 text-xs text-amber-300">
                    <MapPin className="w-3.5 h-3.5 shrink-0" />
                    <span className="line-clamp-1">{t(hotel.distanceText)}</span>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-2">
                    {t(hotel.description)}
                  </p>

                  <div className="flex flex-wrap gap-1 pt-1">
                    {hotel.amenities.slice(0, 3).map((amenity, idx) => (
                      <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {amenity}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Price & Actions */}
              <div className="p-4 pt-0 border-t border-slate-800/80 mt-2">
                <div className="flex items-baseline justify-between mb-3 pt-3">
                  <span className="text-[11px] text-slate-400">
                    {language === 'ur' ? 'شروع قیمت فی رات' : language === 'ar' ? 'يبدأ من / ليلة' : 'Starts from / night'}
                  </span>
                  <span className="text-lg font-bold text-amber-400 font-mono">
                    {formatPrice(hotel.pricePerNightSar)}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => openInquiryModal('Hotel Booking', t(hotel.name))}
                    className="py-2 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
                  >
                    {language === 'ur' ? 'بکنگ درخواست' : language === 'ar' ? 'طلب حجز' : 'Inquire'}
                  </button>

                  <button
                    onClick={() => handleWhatsAppHotel(t(hotel.name), hotel.pricePerNightSar)}
                    className="py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
