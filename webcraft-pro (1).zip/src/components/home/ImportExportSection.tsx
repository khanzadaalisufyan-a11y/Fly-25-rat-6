import React from 'react';
import { useApp } from '../../context/AppContext';
import { Globe2, Package, Check, MessageCircle, Send } from 'lucide-react';

export const ImportExportSection: React.FC = () => {
  const { importExport, t, language, openInquiryModal, getWhatsAppLink } = useApp();

  const handleWhatsAppTrade = (title: string) => {
    const msg = language === 'ur'
      ? `السلام علیکم! میں FLY WITH HAMZA سے تجارتی امپورٹ / ایکسپورٹ پروڈکٹ "${title}" کی سپلائی اور ہول سیل نرخ معلوم کرنا چاہتا ہوں۔`
      : language === 'ar'
      ? `السلام عليكم، أود الاستفسار عن توريد وتصدير منتج "${title}" من FLY WITH HAMZA.`
      : `Hello FLY WITH HAMZA, I would like to inquire about wholesale import/export supply for: "${title}".`;
    window.open(getWhatsAppLink(msg), '_blank');
  };

  return (
    <section className="py-16 bg-slate-950 relative" id="import-export-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <Globe2 className="w-3.5 h-3.5" />
            <span>
              {language === 'ur' ? 'بین الاقوامی تجارت و برآمدات' : language === 'ar' ? 'قطاع التجارة والاستيراد والتصدير' : 'International Trade & Supply Chain'}
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight font-serif">
            {language === 'ur'
              ? 'مدینہ منورہ کی عجوہ کھجوریں، آبِ زمزم اور احرام ہول سیل سپلائی'
              : language === 'ar'
              ? 'تصدير تمور المدينة الفاخرة، مياه زمزم ومستلزمات الحج والعمرة'
              : 'Premium Saudi Dates, Zamzam Supply & Pilgrimage Wholesale'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            {language === 'ur'
              ? 'سعودی عرب، پاکستان اور خلیجی ممالک کے مابین باضابطہ تجارتی برآمدات مع سرٹیفکیٹ اور شفافیت۔'
              : language === 'ar'
              ? 'حلول تجارية متكاملة تلبي احتياجات الأسواق الدولية مع الالتزام بالمواصفات القياسية السعودية.'
              : 'Direct supply contracts with certified origin documentation and customs compliance.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {importExport.map((item) => (
            <div
              key={item.id}
              className="bg-slate-900 rounded-2xl border border-slate-800 hover:border-amber-500/40 overflow-hidden shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="relative h-48 w-full overflow-hidden bg-slate-950">
                  <img
                    src={item.mainImage}
                    alt={t(item.title)}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded-full bg-slate-950/80 text-[11px] font-semibold text-amber-300 border border-slate-700">
                    {item.category}
                  </div>
                </div>

                <div className="p-5 space-y-3">
                  <h3 className="text-base font-bold text-white leading-snug">
                    {t(item.title)}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {t(item.description)}
                  </p>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs space-y-1">
                    <div className="flex justify-between text-slate-400">
                      <span>{language === 'ur' ? 'ماخذ / ملک' : language === 'ar' ? 'بلد المنشأ' : 'Origin'}:</span>
                      <span className="text-slate-200">{item.origin}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>{language === 'ur' ? 'کم از کم آرڈر (MOQ)' : language === 'ar' ? 'الحد الأدنى للطلب' : 'MOQ'}:</span>
                      <span className="text-amber-400 font-semibold">{item.moq}</span>
                    </div>
                  </div>

                  <div className="space-y-1 pt-1 text-xs text-slate-300">
                    {item.specifications.map((spec, idx) => (
                      <div key={idx} className="flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="line-clamp-1">{typeof spec === 'string' ? spec : t(spec)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-5 pt-0 border-t border-slate-800/80 mt-2">
                <div className="grid grid-cols-2 gap-2 pt-3">
                  <button
                    onClick={() => openInquiryModal('Trade Inquiry', t(item.title))}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
                  >
                    {language === 'ur' ? 'تجارتی کوٹیشن' : language === 'ar' ? 'طلب تسعير' : 'Trade Quote'}
                  </button>

                  <button
                    onClick={() => handleWhatsAppTrade(t(item.title))}
                    className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
