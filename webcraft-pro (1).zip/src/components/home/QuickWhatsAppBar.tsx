import React from 'react';
import { useApp } from '../../context/AppContext';
import { MessageCircle, Phone, CalendarCheck } from 'lucide-react';

export const QuickWhatsAppBar: React.FC = () => {
  const { companySettings, getWhatsAppLink, openInquiryModal, language } = useApp();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-lg border-t border-amber-500/30 p-2 sm:hidden shadow-2xl">
      <div className="grid grid-cols-3 gap-2 text-center text-xs font-semibold">
        {/* WhatsApp */}
        <a
          href={getWhatsAppLink()}
          target="_blank"
          rel="noreferrer"
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl bg-emerald-600 active:bg-emerald-700 text-white shadow-md shadow-emerald-700/30"
        >
          <MessageCircle className="w-4 h-4 mb-0.5" />
          <span>WhatsApp</span>
        </a>

        {/* Direct Phone Call */}
        <a
          href={`tel:${companySettings.phone}`}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl bg-slate-800 active:bg-slate-700 text-slate-200 border border-slate-700"
        >
          <Phone className="w-4 h-4 text-amber-400 mb-0.5" />
          <span>{language === 'ur' ? 'کال کریں' : language === 'ar' ? 'اتصال' : 'Direct Call'}</span>
        </a>

        {/* Instant Booking Inquiry */}
        <button
          onClick={() => openInquiryModal('Mobile Bar Quick Inquiry', companySettings.companyName)}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 active:from-amber-600 text-slate-950 font-bold shadow-md shadow-amber-500/20"
        >
          <CalendarCheck className="w-4 h-4 mb-0.5" />
          <span>{language === 'ur' ? 'بکنگ' : language === 'ar' ? 'حجز سريع' : 'Quick Book'}</span>
        </button>
      </div>
    </div>
  );
};
