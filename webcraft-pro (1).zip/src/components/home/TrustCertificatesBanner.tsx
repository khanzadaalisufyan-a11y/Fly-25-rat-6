import React from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, Eye, ExternalLink, CheckCircle2, Lock } from 'lucide-react';

export const TrustCertificatesBanner: React.FC = () => {
  const { certificates, setSelectedCertificate, t, language, setActiveTab } = useApp();

  return (
    <section className="py-14 bg-slate-900/60 border-y border-amber-500/20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-2">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>
                {language === 'ur'
                  ? 'حکومتِ سعودی عرب سے باضابطہ تصدیق شدہ'
                  : language === 'ar'
                  ? 'تراخيص ووثائق رسمية معتمدة بالمملكة'
                  : 'Official Saudi Government Licenses & Registrations'}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight font-serif">
              {language === 'ur'
                ? 'قانونی اسناد، تجارتی رجسٹریشن و حکومتی اجازت نامے'
                : language === 'ar'
                ? 'السجل التجاري والتراخيص النظامية الصادرة من الجهات الرسمية'
                : 'Government Registrations & Official Saudi Credentials'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              {language === 'ur'
                ? 'کسی بھی پیکیج یا ویزا سے قبل ہمارے باضابطہ جاری شدہ سعودی کاغذات، ٹیکس نمبر اور ٹرانسپورٹ اجازت ناموں کی خود تصدیق فرمائیں۔'
                : language === 'ar'
                ? 'نعمل وفق أعلى معايير الشفافية والالتزام بالأنظمة الرسمية لوزارة التجارة وهيئة الزكاة وهيئة النقل.'
                : 'Complete transparency. Verify our active Commercial Registration, ZATCA VAT tax compliance, National Address, and TGA passenger transport permits.'}
            </p>
          </div>

          <button
            onClick={() => {
              setActiveTab('certificates');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="self-start md:self-auto px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold border border-amber-500/30 transition flex items-center gap-1.5 cursor-pointer"
          >
            <span>{language === 'ur' ? 'تمام اسناد کی تفصیلات' : language === 'ar' ? 'عرض جميع الوثائق' : 'View Full Registry'}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 4 Interactive Certificate Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {certificates.map((cert) => (
            <div
              key={cert.id}
              onClick={() => setSelectedCertificate(cert)}
              className="group relative bg-slate-950/80 rounded-2xl border border-slate-800 hover:border-amber-500/50 p-4 transition-all duration-300 hover:shadow-xl hover:shadow-amber-500/10 cursor-pointer flex flex-col justify-between overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-xl group-hover:bg-amber-500/15 transition-all" />

              <div>
                {/* Thumbnail Preview */}
                <div className="relative w-full h-44 rounded-xl overflow-hidden bg-slate-900 border border-slate-800/80 mb-3.5">
                  <img
                    src={cert.documentImage}
                    alt={t(cert.title)}
                    className="w-full h-full object-cover object-top filter brightness-95 group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent opacity-60 group-hover:opacity-30 transition-opacity" />
                  <div className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded bg-slate-900/90 border border-emerald-500/40 text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    <span>Active</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] font-semibold text-amber-400 block truncate">
                    {t(cert.authority)}
                  </span>
                  <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-2 leading-snug">
                    {t(cert.title)}
                  </h3>
                </div>
              </div>

              <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 block">
                    {language === 'ur' ? 'رجسٹریشن نمبر' : language === 'ar' ? 'رقم القيد' : 'Reg. Number'}
                  </span>
                  <span className="font-mono text-slate-200 text-xs font-semibold">{cert.certificateNumber}</span>
                </div>

                <button
                  type="button"
                  className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors"
                  title="View Certificate"
                >
                  <Eye className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
