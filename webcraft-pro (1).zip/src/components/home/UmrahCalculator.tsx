import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calculator,
  Moon,
  Building2,
  Car,
  Users,
  CheckCircle,
  MessageCircle,
  Sparkles,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export const UmrahCalculator: React.FC = () => {
  const { formatPrice, language, getWhatsAppLink, openInquiryModal } = useApp();

  const [makkahNights, setMakkahNights] = useState<number>(5);
  const [madinahNights, setMadinahNights] = useState<number>(4);
  const [hotelTier, setHotelTier] = useState<'5star_kaaba' | '5star_walk' | '4star_central' | 'economy'>('5star_walk');
  const [transportChoice, setTransportChoice] = useState<'gmc' | 'van' | 'sedan' | 'train'>('gmc');
  const [pilgrims, setPilgrims] = useState<number>(2);
  const [includeVisa, setIncludeVisa] = useState<boolean>(true);
  const [includeZiyarat, setIncludeZiyarat] = useState<boolean>(true);

  // Cost matrix in SAR
  const hotelRatesPerRoomNight = {
    '5star_kaaba': 1200,
    '5star_walk': 750,
    '4star_central': 450,
    'economy': 260
  };

  const transportRates = {
    'gmc': 1900,     // Airport + Makkah-Madinah + Ziyarat private
    'van': 1600,     // Toyota HiAce
    'sedan': 1100,   // Private Camry
    'train': 700 * pilgrims // Haramain Train business tickets
  };

  const visaFeePerPerson = 540;
  const ziyaratFee = 400;

  // Calculation
  const roomsNeeded = Math.ceil(pilgrims / 2);
  const totalNights = makkahNights + madinahNights;
  const hotelCost = roomsNeeded * (makkahNights * hotelRatesPerRoomNight[hotelTier] + madinahNights * (hotelRatesPerRoomNight[hotelTier] * 0.9));
  const transportCost = transportRates[transportChoice];
  const visaCost = includeVisa ? pilgrims * visaFeePerPerson : 0;
  const ziyaratCost = includeZiyarat ? ziyaratFee : 0;

  const totalCostSar = hotelCost + transportCost + visaCost + ziyaratCost;
  const costPerPersonSar = Math.round(totalCostSar / pilgrims);

  const handleWhatsAppBooking = () => {
    const tierName = hotelTier === '5star_kaaba' ? '5-Star Haram View' : hotelTier === '5star_walk' ? '5-Star Walking' : '4-Star Central';
    const msg = language === 'ur'
      ? `السلام علیکم! میں نے FLY WITH HAMZA کی ویب سائٹ پر عمرہ ٹرپ کا تخمینہ لگایا ہے۔
افراد: ${pilgrims}
مکہ راتیں: ${makkahNights} | مدینہ راتیں: ${madinahNights}
ہوٹل: ${tierName}
گاڑی: ${transportChoice.toUpperCase()}
ویزا: ${includeVisa ? 'شامل ہے' : 'نہیں'}
کل تخمینہ: ${formatPrice(totalCostSar)} (فی کس: ${formatPrice(costPerPersonSar)})
براہ کرم حتمی بکنگ اور تصدیق فرمائیں۔`
      : language === 'ar'
      ? `السلام عليكم، قمت بحساب تكلفة العمرة عبر موقع FLY WITH HAMZA:
عدد المعتمرين: ${pilgrims}
مكة: ${makkahNights} ليالٍ | المدينة: ${madinahNights} ليالٍ
الفندق: ${tierName} | النقل: ${transportChoice.toUpperCase()}
التكلفة التقريبية: ${formatPrice(totalCostSar)}
أرجو التواصل لتأكيد الحجز والتفاصيل.`
      : `Hello FLY WITH HAMZA TRAVAL AND TOURS, I customized an Umrah trip on your calculator:
Pilgrims: ${pilgrims}
Makkah: ${makkahNights} Nights | Madinah: ${madinahNights} Nights
Hotel Tier: ${tierName}
Vehicle: ${transportChoice.toUpperCase()}
Visa included: ${includeVisa ? 'Yes' : 'No'}
Est. Total: ${formatPrice(totalCostSar)} (${formatPrice(costPerPersonSar)}/person).
Please send me the confirmed quotation.`;

    window.open(getWhatsAppLink(msg), '_blank');
  };

  return (
    <section className="py-16 bg-slate-900/80 border-t border-slate-800 relative" id="calculator-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
            <Calculator className="w-3.5 h-3.5" />
            <span>
              {language === 'ur' ? 'انٹرایکٹو عمرہ لاگت تخمینہ کار' : language === 'ar' ? 'حاسبة باقة العمرة الفورية' : 'Interactive Umrah Cost Customizer'}
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight font-serif">
            {language === 'ur'
              ? 'اپنی مرضی اور بجٹ کے مطابق عمرہ پیکج تیار کریں'
              : language === 'ar'
              ? 'صمم رحلة عمرتك الخاصة وفق ميزانيتك ورغبتك'
              : 'Customize Your Bespoke Umrah Pilgrimage'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            {language === 'ur'
              ? 'دن، ہوٹل کی کیٹیگری اور گاڑی کا انتخاب کریں اور فوری لاگت جانیں۔ ہم آپ کو بہترین رعایت دیں گے۔'
              : language === 'ar'
              ? 'حدد عدد الليالي ومستوى الفنادق ونوع السيارة لتحصل على تقدير فوري وشفاف للأسعار.'
              : 'Select your preferred duration, hotel tier, and private transportation to generate an instant estimate.'}
          </p>
        </div>

        {/* Calculator Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Controls Column */}
          <div className="lg:col-span-7 bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-6 shadow-xl">
            {/* Pilgrims Selector */}
            <div>
              <label className="flex items-center justify-between text-xs font-bold text-slate-200 mb-2">
                <span className="flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-amber-400" />
                  {language === 'ur' ? 'معتمرین / افراد کی تعداد' : language === 'ar' ? 'عدد المعتمرين' : 'Number of Pilgrims'}
                </span>
                <span className="text-amber-400 font-mono text-sm">{pilgrims} {language === 'ur' ? 'افراد' : language === 'ar' ? 'أشخاص' : 'Persons'}</span>
              </label>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                {[1, 2, 3, 4, 6, 8].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setPilgrims(num)}
                    className={`py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                      pilgrims === num
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                        : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>

            {/* Nights in Makkah & Madinah */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-white flex items-center gap-1">
                    <Moon className="w-3.5 h-3.5 text-amber-400" />
                    {language === 'ur' ? 'مکہ مکرمہ میں راتیں' : language === 'ar' ? 'ليالي مكة المكرمة' : 'Makkah Nights'}
                  </span>
                  <span className="text-amber-400 font-bold font-mono text-sm">{makkahNights}</span>
                </div>
                <input
                  type="range"
                  min="3"
                  max="14"
                  value={makkahNights}
                  onChange={(e) => setMakkahNights(Number(e.target.value))}
                  className="w-full accent-amber-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                  <span>3 Nights</span>
                  <span>14 Nights</span>
                </div>
              </div>

              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-white flex items-center gap-1">
                    <Moon className="w-3.5 h-3.5 text-emerald-400" />
                    {language === 'ur' ? 'مدینہ منورہ میں راتیں' : language === 'ar' ? 'ليالي المدينة المنورة' : 'Madinah Nights'}
                  </span>
                  <span className="text-emerald-400 font-bold font-mono text-sm">{madinahNights}</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="10"
                  value={madinahNights}
                  onChange={(e) => setMadinahNights(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                  <span>2 Nights</span>
                  <span>10 Nights</span>
                </div>
              </div>
            </div>

            {/* Hotel Tier */}
            <div>
              <label className="block text-xs font-bold text-slate-200 mb-2">
                {language === 'ur' ? 'ہوٹل کا معیار اور دوری' : language === 'ar' ? 'مستوى وقرب الفندق' : 'Hotel Proximity & Standard'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {[
                  { id: '5star_kaaba', titleEn: '5-Star Haram & Kaaba Front', titleUr: 'فائیو اسٹار کعبہ ویو (0 میٹر)', desc: 'Fairmont / Swissotel' },
                  { id: '5star_walk', titleEn: '5-Star Central Walking (50-100m)', titleUr: 'فائیو اسٹار مرکزی (50 تا 100 میٹر)', desc: 'Oberoi / Movenpick' },
                  { id: '4star_central', titleEn: '4-Star Comfort (200-300m)', titleUr: 'فور اسٹار کمفرٹ (200 تا 300 میٹر)', desc: 'Elaf / Pullman' },
                  { id: 'economy', titleEn: 'Economy Clean (Shuttle / Walk)', titleUr: 'اکانومی معیاری مع شٹل بس', desc: 'Standard Clean' }
                ].map((tier) => (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => setHotelTier(tier.id as any)}
                    className={`p-3 rounded-xl border text-left transition cursor-pointer ${
                      hotelTier === tier.id
                        ? 'border-amber-400 bg-amber-500/10 text-white'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-slate-200">
                      {language === 'ur' ? tier.titleUr : tier.titleEn}
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">{tier.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Transport Choice */}
            <div>
              <label className="block text-xs font-bold text-slate-200 mb-2">
                {language === 'ur' ? 'ٹرانسپورٹ و سواری' : language === 'ar' ? 'وسيلة النقل المفضلة' : 'Transport Vehicle Preference'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                {[
                  { id: 'gmc', label: 'GMC Yukon VIP', sub: 'Luxury SUV' },
                  { id: 'van', label: 'HiAce Van', sub: 'Spacious Family' },
                  { id: 'sedan', label: 'Toyota Camry', sub: 'Couple Sedan' },
                  { id: 'train', label: 'Bullet Train', sub: 'Haramain Express' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setTransportChoice(item.id as any)}
                    className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                      transportChoice === item.id
                        ? 'border-amber-400 bg-amber-500/15 text-white font-bold'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Car className="w-4 h-4 mx-auto mb-1 text-amber-400" />
                    <div>{item.label}</div>
                    <div className="text-[10px] text-slate-500">{item.sub}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Addons Checkboxes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeVisa}
                  onChange={(e) => setIncludeVisa(e.target.checked)}
                  className="rounded accent-amber-500 w-4 h-4"
                />
                <span className="text-xs text-slate-200">
                  {language === 'ur' ? 'سعودی الیکٹرانک ویزا شامل کریں' : language === 'ar' ? 'إضافة التأشيرة الإلكترونية' : 'Include Saudi eVisa'}
                </span>
              </label>

              <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeZiyarat}
                  onChange={(e) => setIncludeZiyarat(e.target.checked)}
                  className="rounded accent-amber-500 w-4 h-4"
                />
                <span className="text-xs text-slate-200">
                  {language === 'ur' ? 'مکہ و مدینہ زیارات ٹور شامل کریں' : language === 'ar' ? 'إضافة جولات المزارات الدينية' : 'Include Guided Ziyarat Tours'}
                </span>
              </label>
            </div>
          </div>

          {/* Cost Estimate Output Card */}
          <div className="lg:col-span-5 bg-gradient-to-b from-slate-900 to-slate-950 p-6 rounded-2xl border border-amber-500/40 shadow-2xl space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold text-white">
                  {language === 'ur' ? 'تخمینہ شدہ پیکج سمری' : language === 'ar' ? 'ملخص التكلفة المقدرة' : 'Package Summary Estimate'}
                </h3>
              </div>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-semibold">
                {totalNights} {language === 'ur' ? 'راتیں' : language === 'ar' ? 'ليال' : 'Nights'}
              </span>
            </div>

            {/* Line items */}
            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex items-center justify-between">
                <span>
                  {language === 'ur' ? 'ہوٹل قیام' : language === 'ar' ? 'الإقامة الفندقية' : 'Hotel Accommodations'} ({roomsNeeded} {language === 'ur' ? 'کمرے' : language === 'ar' ? 'غرف' : 'Rooms'})
                </span>
                <span className="font-mono text-slate-200">{formatPrice(hotelCost)}</span>
              </div>

              <div className="flex items-center justify-between">
                <span>
                  {language === 'ur' ? 'ٹرانسپورٹ' : language === 'ar' ? 'النقل والتوصيل' : 'Transportation'} ({transportChoice.toUpperCase()})
                </span>
                <span className="font-mono text-slate-200">{formatPrice(transportCost)}</span>
              </div>

              {includeVisa && (
                <div className="flex items-center justify-between">
                  <span>
                    {language === 'ur' ? 'سعودی ویزا' : language === 'ar' ? 'التأشيرات' : 'eVisa Processing'} ({pilgrims} {language === 'ur' ? 'افراد' : language === 'ar' ? 'أشخاص' : 'Pax'})
                  </span>
                  <span className="font-mono text-slate-200">{formatPrice(visaCost)}</span>
                </div>
              )}

              {includeZiyarat && (
                <div className="flex items-center justify-between">
                  <span>{language === 'ur' ? 'تاریخی زیارات مکہ و مدینہ' : language === 'ar' ? 'جولات المزارات' : 'Holy Ziyarat Tours'}</span>
                  <span className="font-mono text-slate-200">{formatPrice(ziyaratCost)}</span>
                </div>
              )}
            </div>

            {/* Total Box */}
            <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 text-center space-y-1">
              <span className="text-xs text-slate-400 uppercase tracking-wider block">
                {language === 'ur' ? 'کل متوقع لاگت' : language === 'ar' ? 'إجمالي التكلفة التقديرية' : 'Total Estimated Cost'}
              </span>
              <div className="text-3xl font-black text-amber-400 font-mono">
                {formatPrice(totalCostSar)}
              </div>
              <div className="text-xs text-emerald-400 font-medium">
                ≈ {formatPrice(costPerPersonSar)} / {language === 'ur' ? 'فی معتمر' : language === 'ar' ? 'للشخص الواحد' : 'per person'}
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={handleWhatsAppBooking}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-700/30 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>
                  {language === 'ur' ? 'یہ کوٹیشن واٹس ایپ پر لاک کریں' : language === 'ar' ? 'تأكيد هذا العرض عبر الواتساب' : 'Lock Quote on WhatsApp'}
                </span>
              </button>

              <button
                type="button"
                onClick={() =>
                  openInquiryModal(
                    'Custom Umrah Calculator',
                    `${pilgrims} Pax (${makkahNights}N Makkah + ${madinahNights}N Madinah)`
                  )
                }
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs transition border border-slate-700 cursor-pointer"
              >
                {language === 'ur' ? 'ای میل یا آن لائن بکنگ فارم' : language === 'ar' ? 'طلب عرض السعر عبر البريد' : 'Submit as Online Inquiry'}
              </button>
            </div>

            <p className="text-[11px] text-slate-400 text-center leading-relaxed">
              * {language === 'ur'
                ? 'قیمتیں عام سیزن کے مطابق ہیں؛ رمضان المبارک و حج کے ایام میں ہوٹل کی پالیسی کے تحت تبدیلی ممکن ہے۔'
                : language === 'ar'
                ? 'الأسعار تقريبية للمواسم العادية وتخضع لسياسات الفنادق خلال مواسم الذروة ورمضان.'
                : 'Estimates reflect standard seasons. Peak Ramadan & Hajj rates subject to hotel availability.'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
