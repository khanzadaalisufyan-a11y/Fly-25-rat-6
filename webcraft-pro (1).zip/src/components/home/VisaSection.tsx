import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { VisaServiceItem } from '../../types';
import { FileText, Clock, Calendar, Check, MessageCircle, AlertCircle, ShieldCheck } from 'lucide-react';

export const VisaSection: React.FC = () => {
  const { visaServices, t, formatPrice, language, openInquiryModal, getWhatsAppLink } = useApp();
  const [activeVisaModal, setActiveVisaModal] = useState<VisaServiceItem | null>(null);

  const handleWhatsAppVisa = (title: string) => {
    const msg = language === 'ur'
      ? `السلام علیکم! میں FLY WITH HAMZA سے "${title}" کی ضروریات اور پروسیسنگ کے بارے میں بات کرنا چاہتا ہوں۔`
      : language === 'ar'
      ? `السلام عليكم، أود الاستفسار عن متطلبات وإجراءات "${title}" من FLY WITH HAMZA.`
      : `Hello FLY WITH HAMZA, I want to inquire about requirements and processing for: "${title}".`;
    window.open(getWhatsAppLink(msg), '_blank');
  };

  return (
    <section className="py-16 bg-slate-950 relative" id="visa-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-semibold">
            <FileText className="w-3.5 h-3.5" />
            <span>
              {language === 'ur' ? 'سعودی ویزا کنسلٹنسی و پروسیسنگ' : language === 'ar' ? 'خدمات التأشيرات المعتمدة' : 'Official Saudi Visa Facilitation'}
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight font-serif">
            {language === 'ur'
              ? 'ورک ویزا، ٹورسٹ، عمرہ اور بزنس وزٹ کی رہنمائی'
              : language === 'ar'
              ? 'تسهيل إصدار تأشيرات العمل والزيارة والسياحة والاستثمار'
              : 'Work, Tourist, Umrah & Business Investor Visas'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            {language === 'ur'
              ? 'تمام درخواستیں سعودی وزارتِ خارجہ (MOFA) اور قویٰ پورٹل کے قانونی تقاضوں کے مطابق تیار کی جاتی ہیں۔'
              : language === 'ar'
              ? 'نقدم استشارات نظامية متوافقة مع منصات وزارة الخارجية السعودية ومنصة قوى.'
              : 'Strict adherence to Saudi MOFA, Qiwa, and Ministry of Tourism official regulations.'}
          </p>
        </div>

        {/* Visa Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {visaServices.filter((v) => v.active).map((visa) => (
            <div
              key={visa.id}
              className="bg-slate-900 rounded-2xl border border-slate-800 hover:border-amber-500/40 p-6 shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-300 font-semibold border border-amber-500/30">
                    {visa.type}
                  </span>
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                </div>

                <h3 className="text-lg font-bold text-white leading-snug">
                  {t(visa.title)}
                </h3>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {t(visa.description)}
                </p>

                {/* Processing Specs */}
                <div className="space-y-2 bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-xs">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      {language === 'ur' ? 'پروسیسنگ وقت' : language === 'ar' ? 'مدة المعالجة' : 'Processing Time'}:
                    </span>
                    <span className="text-slate-200 font-medium">{t(visa.processingTime)}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-400">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                      {language === 'ur' ? 'ویزا میعاد' : language === 'ar' ? 'صلاحية التأشيرة' : 'Validity'}:
                    </span>
                    <span className="text-slate-200 font-medium">{t(visa.validity)}</span>
                  </div>
                </div>

                {/* Key Requirements List */}
                <div className="space-y-1.5 pt-1">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    {language === 'ur' ? 'ضروری دستاویزات' : language === 'ar' ? 'المستندات الأساسية' : 'Key Requirements'}:
                  </span>
                  {visa.requirements.slice(0, 3).map((req, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 text-xs text-slate-300">
                      <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="line-clamp-1">{t(req)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price & Action */}
              <div className="pt-6 mt-4 border-t border-slate-800/80">
                <div className="flex items-baseline justify-between mb-3">
                  <span className="text-xs text-slate-400">
                    {language === 'ur' ? 'سروس چارجز تخمینہ' : language === 'ar' ? 'رسوم تقريبية' : 'Estimated Govt & Svc Fee'}
                  </span>
                  <span className="text-base font-bold text-amber-400 font-mono">
                    {formatPrice(visa.approxFeeSar)}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => openInquiryModal('Visa Inquiry', t(visa.title))}
                    className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
                  >
                    {language === 'ur' ? 'درخواست فارم' : language === 'ar' ? 'تقديم الطلب' : 'Apply / Check'}
                  </button>

                  <button
                    onClick={() => handleWhatsAppVisa(t(visa.title))}
                    className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Legal Disclaimer Box */}
        <div className="mt-8 p-4 rounded-xl bg-slate-900/60 border border-amber-500/20 text-xs text-slate-400 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong className="text-slate-200">
              {language === 'ur' ? 'قانونی وضاحت:' : language === 'ar' ? 'تنويه قانوني هام:' : 'Official Legal Notice:'}
            </strong>{' '}
            {language === 'ur'
              ? 'ہم باضابطہ ویزا پروسیسنگ اور دستاویزات کی تیاری میں قانونی معاونت فراہم کرتے ہیں۔ ویزا کے حتمی اجراء اور منظوری کا اختیار مکمل طور پر متعلقہ سعودی حکومتی وزارتوں اور سفارت خانوں کے پاس ہے۔'
              : language === 'ar'
              ? 'نحن نقدم خدمات استشارية ومتابعة للإجراءات النظامية، وتخضع الموافقة النهائية على أي تأشيرة للأنظمة الرسمية للجهات الحكومية المختصة بالمملكة.'
              : 'FLY WITH HAMZA TRAVAL AND TOURS provides professional consultation, document attestations, and filing facilitation. Visa issuance is subject to final approval by the competent Saudi government authorities.'}
          </p>
        </div>
      </div>
    </section>
  );
};
