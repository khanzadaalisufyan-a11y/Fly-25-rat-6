import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  ShieldCheck,
  Phone,
  Mail,
  MapPin,
  MessageCircle,
  Award,
  ChevronRight,
  ExternalLink,
  Lock
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { companySettings, t, language, setActiveTab, getWhatsAppLink, openInquiryModal } = useApp();

  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-sm relative overflow-hidden">
      {/* Decorative top gold line */}
      <div className="h-1 w-full bg-gradient-to-r from-transparent via-amber-500/60 to-transparent" />

      {/* Main Footer Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Column 1: Company Profile & Official Verification */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl overflow-hidden border border-amber-500/40 p-0.5 bg-slate-900 shrink-0">
                <img
                  src={companySettings.logo}
                  alt={companySettings.companyName}
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
              <div>
                <h4 className="text-white font-bold text-base font-serif uppercase tracking-tight">
                  {companySettings.companyName}
                </h4>
                <p className="text-[11px] text-amber-400 font-medium">{t(companySettings.tagline)}</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {t(companySettings.description)}
            </p>

            {/* Official Registration Badges */}
            <div className="pt-2 space-y-2 text-xs">
              <div className="flex items-center gap-2 p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong className="text-white">CR No:</strong> {companySettings.crNumber} (وزارة التجارة)
                </span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
                <Award className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  <strong className="text-white">VAT No:</strong> {companySettings.vatNumber} (زاتكا)
                </span>
              </div>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-3">
            <h5 className="text-white font-semibold text-sm uppercase tracking-wider border-b border-slate-800 pb-2">
              {language === 'ur' ? 'اہم لنکس' : language === 'ar' ? 'روابط سريعة' : 'Quick Navigation'}
            </h5>
            <ul className="space-y-2 text-xs">
              {[
                { id: 'packages', label: language === 'ur' ? 'عمرہ و حج پیکیجز' : language === 'ar' ? 'باقات العمرة والحج' : 'Umrah & Hajj Packages' },
                { id: 'hotels', label: language === 'ur' ? 'مکہ و مدینہ کے ہوٹلز' : language === 'ar' ? 'فنادق مكة والمدينة' : 'Makkah & Madinah Hotels' },
                { id: 'transport', label: language === 'ur' ? 'لگژری ٹرانسپورٹ و ٹیکسی' : language === 'ar' ? 'النقل الخاص والليموزين' : 'VIP Transport & Fleet' },
                { id: 'visa', label: language === 'ur' ? 'سعودی ویزا رہنمائی' : language === 'ar' ? 'خدمات التأشيرات السعودية' : 'Saudi Visa Processing' },
                { id: 'calculator', label: language === 'ur' ? 'عمرہ ٹرپ لاگت کیلکولیٹر' : language === 'ar' ? 'حاسبة رحلة العمرة' : 'Umrah Cost Calculator' },
                { id: 'certificates', label: language === 'ur' ? 'سرکاری اسناد و تصدیق' : language === 'ar' ? 'التراخيص والشهادات الرسمية' : 'Verified Saudi Licenses' },
                { id: 'import-export', label: language === 'ur' ? 'امپورٹ / ایکسپورٹ تجارت' : language === 'ar' ? 'خدمات الاستيراد والتصدير' : 'Import & Export Trade' }
              ].map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => {
                      setActiveTab(link.id);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="flex items-center gap-1.5 hover:text-amber-400 transition-colors cursor-pointer text-slate-300"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-amber-500/70" />
                    <span>{link.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Contact & Headquarters */}
          <div className="space-y-3">
            <h5 className="text-white font-semibold text-sm uppercase tracking-wider border-b border-slate-800 pb-2">
              {language === 'ur' ? 'رابطہ و ہیڈ آفس مکہ' : language === 'ar' ? 'معلومات التواصل والمقر' : 'Contact & Makkah HQ'}
            </h5>
            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-white">{t(companySettings.officeAddress)}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">{t(companySettings.saudiAddress)}</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${companySettings.phone}`} className="hover:text-white" dir="ltr">
                  {companySettings.phone}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={getWhatsAppLink()}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-emerald-400 font-medium"
                  dir="ltr"
                >
                  WhatsApp: {companySettings.whatsapp}
                </a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <a href={`mailto:${companySettings.email}`} className="hover:text-white">
                  {companySettings.email}
                </a>
              </div>
            </div>
          </div>

          {/* Column 4: 24/7 Assistance & Direct Inquiry */}
          <div className="space-y-4">
            <h5 className="text-white font-semibold text-sm uppercase tracking-wider border-b border-slate-800 pb-2">
              {language === 'ur' ? '24/7 زائرین سپورٹ' : language === 'ar' ? 'خدمة ضيوف الرحمن 24/7' : 'Pilgrim Support 24/7'}
            </h5>
            <p className="text-xs text-slate-300 leading-relaxed">
              {t(companySettings.workingHours)}
            </p>

            <button
              onClick={() => openInquiryModal('Custom Quote', companySettings.companyName)}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition cursor-pointer flex items-center justify-center gap-2"
            >
              <span>{language === 'ur' ? 'آن لائن رابطہ و رہنمائی' : language === 'ar' ? 'تواصل معنا الآن' : 'Request Instant Assistance'}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-400">
              <span className="text-amber-400 font-semibold block mb-1">
                {language === 'ur' ? 'قانونی انتباہ' : language === 'ar' ? 'تنويه قانوني' : 'Legal Transparency'}:
              </span>
              {language === 'ur'
                ? 'تمام ویزا و ٹرانسپورٹ خدمات سعودی وزارتوں اور متعلقہ حکومتی پلیٹ فارمز کے تحت انجام دی جاتی ہیں۔'
                : language === 'ar'
                ? 'كافة خدمات التأشيرات والنقل تخضع للأنظمة الرسمية لوزارة الحج والعمرة وهيئة النقل.'
                : 'All visa, transport, and pilgrimage services are handled in strict compliance with Saudi Ministry guidelines.'}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <p className="text-slate-500">
            © {new Date().getFullYear()}{' '}
            <strong className="text-slate-300">{companySettings.companyName}</strong>. All Rights Reserved.
          </p>

          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => {
                setActiveTab('certificates');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-amber-400 transition"
            >
              {language === 'ur' ? 'سعودی رجسٹریشن تصدیق' : language === 'ar' ? 'التحقق من التراخيص' : 'Saudi Registration Verification'}
            </button>
            <span>•</span>
            <button
              onClick={() => {
                setActiveTab('admin');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="hover:text-amber-400 transition flex items-center gap-1 text-slate-400"
            >
              <Lock className="w-3 h-3" />
              <span>{language === 'ur' ? 'ایڈمن پورٹل' : language === 'ar' ? 'لوحة التحكم' : 'Admin'}</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
