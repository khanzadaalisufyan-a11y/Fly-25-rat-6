import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LanguageSwitcher } from '../common/LanguageSwitcher';
import { CurrencySwitcher } from '../common/CurrencySwitcher';
import {
  Phone,
  MessageCircle,
  ShieldCheck,
  Menu,
  X,
  Compass,
  Building2,
  Car,
  FileText,
  Calculator,
  Lock,
  Package,
  Globe2
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { companySettings, activeTab, setActiveTab, language, getWhatsAppLink, openInquiryModal } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', labelEn: 'Home', labelUr: 'صفحہ اول', labelAr: 'الرئيسية', icon: Compass },
    { id: 'packages', labelEn: 'Umrah & Hajj', labelUr: 'عمرہ و حج پیکجز', labelAr: 'باقات العمرة والحج', icon: Package },
    { id: 'hotels', labelEn: 'Hotels', labelUr: 'فائیو اسٹار ہوٹلز', labelAr: 'فنادق الحرمين', icon: Building2 },
    { id: 'transport', labelEn: 'Luxury Transport', labelUr: 'لگژری ٹرانسپورٹ', labelAr: 'النقل والسيارات', icon: Car },
    { id: 'visa', labelEn: 'Visa Services', labelUr: 'ویزا سروسز', labelAr: 'خدمات التأشيرات', icon: FileText },
    { id: 'calculator', labelEn: 'Trip Calculator', labelUr: 'عمرہ لاگت کیلکولیٹر', labelAr: 'حاسبة العمرة', icon: Calculator },
    { id: 'certificates', labelEn: 'Saudi Licenses', labelUr: 'سرکاری اسناد و لائسنس', labelAr: 'التراخيص الرسمية', icon: ShieldCheck },
    { id: 'import-export', labelEn: 'Import & Export', labelUr: 'امپورٹ و ایکسپورٹ', labelAr: 'التجارة والتصدير', icon: Globe2 }
  ];

  const getNavLabel = (item: (typeof navLinks)[0]) => {
    if (language === 'ur') return item.labelUr;
    if (language === 'ar') return item.labelAr;
    return item.labelEn;
  };

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-slate-950/90 border-b border-amber-500/20 shadow-xl transition-all">
      {/* Top Bar for Trust & Contacts */}
      <div className="hidden lg:block bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800 text-xs py-1.5 px-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Government credentials */}
          <div className="flex items-center gap-4 text-slate-300">
            <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>
                {language === 'ur'
                  ? `وزارتِ تجارت سعودی عرب رجسٹرڈ (CR: ${companySettings.crNumber})`
                  : language === 'ar'
                  ? `سجل تجاري سعودي معتمد (${companySettings.crNumber})`
                  : `Saudi Licensed CR: ${companySettings.crNumber}`}
              </span>
            </div>
            <span className="text-slate-600">|</span>
            <div className="text-emerald-400">
              <span>{language === 'ur' ? 'ٹیکس ویٹ' : language === 'ar' ? 'الرقم الضريبي' : 'VAT'}: {companySettings.vatNumber}</span>
            </div>
            <span className="text-slate-600">|</span>
            <div className="text-slate-400">
              <span>{language === 'ur' ? 'ہیڈ آفس' : language === 'ar' ? 'المقر' : 'Location'}: {companySettings.nationalAddressShort} - مكة المكرمة</span>
            </div>
          </div>

          {/* Quick contact, currency, language, and admin */}
          <div className="flex items-center gap-4">
            <a
              href={`tel:${companySettings.phone}`}
              className="flex items-center gap-1 text-slate-300 hover:text-white transition"
            >
              <Phone className="w-3 h-3 text-amber-400" />
              <span dir="ltr">{companySettings.phone}</span>
            </a>

            <a
              href={getWhatsAppLink()}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-medium transition"
            >
              <MessageCircle className="w-3 h-3" />
              <span>WhatsApp</span>
            </a>

            <div className="flex items-center gap-2 border-l border-r border-slate-800 px-3">
              <CurrencySwitcher />
              <LanguageSwitcher />
            </div>

            <button
              onClick={() => handleNavClick('admin')}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold transition cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'bg-slate-800/80 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30'
              }`}
            >
              <Lock className="w-3 h-3" />
              <span>{language === 'ur' ? 'ایڈمن پورٹل' : language === 'ar' ? 'لوحة التحكم' : 'Admin Panel'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="relative w-12 h-12 rounded-xl overflow-hidden border border-amber-500/40 p-0.5 bg-slate-900 group-hover:scale-105 transition-transform duration-300 shadow-md shadow-amber-500/10">
            <img
              src={companySettings.logo}
              alt={companySettings.companyName}
              className="w-full h-full object-cover rounded-lg"
            />
          </div>
          <div className="flex flex-col">
            <span className="text-base sm:text-lg font-black tracking-tight text-white group-hover:text-amber-400 transition-colors uppercase font-serif">
              {companySettings.companyName}
            </span>
            <span className="text-[10px] text-amber-400/90 font-medium tracking-wide flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              {language === 'ur'
                ? 'سعودی لائسنس یافتہ ادارہ برائے عمرہ، ٹرانسپورٹ و سیاحت'
                : language === 'ar'
                ? 'مرخصة رسمياً لخدمات الحج والعمرة والنقل والسياحة'
                : 'Licensed Saudi Gateway for Pilgrimage, VIP Transport & Tourism'}
            </span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-1">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-amber-500/15 text-amber-400 border border-amber-500/40 shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5 opacity-80" />
                <span>{getNavLabel(link)}</span>
              </button>
            );
          })}
        </nav>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => openInquiryModal('General Inquiry', companySettings.companyName)}
            className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 transition cursor-pointer"
          >
            <span>{language === 'ur' ? 'فوری کوٹیشن / بکنگ' : language === 'ar' ? 'طلب عرض سعر' : 'Book / Quote'}</span>
          </button>

          {/* Mobile Switchers & Hamburger */}
          <div className="flex items-center gap-2 xl:hidden">
            <LanguageSwitcher />
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-slate-950 border-b border-amber-500/30 px-4 py-4 space-y-3 animate-fade-in shadow-2xl">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <CurrencySwitcher />
            <button
              onClick={() => handleNavClick('admin')}
              className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1.5"
            >
              <Lock className="w-3 h-3" />
              <span>{language === 'ur' ? 'ایڈمن لاگ ان' : language === 'ar' ? 'لوحة التحكم' : 'Admin Panel'}</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activeTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-semibold text-left transition ${
                    isActive
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{getNavLabel(link)}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-2 flex gap-2">
            <a
              href={getWhatsAppLink()}
              target="_blank"
              rel="noreferrer"
              className="flex-1 py-2.5 rounded-xl bg-emerald-600 text-white font-semibold text-xs flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Direct</span>
            </a>
            <a
              href={`tel:${companySettings.phone}`}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              <span>Call Us</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
