import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Language,
  Currency,
  MultiLangString,
  CompanySettings,
  PackageItem,
  HotelItem,
  VehicleItem,
  VisaServiceItem,
  DestinationItem,
  ImportExportItem,
  CertificateItem,
  InquiryItem,
  MediaItem
} from '../types';
import {
  initialCompanySettings,
  initialCertificates,
  initialPackages,
  initialHotels,
  initialVehicles,
  initialVisaServices,
  initialDestinations,
  initialImportExport,
  initialInquiries,
  initialMedia
} from '../data/initialData';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  currency: Currency;
  setCurrency: (curr: Currency) => void;
  t: (str?: MultiLangString | string) => string;
  formatPrice: (amountSar: number) => string;
  currentCurrencyRate: number;

  // Navigation
  activeTab: string;
  setActiveTab: (tab: string) => void;

  // Company Settings
  companySettings: CompanySettings;
  updateCompanySettings: (settings: CompanySettings) => void;

  // Data & CRUD
  packages: PackageItem[];
  addPackage: (pkg: PackageItem) => void;
  updatePackage: (pkg: PackageItem) => void;
  deletePackage: (id: string) => void;

  hotels: HotelItem[];
  addHotel: (hotel: HotelItem) => void;
  updateHotel: (hotel: HotelItem) => void;
  deleteHotel: (id: string) => void;

  vehicles: VehicleItem[];
  addVehicle: (veh: VehicleItem) => void;
  updateVehicle: (veh: VehicleItem) => void;
  deleteVehicle: (id: string) => void;

  visaServices: VisaServiceItem[];
  addVisaService: (visa: VisaServiceItem) => void;
  updateVisaService: (visa: VisaServiceItem) => void;
  deleteVisaService: (id: string) => void;

  destinations: DestinationItem[];
  addDestination: (dest: DestinationItem) => void;
  updateDestination: (dest: DestinationItem) => void;
  deleteDestination: (id: string) => void;

  importExport: ImportExportItem[];
  addImportExport: (item: ImportExportItem) => void;
  updateImportExport: (item: ImportExportItem) => void;
  deleteImportExport: (id: string) => void;

  certificates: CertificateItem[];
  addCertificate: (cert: CertificateItem) => void;
  updateCertificate: (cert: CertificateItem) => void;
  deleteCertificate: (id: string) => void;

  inquiries: InquiryItem[];
  addInquiry: (inq: Omit<InquiryItem, 'id' | 'createdAt'>) => void;
  updateInquiryStatus: (id: string, status: InquiryItem['status'], notes?: string) => void;
  deleteInquiry: (id: string) => void;

  media: MediaItem[];
  addMedia: (item: MediaItem) => void;
  deleteMedia: (id: string) => void;

  // Modals & UI
  selectedCertificate: CertificateItem | null;
  setSelectedCertificate: (cert: CertificateItem | null) => void;
  inquiryModalItem: { title: string; service: string } | null;
  openInquiryModal: (service: string, title?: string) => void;
  closeInquiryModal: () => void;

  // Toasts
  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;

  // Reset to initial
  resetAllData: () => void;

  // WhatsApp Link Helper
  getWhatsAppLink: (customMessage?: string) => string;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const CURRENCY_RATES: Record<Currency, { rate: number; symbol: string }> = {
  SAR: { rate: 1, symbol: 'SAR' },
  PKR: { rate: 74.5, symbol: 'Rs' },
  USD: { rate: 0.267, symbol: '$' },
  AED: { rate: 0.98, symbol: 'AED' }
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem('fwh_lang') as Language) || 'ur';
  });

  const [currency, setCurrencyState] = useState<Currency>(() => {
    return (localStorage.getItem('fwh_currency') as Currency) || 'SAR';
  });

  const [activeTab, setActiveTab] = useState<string>('home');

  // Persistence helpers
  const getStored = <T,>(key: string, fallback: T): T => {
    try {
      const item = localStorage.getItem(`fwh_${key}`);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  };

  const [companySettings, setCompanySettings] = useState<CompanySettings>(() =>
    getStored('company_settings', initialCompanySettings)
  );

  const [packages, setPackages] = useState<PackageItem[]>(() =>
    getStored('packages', initialPackages)
  );

  const [hotels, setHotels] = useState<HotelItem[]>(() =>
    getStored('hotels', initialHotels)
  );

  const [vehicles, setVehicles] = useState<VehicleItem[]>(() =>
    getStored('vehicles', initialVehicles)
  );

  const [visaServices, setVisaServices] = useState<VisaServiceItem[]>(() =>
    getStored('visa_services', initialVisaServices)
  );

  const [destinations, setDestinations] = useState<DestinationItem[]>(() =>
    getStored('destinations', initialDestinations)
  );

  const [importExport, setImportExport] = useState<ImportExportItem[]>(() =>
    getStored('import_export', initialImportExport)
  );

  const [certificates, setCertificates] = useState<CertificateItem[]>(() =>
    getStored('certificates', initialCertificates)
  );

  const [inquiries, setInquiries] = useState<InquiryItem[]>(() =>
    getStored('inquiries', initialInquiries)
  );

  const [media, setMedia] = useState<MediaItem[]>(() =>
    getStored('media', initialMedia)
  );

  // Modals state
  const [selectedCertificate, setSelectedCertificate] = useState<CertificateItem | null>(null);
  const [inquiryModalItem, setInquiryModalItem] = useState<{ title: string; service: string } | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Update HTML dir and lang
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'en' ? 'ltr' : 'rtl';
    localStorage.setItem('fwh_lang', language);
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const setCurrency = (curr: Currency) => {
    setCurrencyState(curr);
    localStorage.setItem('fwh_currency', curr);
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // Localized text helper
  const t = (str?: MultiLangString | string): string => {
    if (!str) return '';
    if (typeof str === 'string') return str;
    return str[language] || str.en || str.ur || str.ar || '';
  };

  // Currency Formatter
  const formatPrice = (amountSar: number): string => {
    const config = CURRENCY_RATES[currency] || CURRENCY_RATES.SAR;
    const converted = Math.round(amountSar * config.rate);
    const formatted = new Intl.NumberFormat().format(converted);
    if (language === 'ur') {
      return `${formatted} ${currency === 'SAR' ? 'سعودی ریال' : currency === 'PKR' ? 'روپے' : config.symbol}`;
    }
    if (language === 'ar') {
      return `${formatted} ${currency === 'SAR' ? 'ريال سعودي' : config.symbol}`;
    }
    return `${config.symbol} ${formatted}`;
  };

  // WhatsApp generator
  const getWhatsAppLink = (customMessage?: string): string => {
    const cleanNumber = companySettings.whatsapp.replace(/[^0-9]/g, '');
    const defaultMsg = language === 'ur'
      ? `السلام علیکم! میں FLY WITH HAMZA TRAVAL AND TOURS سے معلومات حاصل کرنا چاہتا ہوں۔`
      : language === 'ar'
      ? `السلام عليكم، أود الاستفسار عن خدمات FLY WITH HAMZA TRAVAL AND TOURS.`
      : `Hello FLY WITH HAMZA TRAVAL AND TOURS, I would like to inquire about your travel services.`;
    const message = customMessage || defaultMsg;
    return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
  };

  // CRUD actions with localStorage sync
  const updateCompanySettings = (settings: CompanySettings) => {
    setCompanySettings(settings);
    localStorage.setItem('fwh_company_settings', JSON.stringify(settings));
    showToast('Company settings successfully updated', 'success');
  };

  const addPackage = (pkg: PackageItem) => {
    const updated = [pkg, ...packages];
    setPackages(updated);
    localStorage.setItem('fwh_packages', JSON.stringify(updated));
    showToast('Package created successfully', 'success');
  };

  const updatePackage = (pkg: PackageItem) => {
    const updated = packages.map((p) => (p.id === pkg.id ? pkg : p));
    setPackages(updated);
    localStorage.setItem('fwh_packages', JSON.stringify(updated));
    showToast('Package updated successfully', 'success');
  };

  const deletePackage = (id: string) => {
    const updated = packages.filter((p) => p.id !== id);
    setPackages(updated);
    localStorage.setItem('fwh_packages', JSON.stringify(updated));
    showToast('Package deleted', 'info');
  };

  const addHotel = (hotel: HotelItem) => {
    const updated = [hotel, ...hotels];
    setHotels(updated);
    localStorage.setItem('fwh_hotels', JSON.stringify(updated));
    showToast('Hotel added successfully', 'success');
  };

  const updateHotel = (hotel: HotelItem) => {
    const updated = hotels.map((h) => (h.id === hotel.id ? hotel : h));
    setHotels(updated);
    localStorage.setItem('fwh_hotels', JSON.stringify(updated));
    showToast('Hotel updated successfully', 'success');
  };

  const deleteHotel = (id: string) => {
    const updated = hotels.filter((h) => h.id !== id);
    setHotels(updated);
    localStorage.setItem('fwh_hotels', JSON.stringify(updated));
    showToast('Hotel deleted', 'info');
  };

  const addVehicle = (veh: VehicleItem) => {
    const updated = [veh, ...vehicles];
    setVehicles(updated);
    localStorage.setItem('fwh_vehicles', JSON.stringify(updated));
    showToast('Vehicle added to fleet', 'success');
  };

  const updateVehicle = (veh: VehicleItem) => {
    const updated = vehicles.map((v) => (v.id === veh.id ? veh : v));
    setVehicles(updated);
    localStorage.setItem('fwh_vehicles', JSON.stringify(updated));
    showToast('Vehicle details updated', 'success');
  };

  const deleteVehicle = (id: string) => {
    const updated = vehicles.filter((v) => v.id !== id);
    setVehicles(updated);
    localStorage.setItem('fwh_vehicles', JSON.stringify(updated));
    showToast('Vehicle deleted', 'info');
  };

  const addVisaService = (visa: VisaServiceItem) => {
    const updated = [visa, ...visaServices];
    setVisaServices(updated);
    localStorage.setItem('fwh_visa_services', JSON.stringify(updated));
    showToast('Visa service added', 'success');
  };

  const updateVisaService = (visa: VisaServiceItem) => {
    const updated = visaServices.map((v) => (v.id === visa.id ? visa : v));
    setVisaServices(updated);
    localStorage.setItem('fwh_visa_services', JSON.stringify(updated));
    showToast('Visa service updated', 'success');
  };

  const deleteVisaService = (id: string) => {
    const updated = visaServices.filter((v) => v.id !== id);
    setVisaServices(updated);
    localStorage.setItem('fwh_visa_services', JSON.stringify(updated));
    showToast('Visa service deleted', 'info');
  };

  const addDestination = (dest: DestinationItem) => {
    const updated = [dest, ...destinations];
    setDestinations(updated);
    localStorage.setItem('fwh_destinations', JSON.stringify(updated));
    showToast('Destination added', 'success');
  };

  const updateDestination = (dest: DestinationItem) => {
    const updated = destinations.map((d) => (d.id === dest.id ? dest : d));
    setDestinations(updated);
    localStorage.setItem('fwh_destinations', JSON.stringify(updated));
    showToast('Destination updated', 'success');
  };

  const deleteDestination = (id: string) => {
    const updated = destinations.filter((d) => d.id !== id);
    setDestinations(updated);
    localStorage.setItem('fwh_destinations', JSON.stringify(updated));
    showToast('Destination deleted', 'info');
  };

  const addImportExport = (item: ImportExportItem) => {
    const updated = [item, ...importExport];
    setImportExport(updated);
    localStorage.setItem('fwh_import_export', JSON.stringify(updated));
    showToast('Product added to Trade catalog', 'success');
  };

  const updateImportExport = (item: ImportExportItem) => {
    const updated = importExport.map((i) => (i.id === item.id ? item : i));
    setImportExport(updated);
    localStorage.setItem('fwh_import_export', JSON.stringify(updated));
    showToast('Product updated', 'success');
  };

  const deleteImportExport = (id: string) => {
    const updated = importExport.filter((i) => i.id !== id);
    setImportExport(updated);
    localStorage.setItem('fwh_import_export', JSON.stringify(updated));
    showToast('Product deleted', 'info');
  };

  const addCertificate = (cert: CertificateItem) => {
    const updated = [cert, ...certificates];
    setCertificates(updated);
    localStorage.setItem('fwh_certificates', JSON.stringify(updated));
    showToast('Official Certificate added', 'success');
  };

  const updateCertificate = (cert: CertificateItem) => {
    const updated = certificates.map((c) => (c.id === cert.id ? cert : c));
    setCertificates(updated);
    localStorage.setItem('fwh_certificates', JSON.stringify(updated));
    showToast('Certificate updated', 'success');
  };

  const deleteCertificate = (id: string) => {
    const updated = certificates.filter((c) => c.id !== id);
    setCertificates(updated);
    localStorage.setItem('fwh_certificates', JSON.stringify(updated));
    showToast('Certificate removed', 'info');
  };

  const addInquiry = (inq: Omit<InquiryItem, 'id' | 'createdAt'>) => {
    const newInquiry: InquiryItem = {
      ...inq,
      id: `inq-${Date.now().toString(36)}`,
      createdAt: new Date().toISOString()
    };
    const updated = [newInquiry, ...inquiries];
    setInquiries(updated);
    localStorage.setItem('fwh_inquiries', JSON.stringify(updated));
    showToast(
      language === 'ur'
        ? 'شکریہ! آپ کی درخواست موصول ہو گئی ہے۔ ہمارا نمائندہ جلد رابطہ کرے گا۔'
        : language === 'ar'
        ? 'تم استلام طلبكم بنجاح! سيتواصل معكم فريقنا قريباً.'
        : 'Thank you! Your inquiry has been received. Our team will contact you shortly.',
      'success'
    );
  };

  const updateInquiryStatus = (id: string, status: InquiryItem['status'], notes?: string) => {
    const updated = inquiries.map((inq) => {
      if (inq.id === id) {
        return {
          ...inq,
          status,
          privateAdminNotes: notes !== undefined ? notes : inq.privateAdminNotes
        };
      }
      return inq;
    });
    setInquiries(updated);
    localStorage.setItem('fwh_inquiries', JSON.stringify(updated));
    showToast('Inquiry status updated', 'success');
  };

  const deleteInquiry = (id: string) => {
    const updated = inquiries.filter((inq) => inq.id !== id);
    setInquiries(updated);
    localStorage.setItem('fwh_inquiries', JSON.stringify(updated));
    showToast('Inquiry removed', 'info');
  };

  const addMedia = (item: MediaItem) => {
    const updated = [item, ...media];
    setMedia(updated);
    localStorage.setItem('fwh_media', JSON.stringify(updated));
    showToast('Media added to library', 'success');
  };

  const deleteMedia = (id: string) => {
    const updated = media.filter((m) => m.id !== id);
    setMedia(updated);
    localStorage.setItem('fwh_media', JSON.stringify(updated));
    showToast('Media deleted', 'info');
  };

  const openInquiryModal = (service: string, title?: string) => {
    setInquiryModalItem({
      service,
      title: title || ''
    });
  };

  const closeInquiryModal = () => {
    setInquiryModalItem(null);
  };

  const resetAllData = () => {
    localStorage.clear();
    setCompanySettings(initialCompanySettings);
    setPackages(initialPackages);
    setHotels(initialHotels);
    setVehicles(initialVehicles);
    setVisaServices(initialVisaServices);
    setDestinations(initialDestinations);
    setImportExport(initialImportExport);
    setCertificates(initialCertificates);
    setInquiries(initialInquiries);
    setMedia(initialMedia);
    showToast('Website database reset to verified default records', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        currency,
        setCurrency,
        t,
        formatPrice,
        currentCurrencyRate: CURRENCY_RATES[currency].rate,
        activeTab,
        setActiveTab,
        companySettings,
        updateCompanySettings,
        packages,
        addPackage,
        updatePackage,
        deletePackage,
        hotels,
        addHotel,
        updateHotel,
        deleteHotel,
        vehicles,
        addVehicle,
        updateVehicle,
        deleteVehicle,
        visaServices,
        addVisaService,
        updateVisaService,
        deleteVisaService,
        destinations,
        addDestination,
        updateDestination,
        deleteDestination,
        importExport,
        addImportExport,
        updateImportExport,
        deleteImportExport,
        certificates,
        addCertificate,
        updateCertificate,
        deleteCertificate,
        inquiries,
        addInquiry,
        updateInquiryStatus,
        deleteInquiry,
        media,
        addMedia,
        deleteMedia,
        selectedCertificate,
        setSelectedCertificate,
        inquiryModalItem,
        openInquiryModal,
        closeInquiryModal,
        toasts,
        showToast,
        resetAllData,
        getWhatsAppLink
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
