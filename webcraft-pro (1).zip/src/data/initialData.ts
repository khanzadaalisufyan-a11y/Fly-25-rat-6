import {
  CompanySettings,
  PackageItem,
  HotelItem,
  VehicleItem,
  VisaServiceItem,
  DestinationItem,
  ImportExportItem,
  CertificateItem,
  InquiryItem,
  MediaItem
} from '../types';

export const initialCompanySettings: CompanySettings = {
  companyName: "FLY WITH HAMZA TRAVAL AND TOURS",
  tagline: {
    en: "Explore More. Experience More. Live More.",
    ur: "زیادہ دریافت کریں، اعلیٰ ترین روحانی و سیاحتی تجربہ حاصل کریں۔",
    ar: "استكشف المزيد. عش تجربة لا تُنسى. عش المزيد."
  },
  description: {
    en: "Premier Saudi Arabian licensed corporate travel agency, Umrah & Hajj specialist, luxury transportation fleet, and international trade facilitator based in Makkah Al-Mukarramah.",
    ur: "مکہ مکرمہ میں واقع حکومت سعودی عرب سے باقاعدہ لائسنس یافتہ سفری ادارہ، عمرہ و حج پیکجز، لگژری ٹرانسپورٹ بیڑہ اور تجارتی خدمات کا معتبر نام۔",
    ar: "شركة سعودية رائدة معتمدة متخصصة في خدمات الحج والعمرة، النقل الفاخر، حجز الفنادق، التأشيرات والخدمات التجارية في مكة المكرمة."
  },
  aboutUs: {
    en: "FLY WITH HAMZA TRAVAL AND TOURS is an officially registered Saudi corporate enterprise (CR: 7054724989) operating from the holy city of Makkah. We provide world-class VIP pilgrimage arrangements, executive intercity transportation, 5-star hotel logistics, verified visa consultancy, and bilateral import/export support between Saudi Arabia, GCC countries, Pakistan, and global markets.",
    ur: "فلائی ود حمزہ ٹریول اینڈ ٹورز مکہ مکرمہ سے کام کرنے والا ایک باضابطہ رجسٹرڈ ادارہ ہے (کمرشل رجسٹریشن: 7054724989)۔ ہم عمرہ و حج کے لیے فائیو اسٹار انتظامات، جدید گاڑیوں کے ذریعے ٹرانسپورٹ، ویزا رہنمائی اور تجارتی سہولیات فراہم کرتے ہیں۔",
    ar: "تعد شركة فلاي ويذ حمزة ترافل تور جلوبال شركة مرخصة رسميًا بسجل تجاري رقم 7054724989 ومقرها مكة المكرمة، ونقدم خدمات متكاملة للحجاج والمعتمرين وخدمات النقل الفاخر والتجارة العامة بأعلى معايير الجودة."
  },
  mission: {
    en: "To deliver dignified, transparent, and spiritually enriching travel solutions while providing businesses with seamless transport and trade connectivity in the Kingdom.",
    ur: "شفاف، پروقار اور روحانی طور پر مطمئن سفری خدمات کی فراہمی، اور تجارتی و مواصلاتی نظام میں بے مثال سہولیات کی فراہمی۔",
    ar: "تقديم خدمات سفر راقية وميسرة لضيوف الرحمن، مع توفير حلول نقل وتجارة دولية موثوقة تلبي تطلعات عملائنا."
  },
  vision: {
    en: "To become the most trusted Saudi international hospitality and pilgrimage gateway aligned with Saudi Vision 2030.",
    ur: "سعودی وژن 2030 کے ہم آہنگ رہتے ہوئے سعودی عرب کا سب سے قابلِ اعتماد بین الاقوامی ادارہ بننا۔",
    ar: "أن نكون البوابة الرائدة والموثوقة في خدمات السفر والضيافة والتجارة في المملكة تماشيًا مع رؤية السعودية 2030."
  },
  logo: "/assets/aistudio/IMG-20261001-WA0002_18c58d22.jpg",
  phone: "+96594722026",
  whatsapp: "+96594722026",
  email: "info@flywithhamzatravel.com",
  officeAddress: {
    en: "Building 9011, Ibrahim Al Khaleel St, Al Kakiyah Dist, Makkah 24352, Saudi Arabia",
    ur: "عمارت نمبر 9011، شارع ابراہیم الخلیل، الکعکیہ، مکہ مکرمہ 24352، سعودی عرب",
    ar: "مبنى 9011، شارع إبراهيم الخليل، حي الكعكية، مكة المكرمة 24352، المملكة العربية السعودية"
  },
  saudiAddress: {
    en: "Short Address: MDKA9011 | National Address Proof # 1090056840 | Makkah Al-Mukarramah",
    ur: "مختصر پتہ: MDKA9011 | قومی ایڈریس رجسٹریشن نمبر 1090056840 | مکہ مکرمہ",
    ar: "العنوان المختصر: MDKA9011 | إثبات العنوان الوطني رقم 1090056840 | مكة المكرمة"
  },
  googleMapsUrl: "https://maps.google.com/?q=Ibrahim+Al+Khaleel+Al+Kakiyah+Makkah",
  postalCode: "24352",
  workingHours: {
    en: "Open 24/7 for Pilgrims & Emergency Travel Inquiries | Office: 8:00 AM - 10:00 PM AST",
    ur: "زائرین و ہنگامی رابطہ کے لیے 24/7 دستیاب | دفتری اوقات: صبح 8 تا رات 10 بجے",
    ar: "خدمة ضيوف الرحمن متاحة 24/7 على مدار الساعة | أوقات المكتب: 8:00 ص - 10:00 م"
  },
  emergencyContact: "+96594722026",
  socialMedia: {
    facebook: "https://facebook.com/flywithhamzatravel",
    instagram: "https://instagram.com/flywithhamzatravel",
    youtube: "https://youtube.com/@flywithhamzatravel",
    tiktok: "https://tiktok.com/@flywithhamza",
    linkedin: "https://linkedin.com/company/flywithhamza",
    twitter: "https://twitter.com/flywithhamza"
  },
  crNumber: "7054724989",
  vatNumber: "314885364400003",
  nationalAddressShort: "MDKA9011",
  transportLicenseNumber: "18/00001463"
};

export const initialCertificates: CertificateItem[] = [
  {
    id: "cert-cr",
    title: {
      en: "Saudi Commercial Registration Certificate (Ministry of Commerce)",
      ur: "سعودی وزارتِ تجارت کا کمرشل رجسٹریشن سرٹیفکیٹ (CR)",
      ar: "شهادة السجل التجاري - وزارة التجارة السعودية"
    },
    authority: {
      en: "Ministry of Commerce - Kingdom of Saudi Arabia",
      ur: "وزارتِ تجارت، مملکتِ خداداد سعودی عرب",
      ar: "وزارة التجارة - المملكة العربية السعودية"
    },
    certificateNumber: "7054724989",
    issueDate: "2026-07-05",
    expiryDate: "Active / Official",
    documentImage: "/assets/aistudio/IMG-20261024-WA0016_ba95c865.jpg",
    verificationUrl: "https://mc.gov.sa",
    qrValue: "7054724989",
    description: {
      en: "Official One-Person Limited Liability Company Registration issued to 'Fly with Hamza Travel tour Global Company' by the Saudi Ministry of Commerce.",
      ur: "سعودی وزارت تجارت کی جانب سے باضابطہ جاری کردہ ایک ملکیتی لمیٹڈ لائبلٹی کمپنی کا رجسٹریشن سرٹیفکیٹ۔",
      ar: "شهادة تسجيل رسمية لشركة شخص واحد ذات مسؤولية محدودة صادرة عن وزارة التجارة بالمملكة العربية السعودية."
    },
    active: true
  },
  {
    id: "cert-vat",
    title: {
      en: "VAT Tax Registration Certificate (ZATCA)",
      ur: "ویلیو ایڈڈ ٹیکس (VAT) رجسٹریشن سرٹیفکیٹ (زکوٰۃ و ٹیکس اتھارٹی)",
      ar: "شهادة تسجيل في ضريبة القيمة المضافة - هيئة الزكاة والضريبة والجمارك"
    },
    authority: {
      en: "Zakat, Tax and Customs Authority (ZATCA)",
      ur: "زکوٰۃ، ٹیکس و کسٹمز اتھارٹی (زاتکا)",
      ar: "هيئة الزكاة والضريبة والجمارك"
    },
    certificateNumber: "100261177545680",
    issueDate: "2026-07-21",
    expiryDate: "2026-08-01 Effective",
    documentImage: "/assets/aistudio/document_1_3ae02818.jpg",
    verificationUrl: "https://zatca.gov.sa",
    qrValue: "314885364400003",
    description: {
      en: "Official VAT compliance certificate issued under TIN: 3148853644, registering Fly with Hamza Travel tour Global Company under Saudi taxation standards.",
      ur: "زاتکا کی جانب سے باقاعدہ جاری کردہ ویٹ سرٹیفکیٹ، ٹیکس نمبر 3148853644۔",
      ar: "شهادة التسجيل الضريبي الصادرة رسميًا من هيئة الزكاة والضريبة والجمارك برقم مميز 3148853644."
    },
    active: true
  },
  {
    id: "cert-address",
    title: {
      en: "Saudi SPL National Address Proof (Makkah Al-Mukarramah)",
      ur: "سعودی نیشنل ایڈریس اثبات سند (مکہ مکرمہ)",
      ar: "إثبات العنوان الوطني - سبل البريد السعودي"
    },
    authority: {
      en: "Saudi Post (SPL) & National Address System",
      ur: "سعودی پوسٹ (SPL) اور نیشنل ایڈریس پورٹل",
      ar: "البريد السعودي - العنوان الوطني"
    },
    certificateNumber: "1090056840",
    issueDate: "2026-07-21",
    expiryDate: "2027-01-17",
    documentImage: "/assets/aistudio/_______________________________1_5e8860a6.jpg",
    verificationUrl: "https://proof.address.gov.sa/VerifyProofNA.aspx",
    qrValue: "MDKA9011-9011",
    description: {
      en: "Verified National Address verification at Building 9011, Ibrahim Al Khaleel, Al Kakiyah Dist, Makkah 24352, Short Code MDKA9011.",
      ur: "مکہ مکرمہ کے ابراہیم الخلیل روڈ پر واقع ہیڈ آفس کا باقاعدہ تصدیق شدہ نیشنل ایڈریس۔",
      ar: "إثبات رسمي لعنوان المنشأة الوطني في شارع إبراهيم الخليل، حي الكعكية، مكة المكرمة."
    },
    active: true
  },
  {
    id: "cert-tga",
    title: {
      en: "TGA Transport Authority Private Taxi License",
      ur: "ٹرانسپورٹ جنرل اتھارٹی (TGA) پرائیویٹ ٹیکسی لائسنس",
      ar: "ترخيص النقل بسيارة الأجرة الخاصة - الهيئة العامة للنقل (نقل)"
    },
    authority: {
      en: "Transport General Authority (Naql) - Saudi Arabia",
      ur: "ہيئة النقل العام (نقل) - سعودی عرب",
      ar: "الهيئة العامة للنقل (نقل) بالمملكة"
    },
    certificateNumber: "18/00001463",
    issueDate: "2026-08-15",
    expiryDate: "2026-10-14",
    documentImage: "/assets/aistudio/____________________1_eacc80fc.jpg",
    verificationUrl: "https://tga.gov.sa",
    qrValue: "18/00001463",
    description: {
      en: "Official transport fleet permit enabling regulated passenger shuttle and private taxi services in Makkah and across the Kingdom.",
      ur: "مکہ مکرمہ اور دیگر شہروں میں مسافروں اور زائرین کے لیے خصوصی ٹرانسپورٹ چلانے کا باقاعدہ اجازت نامہ۔",
      ar: "تصريح تشغيل رسمي لخدمات النقل بسيارات الأجرة والليموزين الصادر من هيئة النقل."
    },
    active: true
  }
];

export const initialPackages: PackageItem[] = [
  {
    id: "pkg-1",
    title: {
      en: "Royal VIP Executive Umrah (14 Days)",
      ur: "رائل وی آئی پی ایگزیکٹو عمرہ پیکیج (14 دن)",
      ar: "باقة العمرة التنفيذية الملكية الفاخرة (14 يومًا)"
    },
    category: "umrah",
    badge: "VIP",
    durationDays: 14,
    durationNights: 13,
    priceSar: 7850,
    discountPercent: 10,
    destination: {
      en: "Makkah & Madinah Al-Munawwarah",
      ur: "مکہ مکرمہ اور مدینہ منورہ",
      ar: "مكة المكرمة والمدينة المنورة"
    },
    makkahHotel: {
      en: "Fairmont Makkah Clock Royal Tower (Haram View)",
      ur: "فیئر مونٹ کلاک ٹاور مکہ (حرم ویو)",
      ar: "فندق فيرمونت برج ساعة مكة الملكي (إطلالة الحرم)"
    },
    makkahHotelDistance: "0 Meters (Direct Haram Access)",
    madinahHotel: {
      en: "The Oberoi Hotel Madinah (Direct Courtyard Access)",
      ur: "اوبرائے ہوٹل مدینہ منورہ (صحن کے عین سامنے)",
      ar: "فندق أوبروي المدينة (مباشر على ساحة المسجد النبوي)"
    },
    madinahHotelDistance: "50 Meters",
    transportType: {
      en: "Private GMC Yukon XL Luxury SUV with Chauffeur",
      ur: "پرائیویٹ جی ایم سی یوکون ایکسل لگژری ایس یو وی بمع ڈرائیور",
      ar: "سيارة جي إم سي يوكون إكس إل فاخرة مع سائق خاص"
    },
    featured: true,
    active: true,
    mainImage: "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1565552684305-7e77a28e9324?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80"
    ],
    included: [
      { en: "5-Star Luxury Hotels with Daily Open Buffet Breakfast", ur: "فائیو اسٹار ہوٹل اور روزانہ اوپن بفے ناشتہ", ar: "إقامة 5 نجوم مع بوفيه إفطار فاخر يوميًا" },
      { en: "VIP Haramain High Speed Train First Class Tickets", ur: "حرمین ہائی اسپیڈ ٹرین فرسٹ کلاس ٹکٹس", ar: "تذاكر قطار الحرمين السريع درجة رجال الأعمال" },
      { en: "Private Chauffeur Airport & Intercity Transfers", ur: "نجی گاڑی برائے ایئرپورٹ و بین الشہری سفر", ar: "نقل خاص من وإلى المطار وبين المدن" },
      { en: "Comprehensive Ziyarat Tour in Makkah & Madinah with Scholar", ur: "مکہ و مدینہ کے تاریخی مقامات کی مکمل زیارت", ar: "جولات مزارات دينية بصحبة مرشد متخصص" },
      { en: "Saudi Tourist / Umrah eVisa Assistance", ur: "سعودی ویزا سہولت و رہنمائی", ar: "المساعدة في إصدار التأشيرة الإلكترونية" },
      { en: "Complimentary 5L Pure Zamzam per pilgrim", ur: "ہر زائر کے لیے 5 لیٹر آب زمزم تحفہ", ar: "عبوة ماء زمزم 5 لتر لكل معتمر" }
    ],
    excluded: [
      { en: "International Flight Tickets (Can be booked on request)", ur: "بین الاقوامی فلائٹ ٹکٹ (درخواست پر دستیاب)", ar: "تذاكر الطيران الدولي (يمكن طلبها عند الحجز)" },
      { en: "Personal shopping & extra room service", ur: "ذاتی خریداری و اضافی خرچ", ar: "المصاريف الشخصية والخدمات الإضافية" }
    ],
    itinerary: [
      { day: 1, title: { en: "Arrival at Jeddah / Madinah & VIP Transfer", ur: "جدہ یا مدینہ ایئرپورٹ آمد اور وی آئی پی ٹرانسفر", ar: "الوصول والاستقبال في المطار والتوصيل للفندق" }, description: { en: "Warm welcome, luxury transfer to hotel, check-in, orientation and guided first Umrah.", ur: "استقبال، فائیو اسٹار ہوٹل میں چیک ان اور پہلی باجماعت عمرہ کی ادائیگی۔", ar: "استقبال فاخر وتسكين في الفندق مع أداء مناسك العمرة الأولى." } },
      { day: 2, title: { en: "Spiritual Day at Grand Mosque Makkah", ur: "مسجد الحرام میں عبادت کا روح پرور دن", ar: "يوم للعبادة والسكينة في المسجد الحرام" }, description: { en: "Tawaf, prayers, reflection and evening group dinner.", ur: "طواف، نوافل اور روح پرور لمحات۔", ar: "طواف وصلاة وأوقات مباركة مع وجبة عشاء خاصة." } },
      { day: 5, title: { en: "Comprehensive Makkah Ziyarat Tour", ur: "مکہ مکرمہ کے متبرک مقامات کی زیارت", ar: "جولة مزارات مكة المكرمة التاريخية" }, description: { en: "Cave Hira (Jabal Al Noor), Cave Thawr, Mina, Muzdalifah and Arafat.", ur: "غار حرا، غار ثور، منیٰ، مزدلفہ اور میدان عرفات کی زیارات۔", ar: "زيارة غار حراء وثور والمشاعر المقدسة (منى، مزدلفة، عرفات)." } },
      { day: 8, title: { en: "Departure to Al-Madinah via Haramain High Speed Train", ur: "حرمین ہائی اسپیڈ ٹرین کے ذریعے مدینہ منورہ روانگی", ar: "الانتقال إلى المدينة المنورة عبر قطار الحرمين" }, description: { en: "First-class journey to the City of the Prophet (PBUH) and Salam at Rawdah Mubarak.", ur: "مدینہ منورہ میں چیک ان اور روضہ رسول ﷺ پر صلوٰۃ و سلام۔", ar: "الوصول لمدينة رسول الله ﷺ والسلام في الروضة الشريفة." } }
    ],
    departureDates: ["2026-11-01", "2026-11-15", "2026-12-01", "2026-12-15"]
  },
  {
    id: "pkg-2",
    title: {
      en: "Economy Comfort Umrah Package (10 Days)",
      ur: "اکانومی کمفرٹ عمرہ پیکیج (10 دن)",
      ar: "باقة العمرة الاقتصادية المريحة (10 أيام)"
    },
    category: "umrah",
    badge: "Popular",
    durationDays: 10,
    durationNights: 9,
    priceSar: 3450,
    discountPercent: 15,
    destination: {
      en: "Makkah & Madinah",
      ur: "مکہ اور مدینہ",
      ar: "مكة والمدينة"
    },
    makkahHotel: {
      en: "Swissotel Al Maqam / Pullman Zamzam Tower",
      ur: "سوئس ہوٹل المقام / پل مین زمزم ٹاور",
      ar: "فندق سويس أوتيل المقام / بولمان زمزم"
    },
    makkahHotelDistance: "100 Meters from Haram Gate",
    madinahHotel: {
      en: "Anwar Al Madinah Movenpick",
      ur: "انوار المدینہ موون پک",
      ar: "أنوار المدينة موفنبيك"
    },
    madinahHotelDistance: "150 Meters from Courtyard",
    transportType: {
      en: "AC Luxury Coaster / Modern Toyota HiAce",
      ur: "ائیر کنڈیشنڈ لگژری کوسٹر یا ہائی ایس وین",
      ar: "حافلة كوستر حديثة ومكيفة / تويوتا هاي إيس"
    },
    featured: true,
    active: true,
    mainImage: "https://images.unsplash.com/photo-1565552684305-7e77a28e9324?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1565552684305-7e77a28e9324?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=800&q=80"
    ],
    included: [
      { en: "Centrally Located 4-Star Hotels with Breakfast", ur: "مرکزی 4 سٹار ہوٹل اور ناشتہ", ar: "فنادق 4 نجوم قريبة مع وجبة الإفطار" },
      { en: "Airport Pick and Drop with Group Assistance", ur: "ایئرپورٹ پک اینڈ ڈراپ گروپ کے ساتھ", ar: "استقبال وتوديع في المطار" },
      { en: "Guided Ziyarat in Makkah and Madinah", ur: "مکہ و مدینہ میں زیارات کا اہتمام", ar: "جولات مزارات كاملة للمدينتين" },
      { en: "24/7 Ground Assistance & Local SIM Guidance", ur: "24 گھنٹے گراؤنڈ سپورٹ اور سم کارڈ رہنمائی", ar: "دعم ميداني متواصل على مدار الساعة" }
    ],
    excluded: [
      { en: "Airfare (optional add-on)", ur: "ہوائی جہاز کا ٹکٹ (اختیاری)", ar: "تذكرة الطيران (إضافية حسب الرغبة)" }
    ],
    itinerary: [
      { day: 1, title: { en: "Arrival in Makkah & Umrah", ur: "مکہ آمد اور عمرہ کی ادائیگی", ar: "الوصول لمكة وأداء العمرة" }, description: { en: "Check-in at hotel and guided group Umrah.", ur: "ہوٹل آمد اور عمرہ کی ادائیگی۔", ar: "التسكين والتوجه لأداء المناسك." } },
      { day: 6, title: { en: "Transfer to Madinah", ur: "مدینہ منورہ منتقلی", ar: "الانتقال للمدينة المنورة" }, description: { en: "Scenic transfer and Rawdah permit support.", ur: "مدینہ منورہ آمد اور روضہ رسول حاضری۔", ar: "الوصول للفندق وحجز تصريح الروضة الشريفة." } }
    ],
    departureDates: ["Every Friday & Monday"]
  },
  {
    id: "pkg-3",
    title: {
      en: "Family Bliss 15-Day Umrah & Taif Excursion",
      ur: "فیملی بلیس 15 روزہ عمرہ و طائف ٹور",
      ar: "باقة العائلة المميزة - عمرة وزيارة الطائف (15 يومًا)"
    },
    category: "family" as any,
    badge: "Family",
    durationDays: 15,
    durationNights: 14,
    priceSar: 5950,
    discountPercent: 12,
    destination: {
      en: "Makkah, Madinah & Taif",
      ur: "مکہ، مدینہ اور خوبصورت طائف",
      ar: "مكة والمدينة وعروس المصائف الطائف"
    },
    makkahHotel: {
      en: "Dar Al Ghufran Hotel Safwah Tower",
      ur: "دار الغفران ہوٹل صفوہ ٹاور",
      ar: "فندق دار الغفران أبراج الصفوة"
    },
    makkahHotelDistance: "50 Meters",
    madinahHotel: {
      en: "Pullman Zamzam Madinah",
      ur: "پل مین زمزم مدینہ",
      ar: "بولمان زمزم المدينة"
    },
    madinahHotelDistance: "150 Meters",
    transportType: {
      en: "Private Family Van (Hyundai Staria / Toyota HiAce)",
      ur: "نجی فیملی وین بمع ڈرائیور",
      ar: "فان عائلي مريح وحديث"
    },
    featured: true,
    active: true,
    mainImage: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80"
    ],
    included: [
      { en: "Family Suite accommodations in Makkah & Madinah", ur: "فیملی سوئیٹ اور کشادہ کمرے", ar: "أجنحة فندقية عائلية واسعة" },
      { en: "Full-day day trip to cool Taif mountain & rose factories", ur: "طائف کا پرفضا دورہ اور گلاب کے کارخانے", ar: "رحلة يوم كامل لمدينة الطائف الجبلية ومزارع الورد" },
      { en: "Private vehicle for family comfort throughout stay", ur: "پورے سفر کے دوران نجی فیملی گاڑی", ar: "سيارة خاصة للعائلة طوال فترة الرحلة" }
    ],
    excluded: [
      { en: "Cable car tickets in Taif (optional)", ur: "طائف کیبل کار ٹکٹ (اختیاری)", ar: "تذاكر تلفريك الهدا (اختيارية)" }
    ],
    itinerary: [
      { day: 1, title: { en: "Arrival in Makkah", ur: "مکہ آمد", ar: "الوصول لمكة" }, description: { en: "Smooth VIP reception and check-in.", ur: "استقبال اور آرام دہ چیک ان۔", ar: "استقبال عائلي مريح." } },
      { day: 7, title: { en: "Scenic Taif Rose City Trip", ur: "خوبصورت طائف کا سفر", ar: "رحلة الطائف عروس المصايف" }, description: { en: "Al Hada mountains, Shubra Palace and rose water factories.", ur: "الہدا پہاڑ، شبرا محل اور عرقِ گلاب کے باغات۔", ar: "زيارة جبال الهدا ومصانع تقطير الورد الطائفي الشهير." } }
    ],
    departureDates: ["Flexible Booking Weekly"]
  },
  {
    id: "pkg-4",
    title: {
      en: "Hajj Platinum Royal VIP Package (Seasonal)",
      ur: "حج پلاٹینم رائل وی آئی پی پیکیج (سیزنل)",
      ar: "باقة الحج الملكية البلاتينية لكبار الشخصيات"
    },
    category: "hajj",
    badge: "VIP",
    durationDays: 21,
    durationNights: 20,
    priceSar: 24500,
    destination: {
      en: "Makkah, Mina VIP Tents, Madinah",
      ur: "مکہ، منیٰ وی آئی پی خیمے، مدینہ",
      ar: "مكة والمشاعر المقدسة (مخيمات الـ VIP) والمدينة"
    },
    makkahHotel: {
      en: "Raffles Makkah Palace Suites",
      ur: "رافلز مکہ پیلس سوئٹس",
      ar: "أجنحة رافلز قصر مكة"
    },
    makkahHotelDistance: "0 Meters",
    madinahHotel: {
      en: "Dar Al Iman InterContinental",
      ur: "دار الایمان انٹرکانٹینینٹل",
      ar: "دار الإيمان إنتركونتيننتال"
    },
    madinahHotelDistance: "Courtyard Front",
    transportType: {
      en: "Private Luxury Coach with AC & Refreshments",
      ur: "انتہائی آرام دہ لگژری کوچز بمع ریفریشمنٹس",
      ar: "حافلات مرسيدس توريزمو VIP مجهزة بكافة سبل الراحة"
    },
    featured: true,
    active: true,
    mainImage: "https://images.unsplash.com/photo-1564769625905-50e93615e769?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1564769625905-50e93615e769?auto=format&fit=crop&w=800&q=80"
    ],
    included: [
      { en: "Air-conditioned Platinum VIP tents in Mina and Arafat with private bathrooms", ur: "منیٰ اور عرفات میں ایئر کنڈیشنڈ وی آئی پی خیمے مع نجی باتھ رومز", ar: "مخيمات بلاتينية VIP مكيفة في منى وعرفات مع دورات مياه خاصة" },
      { en: "Dedicated Religious Scholars & Multi-lingual Group Leaders", ur: "جید علماء کرام اور کثیر اللسانی رہنمائی", ar: "نخبة من الدعاة والمرشدين لتيسير مناسك الحج" },
      { en: "Buffet dining with hot beverages and snacks around the clock", ur: "چوبیس گھنٹے گرما گرم کھانے، مشروبات اور ریفریشمنٹس", ar: "بوفيه مفتوح مع المشروبات الساخنة والباردة على مدار الساعة" }
    ],
    excluded: [
      { en: "Sacrifice / Qurbani voucher (can be arranged officially)", ur: "قربانی کوپن (باضابطہ انتظامات دستیاب)", ar: "سند الهدي (يمكن إضافته رسمياً عبر منصة أضاحي)" }
    ],
    itinerary: [
      { day: 1, title: { en: "Assembly in Makkah", ur: "مکہ مکرمہ میں اجتماع", ar: "التجمع في مكة المكرمة" }, description: { en: "Preparations and guidance before Tarwiyah.", ur: "یوم الترویہ سے قبل مکمل تیاری۔", ar: "الاستعداد ليوم التروية وشرح المناسك." } }
    ],
    departureDates: ["Dhul Hijjah Season"]
  }
];

export const initialHotels: HotelItem[] = [
  {
    id: "hotel-1",
    name: {
      en: "Fairmont Makkah Clock Royal Tower",
      ur: "فیئر مونٹ مکہ کلاک رائل ٹاور",
      ar: "فندق فيرمونت برج ساعة مكة الملكي"
    },
    city: "Makkah",
    area: {
      en: "Abraj Al Bait Complex, Haram Front",
      ur: "ابراج البیت کمپلیکس، عین حرم کے سامنے",
      ar: "مجمع أبراج البيت، أمام الحرم المكي مباشرة"
    },
    stars: 5,
    distanceFromHaramMeters: 0,
    distanceText: {
      en: "0 meters (Direct elevator access into Grand Mosque)",
      ur: "0 میٹر (براہ راست لفٹ کے ذریعے مسجد الحرام میں داخلہ)",
      ar: "0 متر (مصاعد مباشرة إلى ساحات الحرم المكي الشريف)"
    },
    pricePerNightSar: 1250,
    mainImage: "https://images.unsplash.com/photo-1565552684305-7e77a28e9324?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1565552684305-7e77a28e9324?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80"
    ],
    amenities: ["Kaaba View Rooms", "5-Star Restaurants", "24/7 Room Service", "High Speed WiFi", "Concierge Service", "Prayer Rooms with Haram Audio"],
    description: {
      en: "One of the world's most iconic hotel towers standing right in front of the Holy Kaaba. Offers world-class luxury and direct access to the Holy Mosque.",
      ur: "دنیا کے مشہور ترین لگژری ہوٹلز میں سے ایک، خانہ کعبہ کے عین سامنے شاندار نظارے اور بے مثال سہولیات۔",
      ar: "أحد أبرز معالم الضيافة العالمية المطلة على الكعبة المشرفة مباشرة ويوفر أعلى درجات الرفاهية والخدمة الاستثنائية."
    },
    featured: true,
    active: true
  },
  {
    id: "hotel-2",
    name: {
      en: "The Oberoi Hotel Madinah",
      ur: "دی اوبرائے ہوٹل مدینہ منورہ",
      ar: "فندق أوبروي المدينة المنورة"
    },
    city: "Madinah",
    area: {
      en: "Northern Central Area, Prophet's Mosque Courtyard",
      ur: "شمالی مرکزی علاقہ، صحن مسجد نبوی",
      ar: "المنطقة المركزية الشمالية، أمام الحرم النبوي مباشرة"
    },
    stars: 5,
    distanceFromHaramMeters: 50,
    distanceText: {
      en: "50 meters from Rawdah entrance gate",
      ur: "روضہ رسول ﷺ کے گیٹ سے صرف 50 میٹر کے فاصلے پر",
      ar: "50 مترًا من بوابات الحرم النبوي الشريف وباب الروضة"
    },
    pricePerNightSar: 1100,
    mainImage: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1000&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80"
    ],
    amenities: ["Courtyard View", "Fine Dining", "Underground Parking", "VIP Concierge", "Fitness Gym", "Business Center"],
    description: {
      en: "Renowned for its unparalleled hospitality and prime location facing the Prophet's Mosque in Madinah Al-Munawwarah.",
      ur: "مدینہ منورہ میں مسجد نبوی کے سامنے شاندار اور پرسکون قیام کی اولین پسند۔",
      ar: "فندق فخم يشتهر بحفاوة الاستقبال وقربه البالغ من الروضة النبوية الشريفة."
    },
    featured: true,
    active: true
  },
  {
    id: "hotel-3",
    name: {
      en: "Swissôtel Al Maqam Makkah",
      ur: "سوئس ہوٹل المقام مکہ",
      ar: "فندق سويس أوتيل المقام مكة"
    },
    city: "Makkah",
    area: {
      en: "Abraj Al Bait, King Abdulaziz Endowment",
      ur: "ابراج البیت، وقف شاہ عبدالعزیز",
      ar: "أبراج البيت، وقف الملك عبد العزيز"
    },
    stars: 5,
    distanceFromHaramMeters: 80,
    distanceText: {
      en: "80 meters with direct shopping arcade link to Haram",
      ur: "80 میٹر شاپنگ آرکیڈ کے ذریعے براہ راست راستہ",
      ar: "80 مترًا مع مدخل مباشر لساحات الحرم"
    },
    pricePerNightSar: 890,
    mainImage: "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1000&q=80",
    gallery: [],
    amenities: ["Buffet Dining", "Free Wi-Fi", "Express Check-in", "Family Rooms", "Haram View Options"],
    description: {
      en: "A vibrant luxury hotel situated in the prominent Abraj Al Bait with warm Swiss hospitality and breathtaking holy views.",
      ur: "سوئس معیار کی مہمان نوازی اور ابراج البیت کے اندر پُرسکون ماحول۔",
      ar: "ضيافة سويسرية راقية وإطلالات روحانية على الحرم المكي الشريف."
    },
    featured: true,
    active: true
  },
  {
    id: "hotel-4",
    name: {
      en: "Anwar Al Madinah Mövenpick",
      ur: "انوار المدینہ موون پک",
      ar: "فندق أنوار المدينة موفنبيك"
    },
    city: "Madinah",
    area: {
      en: "Central Area, Close to Ladies Gate",
      ur: "مرکزی علاقہ، خواتین کے گیٹ کے قریب",
      ar: "المنطقة المركزية، الأقرب لبوابة النساء"
    },
    stars: 5,
    distanceFromHaramMeters: 100,
    distanceText: {
      en: "100 meters (Closest to Ladies Prayer Entrance)",
      ur: "100 میٹر (خواتین کے داخلے کے دروازے سے قریب ترین)",
      ar: "100 متر (الأقرب لمصلى النساء وبوابات الزيارة)"
    },
    pricePerNightSar: 780,
    mainImage: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1000&q=80",
    gallery: [],
    amenities: ["Shopping Mall Inside", "Multiple Restaurants", "Conference Rooms", "Doctor on Call"],
    description: {
      en: "Madinah's largest hotel complex featuring direct access to the northern courtyard and an integrated shopping mall.",
      ur: "مدینہ منورہ کا وسیع و عریض فائیو اسٹار ہوٹل جس میں انڈور شاپنگ مال اور شاندار سہولیات ہیں۔",
      ar: "أكبر مجمع فندقي في المدينة المنورة يتميز بمدخل مباشر لساحات المسجد النبوي وسوق متكامل."
    },
    featured: false,
    active: true
  }
];

export const initialVehicles: VehicleItem[] = [
  {
    id: "veh-1",
    name: {
      en: "GMC Yukon XL VIP (Latest Edition)",
      ur: "جی ایم سی یوکون ایکسل وی آئی پی (جدید ماڈل)",
      ar: "جي إم سي يوكون إكس إل VIP (موديل حديث)"
    },
    category: "SUV",
    modelYear: "2025/2026",
    passengerCapacity: 7,
    luggageCapacity: 6,
    features: [
      { en: "Ultra-comfortable leather recliners", ur: "انتہائی آرام دہ چمڑے کی سیٹیں", ar: "مقاعد جلدية مريحة جداً قابلة للتعديل" },
      { en: "Dual-zone high performance climate control", ur: "ڈوئل زون طاقتور ایئر کنڈیشننگ", ar: "تكييف مركزي فائق الأداء" },
      { en: "Free high-speed in-car Wi-Fi & Charging ports", ur: "گاڑی میں مفت تیز رفتار وائی فائی اور چارجنگ", ar: "واي فاي مجاني فائق السرعة وشواحن هواتف" },
      { en: "Uniformed, licensed multi-lingual chauffeur", ur: "بااخلاق، لائسنس یافتہ کثیر اللسانی ڈرائیور", ar: "سائق خاص مرخص وذو خبرة بالمسارات" }
    ],
    ratePerRouteSar: {
      makkahToMadinah: 950,
      jeddahAirportToMakkah: 450,
      madinahAirportToMadinah: 250,
      ziyaratMakkah: 400,
      ziyaratMadinah: 350
    },
    mainImage: "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1000&q=80",
    featured: true,
    active: true
  },
  {
    id: "veh-2",
    name: {
      en: "Toyota HiAce Grand Cabin (14-Seater)",
      ur: "ٹویوٹا ہائی ایس گرینڈ کیبن (14 سیٹر)",
      ar: "تويوتا هاي إيس جراند كابين (14 راكب)"
    },
    category: "Van",
    modelYear: "2025",
    passengerCapacity: 13,
    luggageCapacity: 10,
    features: [
      { en: "Spacious individual seats for family & groups", ur: "فیملی اور گروپ کے لیے کشادہ نشستیں", ar: "مقاعد منفصلة مريحة للعائلات والمجموعات" },
      { en: "Ample trunk luggage space with roof carrier option", ur: "سامان کے لیے خصوصی اور کشادہ جگہ", ar: "مساحة واسعة للحقائب والأمتعة" },
      { en: "Direct Intercity & Ziyarat route permits", ur: "بین الشہری سفر اور زیارات کے اجازت نامے", ar: "تصاريح نقل نظامية لكافة مدن المملكة والمزارات" }
    ],
    ratePerRouteSar: {
      makkahToMadinah: 1100,
      jeddahAirportToMakkah: 500,
      madinahAirportToMadinah: 300,
      ziyaratMakkah: 450,
      ziyaratMadinah: 400
    },
    mainImage: "https://images.unsplash.com/photo-1570125909232-eb263c188f7e?auto=format&fit=crop&w=1000&q=80",
    featured: true,
    active: true
  },
  {
    id: "veh-3",
    name: {
      en: "Mercedes Tourismo VIP Luxury Bus (49-Seater)",
      ur: "مرسڈیز ٹورزمو لگژری بس (49 سیٹر)",
      ar: "حافلة مرسيدس توريزمو السياحية الفاخرة (49 راكب)"
    },
    category: "Bus",
    modelYear: "2024/2025",
    passengerCapacity: 49,
    luggageCapacity: 50,
    features: [
      { en: "First-class reclining ergonomic seats with footrests", ur: "فرسٹ کلاس ری کلائننگ سیٹیں مع فٹ ریسٹ", ar: "مقاعد فاخرة مريحة مع مساند للقدمين" },
      { en: "Onboard WC / Restroom & PA audio system", ur: "بس کے اندر واش روم اور ساؤنڈ سسٹم", ar: "دورة مياه داخلية ونظام صوتي متطور" },
      { en: "Huge undercarriage luggage hold", ur: "سامان کے لیے وسیع زیریں کیبن", ar: "مستودع أمتعة سفلي واسع جداً" }
    ],
    ratePerRouteSar: {
      makkahToMadinah: 2800,
      jeddahAirportToMakkah: 1400,
      madinahAirportToMadinah: 800,
      ziyaratMakkah: 1200,
      ziyaratMadinah: 1100
    },
    mainImage: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1000&q=80",
    featured: true,
    active: true
  },
  {
    id: "veh-4",
    name: {
      en: "Toyota Camry Executive Sedan",
      ur: "ٹویوٹا کیمری ایگزیکٹو سیڈان",
      ar: "تويوتا كامري سيدان تنفيذية"
    },
    category: "Sedan",
    modelYear: "2025",
    passengerCapacity: 4,
    luggageCapacity: 3,
    features: [
      { en: "Fuel-efficient, quiet hybrid ride", ur: "آرام دہ اور پُرسکون ہائبرڈ گاڑی", ar: "قيادة هادئة واقتصادية مريحة" },
      { en: "Ideal for couples and business travelers", ur: "جوڑوں اور کاروباری افراد کے لیے بہترین", ar: "مثالية للمسافرين الأفراد والأزواج" }
    ],
    ratePerRouteSar: {
      makkahToMadinah: 650,
      jeddahAirportToMakkah: 280,
      madinahAirportToMadinah: 180,
      ziyaratMakkah: 280,
      ziyaratMadinah: 250
    },
    mainImage: "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=1000&q=80",
    featured: false,
    active: true
  }
];

export const initialVisaServices: VisaServiceItem[] = [
  {
    id: "visa-1",
    title: {
      en: "Saudi Work & Employment Visa Processing Consultancy",
      ur: "سعودی ورک و ایمپلائمنٹ ویزا پروسیسنگ رہنمائی",
      ar: "خدمات واستشارات تأشيرات العمل والتوظيف بالمملكة"
    },
    type: "Work / Employment",
    processingTime: {
      en: "7 to 15 Working Days",
      ur: "7 تا 15 دفتری ایام",
      ar: "من 7 إلى 15 يوم عمل"
    },
    validity: {
      en: "1 to 2 Years (Renewable Iqama)",
      ur: "1 تا 2 سال (قابلِ تجدید اقامہ)",
      ar: "سنة أو سنتين (إقامة قابلة للتجديد)"
    },
    approxFeeSar: 1850,
    description: {
      en: "Expert liaison for Saudi company work visas, Qiwa platform contracts, medical test attestations (GAMCA), MOFA visa verification, and embassy attestation support. Note: We provide professional documentation facilitation; final issuance is subject to Ministry approval.",
      ur: "سعودی کمپنیوں کے ورک ویزا، قویٰ پلیٹ فارم کنٹریکٹ، میڈیکل ٹیسٹ، وزارت خارجہ اور ایمبیسی تصدیق کی پیشہ ورانہ رہنمائی۔ نوٹ: حتمی منظوری متعلقہ حکومتی اداروں سے مشروط ہے۔",
      ar: "استشارات متكاملة لتسهيل إجراءات تأشيرات العمل، عقود منصة قوى، التصديقات الطبية والخارجية وفق الأنظمة الرسمية."
    },
    requirements: [
      { en: "Valid Passport with minimum 6 months validity", ur: "کم از کم 6 ماہ کی میعاد والا پاسپورٹ", ar: "جواز سفر ساري المفعول لمدة لا تقل عن 6 أشهر" },
      { en: "Official Job Offer / Qiwa electronic work contract", ur: "باقاعدہ جاب آفر یا قویٰ الیکٹرانک ورک کنٹریکٹ", ar: "عقد عمل رسمي موثق عبر منصة قوى" },
      { en: "Fit Medical Fitness Certificate (GAMCA / approved center)", ur: "منظور شدہ میڈیکل سینٹر سے فٹنس سرٹیفکیٹ", ar: "فحص طبي لائق من مراكز معتمدة" },
      { en: "Verified educational degrees / vocational skill test if applicable", ur: "تصدیق شدہ تعلیمی اسناد یا مہارت کا سرٹیفکیٹ", ar: "المؤهلات الدراسية أو شهادة الفحص المهني" }
    ],
    documentsRequired: [
      { en: "Original Passport & Copy", ur: "اصل پاسپورٹ اور کاپی", ar: "أصل وصورة جواز السفر" },
      { en: "8 Passport-size photos with white background", ur: "8 عدد پاسپورٹ سائز تصاویر", ar: "8 صور شخصية بخلفية بيضاء" },
      { en: "Police Character Certificate (Attested)", ur: "تصدیق شدہ پولیس کریکٹر سرٹیفکیٹ", ar: "شهادة خلو سوابق مصدقة" }
    ],
    featured: true,
    active: true,
    iconName: "Briefcase"
  },
  {
    id: "visa-2",
    title: {
      en: "Saudi One-Year Multiple Entry Tourist & Umrah eVisa",
      ur: "سعودی ایک سالہ ملٹیپل انٹری ٹورسٹ و عمرہ ای ویزا",
      ar: "التأشيرة السياحية وعمرة متعددة الدخول لمدة سنة"
    },
    type: "Tourist / Visit",
    processingTime: {
      en: "Instant (Within 24 to 48 Hours)",
      ur: "فوری (24 تا 48 گھنٹے کے اندر)",
      ar: "فوري (خلال 24 إلى 48 ساعة)"
    },
    validity: {
      en: "1 Year Validity (Up to 90 Days stay per visit)",
      ur: "1 سالہ میعاد (ہر وزٹ پر 90 دن تک قیام)",
      ar: "صلاحية لمدة عام (إقامة حتى 90 يومًا لكل زيارة)"
    },
    approxFeeSar: 540,
    description: {
      en: "Fast-track electronic tourist visa allowing pilgrims to perform Umrah, visit Madinah, explore historical sites across the Kingdom, and enter multiple times throughout the year.",
      ur: "تیز ترین آن لائن ویزا جس کے تحت آپ پورے سال میں متعدد بار عمرہ ادا کر سکتے ہیں اور سعودی عرب کے تمام شہروں کی سیر کر سکتے ہیں۔",
      ar: "تأشيرة إلكترونية سريعة تتيح أداء مناسك العمرة وزيارة كافة مدن المملكة والاستمتاع بالمواقع التاريخية والسياحية."
    },
    requirements: [
      { en: "Clear colored scan of Passport info page", ur: "پاسپورٹ کے پہلے صفحے کا واضح اسکین", ar: "صورة ملونة وواضحة من جواز السفر" },
      { en: "Recent digital photo (white background)", ur: "حالیہ ڈیجیٹل تصویر", ar: "صورة شخصية حديثة" },
      { en: "Confirmed return air ticket & hotel reservation", ur: "کنفرم واپسی کا ٹکٹ اور ہوٹل بکنگ", ar: "تذكرة طيران وحجز فندقي مؤكد" }
    ],
    documentsRequired: [
      { en: "Passport Bio Page Scan", ur: "پاسپورٹ اسکین", ar: "مسح ضوئي لبيانات الجواز" },
      { en: "Digital Photo", ur: "تصویر", ar: "صورة رقمية" }
    ],
    featured: true,
    active: true,
    iconName: "Compass"
  },
  {
    id: "visa-3",
    title: {
      en: "Saudi Business & Investor Visit Visa",
      ur: "سعودی بزنس و انویسٹر وزٹ ویزا",
      ar: "تأشيرة زيارة الأعمال والاستثمار"
    },
    type: "Business / Investor",
    processingTime: {
      en: "3 to 5 Working Days",
      ur: "3 تا 5 دفتری ایام",
      ar: "من 3 إلى 5 أيام عمل"
    },
    validity: {
      en: "6 Months to 1 Year Multiple Entry",
      ur: "6 ماہ تا 1 سال ملٹیپل انٹری",
      ar: "من 6 أشهر إلى سنة متعددة الدخول"
    },
    approxFeeSar: 1200,
    description: {
      en: "Tailored for international entrepreneurs, corporate delegates, and trade partners attending Saudi business meetings, expos, or exploring MISA investment opportunities.",
      ur: "سعودی عرب میں تجارتی میٹنگز، نمائشوں اور سرمایہ کاری کے مواقع تلاش کرنے والے تاجروں اور کمپنیوں کے لیے خصوصی ویزا سہولت۔",
      ar: "مخصصة لرجال الأعمال والمستثمرين لحضور الاجتماعات التجارية والمعارض واستكشاف فرص الاستثمار الواعدة بالمملكة."
    },
    requirements: [
      { en: "Chamber of Commerce invitation letter from Saudi company", ur: "سعودی کمپنی کا تصدیق شدہ دعوت نامہ", ar: "خطاب دعوة مصدق من الغرفة التجارية السعودية" },
      { en: "Company registration document in applicant's home country", ur: "درخواست دہندہ کی کمپنی کے رجسٹریشن کاغذات", ar: "سجل تجاري للشركة في بلد المتقدم" }
    ],
    documentsRequired: [
      { en: "Passport copy", ur: "پاسپورٹ کاپی", ar: "صورة الجواز" },
      { en: "Official invitation letter from Saudi host", ur: "دعوت نامہ", ar: "خطاب الدعوة الرسمي" }
    ],
    featured: false,
    active: true,
    iconName: "Landmark"
  }
];

export const initialDestinations: DestinationItem[] = [
  {
    id: "dest-1",
    name: {
      en: "Makkah Al-Mukarramah",
      ur: "مکہ مکرمہ",
      ar: "مكة المكرمة"
    },
    city: "Makkah",
    country: "Saudi Arabia",
    tagline: {
      en: "The Spiritual Heart of the Islamic World",
      ur: "عالمِ اسلام کا مقدس ترین روحانی مرکز",
      ar: "مهوى أفئدة المسلمين ومهد الرسالة"
    },
    description: {
      en: "Home to the Holy Kaaba and Masjid Al-Haram. Experience the life-changing spiritual grandeur of Tawaf, Sa'i between Safa and Marwah, and holy sites of Mina, Muzdalifah, and Arafat.",
      ur: "خانہ کعبہ اور مسجد الحرام کا مقدس شہر۔ طواف، صفا و مروہ کی سعی اور منیٰ، عرفات و مزدلفہ کے تاریخی و متبرک مقامات۔",
      ar: "قبلة المسلمين وحاضنة المسجد الحرام والكعبة المشرفة، حيث تتجلى الروحانية في أبهى صورها."
    },
    mainImage: "https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?auto=format&fit=crop&w=1000&q=80",
    attractions: [
      { en: "Masjid Al-Haram & Kaaba", ur: "مسجد الحرام اور بیت اللہ شریف", ar: "المسجد الحرام والكعبة المشرفة" },
      { en: "Cave Hira & Jabal Al-Noor", ur: "غارِ حرا اور جبل النور", ar: "غار حراء وجبل النور" },
      { en: "Cave Thawr", ur: "غارِ ثور", ar: "غار ثور المبارك" },
      { en: "Makkah Clock Royal Tower Museum", ur: "مکہ کلاک ٹاور میوزیم", ar: "متحف برج الساعة" },
      { en: "Aisha Mosque (Taneem) Miqat", ur: "مسجد عائشہ (تنعیم میقات)", ar: "مسجد التنعيم (ميقات العمرة)" }
    ],
    recommendedDuration: {
      en: "5 to 10 Days",
      ur: "5 تا 10 دن",
      ar: "من 5 إلى 10 أيام"
    },
    featured: true
  },
  {
    id: "dest-2",
    name: {
      en: "Al-Madinah Al-Munawwarah",
      ur: "مدینہ منورہ",
      ar: "المدينة المنورة"
    },
    city: "Madinah",
    country: "Saudi Arabia",
    tagline: {
      en: "The Radiant City of the Beloved Prophet (PBUH)",
      ur: "حضور اکرم ﷺ کا روشن و پرنور شہر",
      ar: "طيبة الطيبة ومأرز الإيمان"
    },
    description: {
      en: "City of peace, compassion, and divine serenity. Visit Al-Masjid an-Nabawi, convey Salam at the Rawdah Mubarak, and pray at Masjid Quba.",
      ur: "امن و سلامتی کا گہوارہ۔ مسجد نبوی شریف میں روضۂ اطہر پر صلوٰۃ و سلام اور مسجد قباء میں نوافل کی سعادت۔",
      ar: "مدينة المحبة والسكينة، تضم المسجد النبوي الشريف والروضة المباركة ومسجد قباء أول مسجد في الإسلام."
    },
    mainImage: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1000&q=80",
    attractions: [
      { en: "Al-Masjid an-Nabawi & Rawdah", ur: "مسجد نبوی شریف و ریاض الجنہ", ar: "المسجد النبوي الشريف والروضة" },
      { en: "Masjid Quba (First Mosque in Islam)", ur: "مسجد قباء (اسلام کی پہلی مسجد)", ar: "مسجد قباء" },
      { en: "Mount Uhud & Martyrs Cemetery", ur: "جبلِ احد اور شہدائے احد کا مزار", ar: "جبل أحد ومقبرة الشهداء" },
      { en: "Masjid Al-Qiblatayn", ur: "مسجد قبلتین", ar: "مسجد القبلتين" },
      { en: "Seven Mosques (Battle of Khandaq)", ur: "مساجدِ سبعہ (غزوہ خندق)", ar: "المساجد السبعة" }
    ],
    recommendedDuration: {
      en: "4 to 7 Days",
      ur: "4 تا 7 دن",
      ar: "من 4 إلى 7 أيام"
    },
    featured: true
  },
  {
    id: "dest-3",
    name: {
      en: "Taif City of Roses & Mist",
      ur: "طائف - گلاب اور ٹھنڈی ہواؤں کا مسکن",
      ar: "الطائف عروس المصايف ومدينة الورد"
    },
    city: "Taif",
    country: "Saudi Arabia",
    tagline: {
      en: "Highland Retreat and Fragrant Rose Gardens",
      ur: "سرسبز پہاڑ، ٹھنڈی ہوائیں اور خوشبودار گلاب کے باغات",
      ar: "جمال الطبيعة الجبلية ومصانع الورد الطائفي العريق"
    },
    description: {
      en: "Perched high in the Sarawat Mountains just an hour from Makkah, Taif is famous for its cool temperate climate, fragrant Damask rose distilleries, fruit orchards, and scenic cable car.",
      ur: "مکہ مکرمہ سے کچھ فاصلے پر بلند و بالا پہاڑوں پر واقع پُرفضا مقام، جہاں کے خوشبودار گلاب اور پھلوں کے باغات دنیا بھر میں مشہور ہیں۔",
      ar: "تقع على قمم جبال السروات وتتميز بأجوائها المعتدلة ومزارع الورد وقصر شبرا التاريخي وتلفريك الهدا."
    },
    mainImage: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1000&q=80",
    attractions: [
      { en: "Al Hada Mountain Cable Car", ur: "الہدا کیبل کار", ar: "تلفريك الهدا وجبل كرا" },
      { en: "Traditional Taif Rose Distilleries", ur: "طائف عرقِ گلاب کے روایتی کارخانے", ar: "مصانع تقطير الورد الطائفي" },
      { en: "Addas Mosque & Abdullah Ibn Abbas Mosque", ur: "مسجد عداس و مسجد عبداللہ بن عباسؓ", ar: "مسجد عداس ومسجد عبد الله بن عباس" }
    ],
    recommendedDuration: {
      en: "1 to 2 Days",
      ur: "1 تا 2 دن",
      ar: "يوم إلى يومين"
    },
    featured: true
  }
];

export const initialImportExport: ImportExportItem[] = [
  {
    id: "trade-1",
    title: {
      en: "Original Madinah Ajwa & Royal Medjool Dates Export",
      ur: "مدینہ منورہ کی اصل عجوہ اور رائل مجدول کھجوروں کی برآمد",
      ar: "تصدير تمور العجوة والمجدول الملكي من مزارع المدينة"
    },
    category: "Agri & Dates",
    origin: "Al-Madinah Al-Munawwarah, Saudi Arabia",
    destination: "Worldwide (Pakistan, GCC, UK, Europe, USA, Asia)",
    moq: "500 Kilograms / Air & Sea Freight",
    description: {
      en: "Direct farm-sourced premium organic Ajwa Al-Aliya dates with laboratory phytosanitary certificates, nitrogen-flushed luxury vacuum packaging, and certified origin authentication.",
      ur: "مدینہ منورہ کے باغات سے براہ راست حاصل شدہ اعلیٰ کوالٹی عجوہ کھجوریں، لیبارٹری سرٹیفکیٹ اور بین الاقوامی پیکنگ کے ساتھ۔",
      ar: "تمور فاخرة منتقاة من نخيل المدينة المنورة مصحوبة بشهادات السلامة والجودة وتغليف فاخر للتصدير الدولي."
    },
    mainImage: "https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=800&q=80",
    specifications: [
      "100% Authentic Madinah Harvest",
      "Vacuum Sealed & Gift Boxes (500g, 1kg, 5kg)",
      "Global Express & Reefer Container Shipping Available",
      "Full Phytosanitary & ZATCA Invoicing"
    ],
    featured: true
  },
  {
    id: "trade-2",
    title: {
      en: "Official Certified Pure Zamzam Water Distribution Supply",
      ur: "باقاعدہ تصدیق شدہ خالص آبِ زمزم کی ترسیل",
      ar: "توزيع مياه زمزم المباركة المعتمدة رسمياً"
    },
    category: "Holy Relics & Zamzam",
    origin: "Makkah Al-Mukarramah (Kudai Center Bottling)",
    destination: "Regulated International Distribution Partners",
    moq: "100 Units (5 Liters sealed containers)",
    description: {
      en: "Official bottled Zamzam water sourced through authorized distribution channels with intact tamper-proof holographic seals and authorized travel documentation.",
      ur: "مکہ مکرمہ کدی پروجیکٹ سے باضابطہ پیک شدہ 5 لیٹر زمزم کین، مکمل سیکیورٹی سیل کے ساتھ۔",
      ar: "مياه زمزم المباركة المعبأة في مشروع الملك عبد الله بن عبد العزيز لسقيا زمزم بمكة المكرمة مع الأختام الأصلية."
    },
    mainImage: "https://images.unsplash.com/photo-1548839140-29a749e1bc4e?auto=format&fit=crop&w=800&q=80",
    specifications: [
      "Original 5L Bottles in reinforced cardboard shipping cartons",
      "Official Kudai Bottling Project Seals",
      "Available for Group Pilgrims and Cargo Shipping"
    ],
    featured: true
  },
  {
    id: "trade-3",
    title: {
      en: "Luxury Microfiber & Cotton Ihram & Prayer Mats Wholesale",
      ur: "لگژری احرام، جانماز اور تبرکات ہول سیل سپلائی",
      ar: "توريد ملابس الإحرام الفاخرة وسجادات الصلاة بالجملة"
    },
    category: "Textiles & Ihram",
    origin: "Saudi Arabia & Pakistan Direct Factory Ties",
    destination: "GCC, Pakistan, International Travel Agencies",
    moq: "200 Sets",
    description: {
      en: "Premium combed cotton, seamless 1400g extra-absorbent Ihram towels, non-slip luxury Rawdah-pattern prayer carpets, and travel gift kits for pilgrimage agencies.",
      ur: "اعلیٰ کوالٹی بغیر سلائی احرام تولیے، نرم مائیکرو فائبر جانماز اور ٹریول ایجنسیوں کے لیے برانڈڈ کٹس۔",
      ar: "أطقم إحرام قطنية فاخرة غير مخيطة وسجاد صلاة بنقوش الروضة الشريفة لوكالات السفر والمجموعات."
    },
    mainImage: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80",
    specifications: [
      "Heavyweight 1400g - 1600g Premium Turkish/Pakistani weave",
      "Shrink-resistant & Anti-allergenic",
      "Custom agency branding and logo embroidery available"
    ],
    featured: false
  }
];

export const initialInquiries: InquiryItem[] = [
  {
    id: "inq-101",
    createdAt: "2026-10-24T18:30:00.000Z",
    customerName: "Mohammad Usman Tariq",
    customerEmail: "usman.tariq@gmail.com",
    customerPhone: "+92 300 8765432",
    customerWhatsapp: "+923008765432",
    serviceType: "Umrah Package",
    targetItemTitle: "Royal VIP Executive Umrah (14 Days)",
    country: "Pakistan",
    personsCount: 4,
    travelDate: "2026-12-10",
    message: "Salam, we are a family of 4 looking for a 5-star hotel right in front of Haram in Makkah with GMC transport.",
    status: "New",
    privateAdminNotes: "Client requested quotation for Fairmont Clock Tower suite view."
  },
  {
    id: "inq-102",
    createdAt: "2026-10-23T14:15:00.000Z",
    customerName: "Sheikh Abdulrahman Al-Otaibi",
    customerEmail: "a.otaibi@business.sa",
    customerPhone: "+966 50 1234567",
    customerWhatsapp: "+966501234567",
    serviceType: "Fleet Transportation",
    targetItemTitle: "Mercedes Tourismo VIP Luxury Bus (49-Seater)",
    country: "Saudi Arabia",
    personsCount: 45,
    travelDate: "2026-11-20",
    message: "Urgent quote needed for delegate transport Jeddah Airport to Makkah hotel and return.",
    status: "Contacted",
    privateAdminNotes: "Quotation of 2,800 SAR sent via WhatsApp. Follow-up scheduled."
  }
];

export const initialMedia: MediaItem[] = [
  {
    id: "med-logo",
    name: "Fly With Hamza Official Logo Badge",
    url: "/assets/aistudio/IMG-20261001-WA0002_18c58d22.jpg",
    category: "General",
    uploadDate: "2026-10-24",
    fileSize: "248 KB"
  },
  {
    id: "med-cr",
    name: "Commercial Registration Certificate (Ministry of Commerce)",
    url: "/assets/aistudio/IMG-20261024-WA0016_ba95c865.jpg",
    category: "Certificates",
    uploadDate: "2026-10-24",
    fileSize: "412 KB"
  },
  {
    id: "med-vat",
    name: "VAT Tax Certificate (ZATCA)",
    url: "/assets/aistudio/document_1_3ae02818.jpg",
    category: "Certificates",
    uploadDate: "2026-10-24",
    fileSize: "530 KB"
  },
  {
    id: "med-naql",
    name: "Transport Authority Taxi License",
    url: "/assets/aistudio/____________________1_eacc80fc.jpg",
    category: "Certificates",
    uploadDate: "2026-10-24",
    fileSize: "320 KB"
  },
  {
    id: "med-address",
    name: "SPL National Address Proof Makkah",
    url: "/assets/aistudio/_______________________________1_5e8860a6.jpg",
    category: "Certificates",
    uploadDate: "2026-10-24",
    fileSize: "380 KB"
  }
];
