import { createClient, SupabaseClient } from '@supabase/supabase-js';

let supabaseInstance: SupabaseClient | null = null;

export function getSupabaseClient(url?: string, anonKey?: string): SupabaseClient | null {
  const finalUrl = url || (typeof window !== 'undefined' ? localStorage.getItem('fwh_supabase_url') : '') || '';
  const finalKey = anonKey || (typeof window !== 'undefined' ? localStorage.getItem('fwh_supabase_anon_key') : '') || '';

  if (!finalUrl || !finalKey) {
    return null;
  }

  try {
    if (!supabaseInstance) {
      supabaseInstance = createClient(finalUrl, finalKey);
    }
    return supabaseInstance;
  } catch (err) {
    console.error('Failed to create Supabase client:', err);
    return null;
  }
}

export function resetSupabaseClient(url: string, anonKey: string): SupabaseClient | null {
  try {
    if (typeof window !== 'undefined') {
      localStorage.setItem('fwh_supabase_url', url);
      localStorage.setItem('fwh_supabase_anon_key', anonKey);
    }
    supabaseInstance = createClient(url, anonKey);
    return supabaseInstance;
  } catch (err) {
    console.error('Failed to reset Supabase client:', err);
    return null;
  }
}
