export const MASTER_SUPABASE_SQL = `-- ==============================================================================
-- FLY WITH HAMZA TRAVAL AND TOURS - SUPABASE POSTGRESQL MASTER DATABASE SCHEMA
-- Official Company: FLY WITH HAMZA TRAVAL AND TOURS (CR: 7054724989)
-- Designed for Supabase SQL Editor execution
-- ==============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. COMPANY SETTINGS TABLE
CREATE TABLE IF NOT EXISTS company_settings (
    id TEXT PRIMARY KEY DEFAULT 'primary',
    company_name TEXT NOT NULL DEFAULT 'FLY WITH HAMZA TRAVAL AND TOURS',
    tagline_en TEXT,
    tagline_ur TEXT,
    tagline_ar TEXT,
    description_en TEXT,
    description_ur TEXT,
    description_ar TEXT,
    about_us_en TEXT,
    about_us_ur TEXT,
    about_us_ar TEXT,
    mission_en TEXT,
    mission_ur TEXT,
    mission_ar TEXT,
    vision_en TEXT,
    vision_ur TEXT,
    vision_ar TEXT,
    logo_url TEXT,
    phone TEXT NOT NULL DEFAULT '+96594722026',
    whatsapp TEXT NOT NULL DEFAULT '+96594722026',
    email TEXT DEFAULT 'info@flywithhamzatravel.com',
    office_address_en TEXT,
    office_address_ur TEXT,
    office_address_ar TEXT,
    saudi_address_en TEXT,
    saudi_address_ur TEXT,
    saudi_address_ar TEXT,
    google_maps_url TEXT,
    postal_code TEXT DEFAULT '24352',
    working_hours_en TEXT,
    working_hours_ur TEXT,
    working_hours_ar TEXT,
    emergency_contact TEXT DEFAULT '+96594722026',
    facebook_url TEXT,
    instagram_url TEXT,
    youtube_url TEXT,
    tiktok_url TEXT,
    linkedin_url TEXT,
    twitter_url TEXT,
    cr_number TEXT DEFAULT '7054724989',
    vat_number TEXT DEFAULT '314885364400003',
    national_address_short TEXT DEFAULT 'MDKA9011',
    transport_license_number TEXT DEFAULT '18/00001463',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. PACKAGES TABLE
CREATE TABLE IF NOT EXISTS packages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug TEXT UNIQUE,
    category TEXT NOT NULL CHECK (category IN ('umrah', 'hajj', 'ziyarat', 'holiday', 'family', 'custom')),
    badge TEXT DEFAULT 'Popular',
    title_en TEXT NOT NULL,
    title_ur TEXT,
    title_ar TEXT,
    duration_days INTEGER NOT NULL DEFAULT 10,
    duration_nights INTEGER NOT NULL DEFAULT 9,
    price_sar NUMERIC(10, 2) NOT NULL DEFAULT 0,
    discount_percent NUMERIC(5, 2) DEFAULT 0,
    destination_en TEXT,
    destination_ur TEXT,
    destination_ar TEXT,
    makkah_hotel_en TEXT,
    makkah_hotel_ur TEXT,
    makkah_hotel_ar TEXT,
    makkah_hotel_distance TEXT,
    madinah_hotel_en TEXT,
    madinah_hotel_ur TEXT,
    madinah_hotel_ar TEXT,
    madinah_hotel_distance TEXT,
    transport_type_en TEXT,
    transport_type_ur TEXT,
    transport_type_ar TEXT,
    featured BOOLEAN DEFAULT true,
    active BOOLEAN DEFAULT true,
    main_image TEXT,
    gallery TEXT[] DEFAULT '{}',
    included JSONB DEFAULT '[]'::jsonb,
    excluded JSONB DEFAULT '[]'::jsonb,
    itinerary JSONB DEFAULT '[]'::jsonb,
    departure_dates TEXT[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. HOTELS TABLE
CREATE TABLE IF NOT EXISTS hotels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_en TEXT NOT NULL,
    name_ur TEXT,
    name_ar TEXT,
    city TEXT NOT NULL CHECK (city IN ('Makkah', 'Madinah', 'Jeddah', 'Riyadh')),
    area_en TEXT,
    area_ur TEXT,
    area_ar TEXT,
    stars INTEGER NOT NULL DEFAULT 5,
    distance_from_haram_meters INTEGER DEFAULT 0,
    distance_text_en TEXT,
    distance_text_ur TEXT,
    distance_text_ar TEXT,
    price_per_night_sar NUMERIC(10, 2) NOT NULL DEFAULT 500,
    main_image TEXT,
    gallery TEXT[] DEFAULT '{}',
    amenities TEXT[] DEFAULT '{}',
    description_en TEXT,
    description_ur TEXT,
    description_ar TEXT,
    featured BOOLEAN DEFAULT false,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. VEHICLES & TRANSPORTATION TABLE
CREATE TABLE IF NOT EXISTS vehicles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_en TEXT NOT NULL,
    name_ur TEXT,
    name_ar TEXT,
    category TEXT NOT NULL CHECK (category IN ('Sedan', 'SUV', 'Luxury VIP', 'Van', 'Coaster', 'Bus')),
    model_year TEXT DEFAULT '2025/2026',
    passenger_capacity INTEGER NOT NULL DEFAULT 4,
    luggage_capacity INTEGER NOT NULL DEFAULT 4,
    features JSONB DEFAULT '[]'::jsonb,
    rates JSONB DEFAULT '{}'::jsonb,
    main_image TEXT,
    featured BOOLEAN DEFAULT false,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. VISA SERVICES TABLE
CREATE TABLE IF NOT EXISTS visa_services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title_en TEXT NOT NULL,
    title_ur TEXT,
    title_ar TEXT,
    type TEXT NOT NULL,
    processing_time_en TEXT,
    processing_time_ur TEXT,
    processing_time_ar TEXT,
    validity_en TEXT,
    validity_ur TEXT,
    validity_ar TEXT,
    approx_fee_sar NUMERIC(10, 2) DEFAULT 0,
    description_en TEXT,
    description_ur TEXT,
    description_ar TEXT,
    requirements JSONB DEFAULT '[]'::jsonb,
    documents_required JSONB DEFAULT '[]'::jsonb,
    featured BOOLEAN DEFAULT false,
    active BOOLEAN DEFAULT true,
    icon_name TEXT DEFAULT 'Compass',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 6. DESTINATIONS TABLE
CREATE TABLE IF NOT EXISTS destinations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_en TEXT NOT NULL,
    name_ur TEXT,
    name_ar TEXT,
    city TEXT NOT NULL,
    country TEXT NOT NULL DEFAULT 'Saudi Arabia',
    tagline_en TEXT,
    tagline_ur TEXT,
    tagline_ar TEXT,
    description_en TEXT,
    description_ur TEXT,
    description_ar TEXT,
    main_image TEXT,
    attractions JSONB DEFAULT '[]'::jsonb,
    recommended_duration_en TEXT,
    recommended_duration_ur TEXT,
    recommended_duration_ar TEXT,
    featured BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 7. IMPORT & EXPORT PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS import_export (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title_en TEXT NOT NULL,
    title_ur TEXT,
    title_ar TEXT,
    category TEXT NOT NULL,
    origin TEXT DEFAULT 'Saudi Arabia',
    destination TEXT DEFAULT 'Worldwide',
    moq TEXT,
    description_en TEXT,
    description_ur TEXT,
    description_ar TEXT,
    main_image TEXT,
    specifications TEXT[] DEFAULT '{}',
    featured BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 8. CERTIFICATES & OFFICIAL SAUDI DOCUMENTS TABLE
CREATE TABLE IF NOT EXISTS certificates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title_en TEXT NOT NULL,
    title_ur TEXT,
    title_ar TEXT,
    authority_en TEXT,
    authority_ur TEXT,
    authority_ar TEXT,
    certificate_number TEXT NOT NULL,
    issue_date TEXT,
    expiry_date TEXT,
    document_image TEXT NOT NULL,
    verification_url TEXT,
    qr_value TEXT,
    description_en TEXT,
    description_ur TEXT,
    description_ar TEXT,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 9. INQUIRIES & LEADS CRM TABLE
CREATE TABLE IF NOT EXISTS inquiries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    customer_name TEXT NOT NULL,
    customer_email TEXT NOT NULL,
    customer_phone TEXT,
    customer_whatsapp TEXT NOT NULL,
    service_type TEXT NOT NULL,
    target_item_title TEXT,
    country TEXT,
    persons_count INTEGER DEFAULT 1,
    travel_date TEXT,
    message TEXT,
    status TEXT NOT NULL DEFAULT 'New' CHECK (status IN ('New', 'Pending', 'Contacted', 'Quoted', 'Confirmed', 'Cancelled')),
    private_admin_notes TEXT
);

-- 10. MEDIA LIBRARY TABLE
CREATE TABLE IF NOT EXISTS media_library (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    url TEXT NOT NULL,
    category TEXT DEFAULT 'General',
    file_size TEXT,
    upload_date TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- ENABLE ROW LEVEL SECURITY (RLS)
ALTER TABLE company_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE hotels ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE visa_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE import_export ENABLE ROW LEVEL SECURITY;
ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;
ALTER TABLE inquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE media_library ENABLE ROW LEVEL SECURITY;

-- POLICIES
CREATE POLICY "Allow public read for company_settings" ON company_settings FOR SELECT USING (true);
CREATE POLICY "Allow public read for packages" ON packages FOR SELECT USING (active = true);
CREATE POLICY "Allow public read for hotels" ON hotels FOR SELECT USING (active = true);
CREATE POLICY "Allow public read for vehicles" ON vehicles FOR SELECT USING (active = true);
CREATE POLICY "Allow public read for visa_services" ON visa_services FOR SELECT USING (active = true);
CREATE POLICY "Allow public read for destinations" ON destinations FOR SELECT USING (true);
CREATE POLICY "Allow public read for import_export" ON import_export FOR SELECT USING (true);
CREATE POLICY "Allow public read for certificates" ON certificates FOR SELECT USING (active = true);
CREATE POLICY "Allow public insert for inquiries" ON inquiries FOR INSERT WITH CHECK (true);
`;
