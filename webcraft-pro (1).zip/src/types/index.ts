export type Language = 'en' | 'ur' | 'ar';

export type Currency = 'SAR' | 'PKR' | 'USD' | 'AED';

export interface MultiLangString {
  en: string;
  ur: string;
  ar: string;
}

export interface CompanySettings {
  companyName: string;
  tagline: MultiLangString;
  description: MultiLangString;
  aboutUs: MultiLangString;
  mission: MultiLangString;
  vision: MultiLangString;
  logo: string;
  phone: string;
  whatsapp: string;
  email: string;
  officeAddress: MultiLangString;
  saudiAddress: MultiLangString;
  googleMapsUrl: string;
  postalCode: string;
  workingHours: MultiLangString;
  emergencyContact: string;
  socialMedia: {
    facebook?: string;
    instagram?: string;
    youtube?: string;
    tiktok?: string;
    linkedin?: string;
    twitter?: string;
  };
  crNumber: string;
  vatNumber: string;
  nationalAddressShort: string;
  transportLicenseNumber: string;
  supabaseUrl?: string;
  supabaseAnonKey?: string;
}

export interface PackageItem {
  id: string;
  title: MultiLangString;
  category: 'umrah' | 'hajj' | 'ziyarat' | 'holiday' | 'custom';
  badge: 'Popular' | 'VIP' | 'Economy' | 'New' | 'Family' | 'Limited';
  durationDays: number;
  durationNights: number;
  priceSar: number;
  discountPercent?: number;
  destination: MultiLangString;
  makkahHotel: MultiLangString;
  makkahHotelDistance: string;
  madinahHotel: MultiLangString;
  madinahHotelDistance: string;
  transportType: MultiLangString;
  featured: boolean;
  active: boolean;
  mainImage: string;
  gallery: string[];
  included: MultiLangString[];
  excluded: MultiLangString[];
  itinerary: {
    day: number;
    title: MultiLangString;
    description: MultiLangString;
  }[];
  departureDates: string[];
}

export interface HotelItem {
  id: string;
  name: MultiLangString;
  city: 'Makkah' | 'Madinah' | 'Jeddah' | 'Riyadh';
  area: MultiLangString;
  stars: number;
  distanceFromHaramMeters: number;
  distanceText: MultiLangString;
  pricePerNightSar: number;
  mainImage: string;
  gallery: string[];
  amenities: string[];
  description: MultiLangString;
  featured: boolean;
  active: boolean;
}

export interface VehicleItem {
  id: string;
  name: MultiLangString;
  category: 'Sedan' | 'SUV' | 'Luxury VIP' | 'Van' | 'Coaster' | 'Bus';
  modelYear: string;
  passengerCapacity: number;
  luggageCapacity: number;
  features: MultiLangString[];
  ratePerRouteSar: {
    makkahToMadinah: number;
    jeddahAirportToMakkah: number;
    madinahAirportToMadinah: number;
    ziyaratMakkah: number;
    ziyaratMadinah: number;
  };
  mainImage: string;
  featured: boolean;
  active: boolean;
}

export interface VisaServiceItem {
  id: string;
  title: MultiLangString;
  type: 'Work / Employment' | 'Tourist / Visit' | 'Umrah eVisa' | 'Business / Investor' | 'Family Visit';
  processingTime: MultiLangString;
  validity: MultiLangString;
  approxFeeSar: number;
  description: MultiLangString;
  requirements: MultiLangString[];
  documentsRequired: MultiLangString[];
  featured: boolean;
  active: boolean;
  iconName: string;
}

export interface DestinationItem {
  id: string;
  name: MultiLangString;
  city: string;
  country: string;
  tagline: MultiLangString;
  description: MultiLangString;
  mainImage: string;
  attractions: MultiLangString[];
  recommendedDuration: MultiLangString;
  featured: boolean;
}

export interface ImportExportItem {
  id: string;
  title: MultiLangString;
  category: 'Agri & Dates' | 'Holy Relics & Zamzam' | 'Textiles & Ihram' | 'General Trading' | 'Logistics';
  origin: string;
  destination: string;
  moq: string;
  description: MultiLangString;
  mainImage: string;
  specifications: (MultiLangString | string)[];
  featured: boolean;
}

export interface CertificateItem {
  id: string;
  title: MultiLangString;
  authority: MultiLangString;
  certificateNumber: string;
  issueDate: string;
  expiryDate: string;
  documentImage: string;
  verificationUrl?: string;
  qrValue?: string;
  description: MultiLangString;
  active: boolean;
}

export interface InquiryItem {
  id: string;
  createdAt: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerWhatsapp: string;
  serviceType: string;
  targetItemTitle?: string;
  country: string;
  personsCount: number;
  travelDate?: string;
  message: string;
  status: 'New' | 'Pending' | 'Contacted' | 'Quoted' | 'Confirmed' | 'Cancelled';
  privateAdminNotes?: string;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  category: 'Packages' | 'Hotels' | 'Vehicles' | 'Certificates' | 'Destinations' | 'General';
  uploadDate: string;
  fileSize: string;
}
